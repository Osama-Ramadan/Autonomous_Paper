#include "__cf_PassVeh7DOF.h"
#ifndef RTW_HEADER_PassVeh7DOF_capi_h_
#define RTW_HEADER_PassVeh7DOF_capi_h_
#include "PassVeh7DOF.h"
extern void PassVeh7DOF_InitializeDataMapInfo ( pa50wxsaaa * const hokadafud5
, bpefjqedzq * localDW , hcqlainyez * localX , void * sysRanPtr , int
contextTid ) ;
#endif
