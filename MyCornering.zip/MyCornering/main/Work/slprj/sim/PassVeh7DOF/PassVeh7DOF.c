#include "__cf_PassVeh7DOF.h"
#include "PassVeh7DOF_capi.h"
#include "PassVeh7DOF.h"
#include "PassVeh7DOF_private.h"
#include "interp2_rm8DQnLL.h"
#include "look1_binlcpw.h"
#include "look1_binlxpw.h"
static RegMdlInfo rtMdlInfo_PassVeh7DOF [ 107 ] = { { "or0r4q4rh4" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"j4fedpjpo0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "cspwehehgp" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "buwnn4ewmg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"bq3nsn4tha" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "hgz0u45ian" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "ijfgkn4l3e" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"iw0hhox1z3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "ji1gw0gkru" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "jaxagnd4mw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"jztpqiauj1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "fg22ue3aah" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "kelouni0w2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"dynfse4vnc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "mzvj13bo1n" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "mmcf5c4ckd" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"bocyy0pkp2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "aczei5pvks" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "ngq1joxobt" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"liftzd2mdx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "clgilwu00r" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "orfasxj0ep" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"lq2plzp4km" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "dg2od0xqji" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "knl4ewsztr" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"c3gqiwzg0d" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "fa5ca1a3gq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "csuqfix3h2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"bw5rgl5xeh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "ospwb2s4dn" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "ms5njtyggd" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"krvjupx21a" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "isppcpplpd" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "pqca3kvywqf" , MDL_INFO_NAME_MDLREF_DWORK ,
0 , - 1 , ( void * ) "PassVeh7DOF" } , { "kg2zcpxtlx" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"e3r11zdizr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "dn0l2t323g" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "ha25zehowz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"hcqlainyez" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "n52l1mzp31" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "pcbmq2m11v" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"a12pcgpb01" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "lijr033rr2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "bpefjqedzq" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"id4lpjcjia" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "dgk2ovyv5o" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "b51av3ulwn" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mfpcrarm3m" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "g3iefm0j4w" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "lis1ormwxp" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"pgy4d5vijx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "iu231drtpw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "ii3iorkudk" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"ps1ayp5pv5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "hzczw4rimi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "lahi4jyhaj" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"aoae4c423r" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "ateq2n1kdh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "h5dkixmxqh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"ijd5bz40nz" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "iibbapsg2n" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "bgjvfsnvvf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mkju4kqcel" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "alhvckflry" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "oo42sjmjl1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"gwrnctxr0y" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "ekmk5spjxa" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 ,
( void * ) "Locked" } , { "dhp1yzpksy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "PassVeh7DOF" } , { "gv2yzafy0b" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"hgf2ztyaep" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "do0vha2zzf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "g2cx1nveng" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"bowidq2yed" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "ndms1vagjm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "iusyzhpcqk" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"hor3rithbp" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( void * )
"Simple Magic Tire" } , { "PassVeh7DOF" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , 0 , ( NULL ) } , { "iqrkfebraoy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "PassVeh7DOF" } , { "a4qtx0azetw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"i2rjcmb3r3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "oinmjmcxpr0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , -
1 , ( void * ) "PassVeh7DOF" } , { "jy03oxyarzs" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"awewo52yo44" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "pwude5af1ju" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , -
1 , ( void * ) "PassVeh7DOF" } , { "iqrkfebrao" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"a4qtx0azet" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "oinmjmcxpr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "mkmp3c5j3y" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"pa50wxsaaa" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "struct_5NGg6nxNHRWKsr0nLboB4F" , MDL_INFO_ID_DATA_TYPE ,
0 , - 1 , ( NULL ) } , { "struct_wjXS3rIiQNI90M790LMxVG" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"struct_NtCe3ohFvXuRZXQoDidoXH" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL )
} , { "struct_A6Yb21eKNPgaupJlKafAPB" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "mr_PassVeh7DOF_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "PassVeh7DOF" } , { "mr_PassVeh7DOF_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 ,
( void * ) "PassVeh7DOF" } , { "mr_PassVeh7DOF_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "mr_PassVeh7DOF_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "PassVeh7DOF" } , { "PassVeh7DOF.h" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , { "PassVeh7DOF.c" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } } ;
becrktx0d0o becrktx0d0 = { 2.11 , 0.3 , 0.1 , 0.1 , { 0.0 , 0.03 , 0.06 ,
0.09 , 0.12 , 0.15 , 0.18 , 0.21 , 0.24 , 0.27 , 0.3 , 0.32999999999999996 ,
0.36 , 0.39 , 0.42 , 0.45 , 0.48000000000000004 , 0.51 , 0.54 ,
0.57000000000000006 , 0.60000000000000009 , 0.63 , 0.66 , 0.69000000000000006
, 0.72 , 0.75 , 0.78 , 0.81 , 0.84000000000000008 , 0.87 , 0.9 } , 15000.0 ,
35000.0 , { 0.0 , 0.01 , 0.02 , 0.03 , 0.04 , 0.05 , 0.06 , 0.07 , 0.08 ,
0.09 , 0.1 , 0.11 , 0.12 , 0.13 , 0.14 , 0.15 , 0.15999999999999998 ,
0.16999999999999998 , 0.18 , 0.19 , 0.19999999999999998 , 0.21 ,
0.21999999999999997 , 0.22999999999999998 , 0.24 , 0.25 , 0.26 , 0.27 ,
0.27999999999999997 , 0.29 , 0.3 } , 5000.0 , 5000.0 , 5000.0 , 5000.0 ,
10000.0 , 10000.0 , 10000.0 , 10000.0 , 1000.0 , 1000.0 , 1000.0 , 1000.0 ,
5000.0 , 0.8 , 0.8 , 0.8 , 0.8 , 2066.0 , 16.0 , 16.0 , 16.0 , 16.0 , 0.15 ,
0.15 , 0.15 , 0.15 , 2.0 , 220000.0 , 220000.0 , 220000.0 , 220000.0 , 2.0 ,
1.6 , 1.6 , 1.6 , 1.6 , 1.0 , 1.0 , 1.0 , 1.0 , - 0.08 , - 0.08 , - 0.08 , -
0.08 , 0.0 , 0.0 , 0.0 , 0.0 , 0.112 , 0.112 , 0.112 , 0.112 , 0.313 , 0.313
, 0.313 , 0.313 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0016 , 0.0016 , 0.0016 , 0.0016 ,
0.00021585 , 0.00021585 , 0.00021585 , 0.00021585 , 0.00115 , 0.00115 ,
0.00115 , 0.00115 , 21.7 , 21.7 , 21.7 , 21.7 , 13.77 , 13.77 , 13.77 , 13.77
, - 0.412 , - 0.412 , - 0.412 , - 0.412 , - 0.3489 , - 0.3489 , - 0.3489 , -
0.3489 , 0.382 , 0.382 , 0.382 , 0.382 , - 0.09634 , - 0.09634 , - 0.09634 ,
- 0.09634 , 0.06447 , 0.06447 , 0.06447 , 0.06447 , 1.5973E-5 , 1.5973E-5 ,
1.5973E-5 , 1.5973E-5 , 0.0001043 , 0.0001043 , 0.0001043 , 0.0001043 ,
101325.0 , 0.007 , 0.007 , 0.007 , 0.007 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0015 ,
0.0015 , 0.0015 , 0.0015 , 8.5E-5 , 8.5E-5 , 8.5E-5 , 8.5E-5 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.9 , 0.9 , 0.9 , 0.9 , - 0.4 , - 0.4 , -
0.4 , - 0.4 , 287.058 , 0.0 , 0.0 , 0.37 , 0.37 , 0.37 , 0.37 , 0.1778 ,
0.1778 , 0.1778 , 0.1778 , 273.0 , 0.37 , 0.37 , 0.37 , 0.37 , 0.1 , 0.1 ,
0.1 , 0.1 , 0.0 , 3.125 , 1.515 , 1.504 , { 0.0 , 0.01 , 0.02 , 0.03 , 0.04 ,
0.05 , 0.06 , 0.07 , 0.08 , 0.09 , 0.1 , 0.11 , 0.12 , 0.13 , 0.14 , 0.15 ,
0.15999999999999998 , 0.16999999999999998 , 0.18 , 0.19 , 0.19999999999999998
, 0.21 , 0.21999999999999997 , 0.22999999999999998 , 0.24 , 0.25 , 0.26 ,
0.27 , 0.27999999999999997 , 0.29 , 0.3 } , 0.001 , 0.001 , 0.001 , 0.001 ,
0.0 , 0.05 , 0.05 , 0.05 , 0.05 , 9.81 , 0.0 , 0.0 , 0.0 , 0.0 , 0.134 , 1.5
, 1.5 , 1.5 , 1.5 , 1.0 , 1.0 , 1.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 1.0
, 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0
, 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1181.0 , 0.2 , 0.2 ,
0.2 , 0.2 , 0.3 , 0.3 , 0.3 , 0.3 , 2.0 , 2.0 , 2.0 , 2.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.1 , 0.1 , 125.66370614359172 , 0.0 , 1.0 , 0.0 , 0.0 , -
4.0 , 0.0 , - 4.0 , 0.0 , - 4.0 , 0.0 , - 4.0 , 7.0E+6 , 2.0E+6 , { 1.922 ,
1.922 } , 0.0 , 0.0 , 0.0 , - 1.0 , 0.78539816339744828 , 0.0 ,
2.2204460492503131E-16 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , {
3.1415926535897931 , 3.1415926535897931 , 3.1415926535897931 ,
3.1415926535897931 } , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 10000.0 , 1.0E+6 ,
{ 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 } , 10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0 ,
0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 2.0 , 2.0 , 0.0 , 0.0 ,
0.0 , - 1.0 , 0.78539816339744828 , 0.0 , 2.2204460492503131E-16 , 0.0 , 1.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 10000.0 , 1.0E+6 , { 0.0 , 0.0 ,
0.0 } , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 } , 10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 } , {
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 2.0 , 2.0 , 0.0 , 0.0 , 0.0 , - 1.0 ,
0.78539816339744828 , 0.0 , 2.2204460492503131E-16 , 0.0 , 1.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0
, 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } ,
10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 2.0 , 2.0 , 0.0 , 0.0 , 0.0 , - 1.0 ,
0.78539816339744828 , 0.0 , 2.2204460492503131E-16 , 0.0 , 1.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0
, 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } ,
10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 2.0 , 2.0 , 0.0 , - 5.0 , 5.0 , 0.5 , 0.5 , 0.5 , {
1.0 , 1.0 , 1.0 } , 0.0 , { 0.0 , 0.0 } , { - 1.0 , 1.0 } , 20000.0 , 1000.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , { 0.134 , 0.134 , 0.134 , 0.134 } , 0 , { 0 ,
1 , 0 , 0 , 1 , 1 , 1 , 0 } , 0 , { 0 , 1 , 0 , 0 , 1 , 1 , 1 , 0 } , 0 , { 0
, 1 , 0 , 0 , 1 , 1 , 1 , 0 } , 0 , { 0 , 1 , 0 , 0 , 1 , 1 , 1 , 0 } , { 0.0
, 0.0 } , { 0.0 , 0.0 } , { 0.0 , 0.0 } , { 0.0 , 0.0 } } ; static void
hyxmtil4ba ( real_T rhoz , real_T omega , real_T * Re , real_T * Fz ) ;
static void ey44ilkqk5 ( const real_T a_data [ ] , const int32_T a_size [ 2 ]
, real_T y_data [ ] , int32_T y_size [ 2 ] ) ; static real_T ompv3yyu2t (
real_T Re , real_T omega , real_T Vx , real_T b_VXLOW , real_T b_kappamax ) ;
static void hh45nhwxle ( real_T u , real_T * y , real_T * yabs ) ; static
real_T oraw1x3kwu ( real_T kappa , real_T Vx , real_T Fz , real_T b_gamma ,
real_T LONGVL , real_T FNOMIN , real_T b_FZMIN , real_T b_FZMAX , real_T
press , real_T NOMPRES , real_T PRESMIN , real_T PRESMAX , real_T PCX1 ,
real_T PDX1 , real_T PDX2 , real_T PDX3 , real_T PEX1 , real_T PEX2 , real_T
PEX3 , real_T PEX4 , real_T PKX1 , real_T PKX2 , real_T PKX3 , real_T PHX1 ,
real_T PHX2 , real_T PVX1 , real_T PVX2 , real_T PPX1 , real_T PPX2 , real_T
PPX3 , real_T PPX4 , real_T lam_Fzo , real_T lam_muV , real_T lam_mux ,
real_T lam_Kxkappa , real_T lam_Cx , real_T lam_Ex , real_T lam_Hx , real_T
lam_Vx ) ; static real_T frme5sc23i ( real_T Fz , real_T omega , real_T Vx ,
real_T press , real_T QSY1 , real_T QSY2 , real_T QSY3 , real_T QSY7 , real_T
QSY8 , real_T UNLOADED_RADIUS , real_T b_FZMIN , real_T b_FZMAX , real_T
PRESMIN , real_T PRESMAX ) ; static real_T njnyloetbl ( real_T Fx , real_T Fz
, real_T omega , real_T Vx , real_T press , real_T FNOMIN , real_T NOMPRES ,
real_T QSY1 , real_T QSY2 , real_T QSY3 , real_T QSY4 , real_T QSY5 , real_T
QSY6 , real_T QSY7 , real_T QSY8 , real_T b_gamma , real_T lam_My , real_T
UNLOADED_RADIUS , real_T b_FZMAX , real_T PRESMIN , real_T PRESMAX ) ; static
void gxcyrp3wtv ( real_T Ftire_x , real_T Ftire_y , real_T b_Fxtire_sat ,
real_T b_Fytire_sat , real_T * Ftire_xs , real_T * Ftire_ys ) ; static void
hyxmtil4ba ( real_T rhoz , real_T omega , real_T * Re , real_T * Fz ) { * Re
= 0.0 * muDoubleScalarAbs ( omega ) + rhoz ; if ( * Re < 0.001 ) { * Re =
0.001 ; } * Fz = ( rtNaN ) ; } static void ey44ilkqk5 ( const real_T a_data [
] , const int32_T a_size [ 2 ] , real_T y_data [ ] , int32_T y_size [ 2 ] ) {
real_T z1_data ; int32_T loop_ub ; y_size [ 1 ] = ( int8_T ) a_size [ 1 ] ;
loop_ub = y_size [ 1 ] - 1 ; if ( 0 <= loop_ub ) { memcpy ( & z1_data , &
y_data [ 0 ] , ( loop_ub + 1 ) * sizeof ( real_T ) ) ; } if ( 1 <= y_size [ 1
] ) { z1_data = a_data [ 0 ] * a_data [ 0 ] ; } y_size [ 0 ] = 1 ; loop_ub =
y_size [ 1 ] - 1 ; if ( 0 <= loop_ub ) { memcpy ( & y_data [ 0 ] , & z1_data
, ( loop_ub + 1 ) * sizeof ( real_T ) ) ; } } static real_T ompv3yyu2t (
real_T Re , real_T omega , real_T Vx , real_T b_VXLOW , real_T b_kappamax ) {
real_T kappa ; real_T Vxpabs ; int32_T b_trueCount ; real_T f_data ; real_T
Vxpabs_data ; real_T tmp_data ; int32_T i ; int32_T Vxpabs_size [ 2 ] ;
int32_T tmp_size [ 2 ] ; Vxpabs = muDoubleScalarAbs ( Vx ) ; b_trueCount = 0
; if ( Vxpabs < b_VXLOW ) { b_trueCount = 1 ; } Vxpabs_size [ 0 ] = 1 ;
Vxpabs_size [ 1 ] = b_trueCount ; for ( i = 0 ; i < b_trueCount ; i ++ ) {
Vxpabs_data = Vxpabs / b_VXLOW ; } ey44ilkqk5 ( & Vxpabs_data , Vxpabs_size ,
& tmp_data , tmp_size ) ; for ( i = 0 ; i < b_trueCount ; i ++ ) { f_data =
2.0 * b_VXLOW / ( 3.0 - tmp_data ) ; } if ( Vxpabs < b_VXLOW ) { Vxpabs =
f_data ; } kappa = ( Re * omega - Vx ) / Vxpabs ; b_trueCount = 0 ; if (
kappa < - b_kappamax ) { b_trueCount = 1 ; } if ( 0 <= b_trueCount - 1 ) {
kappa = - b_kappamax ; } if ( kappa > b_kappamax ) { kappa = b_kappamax ; }
return kappa ; } static void hh45nhwxle ( real_T u , real_T * y , real_T *
yabs ) { int32_T trueCount ; real_T d_data ; real_T yabs_data ; real_T
tmp_data ; int32_T i ; int32_T yabs_size [ 2 ] ; int32_T tmp_size [ 2 ] ; *
yabs = muDoubleScalarAbs ( u ) ; trueCount = 0 ; if ( * yabs < 0.1 ) {
trueCount = 1 ; } yabs_size [ 0 ] = 1 ; yabs_size [ 1 ] = trueCount ; for ( i
= 0 ; i < trueCount ; i ++ ) { yabs_data = * yabs / 0.1 ; } ey44ilkqk5 ( &
yabs_data , yabs_size , & tmp_data , tmp_size ) ; for ( i = 0 ; i < trueCount
; i ++ ) { d_data = 0.2 / ( 3.0 - tmp_data ) ; } if ( * yabs < 0.1 ) { * yabs
= d_data ; } trueCount = 0 ; if ( u < 0.0 ) { trueCount = 1 ; } trueCount --
; for ( i = 0 ; i <= trueCount ; i ++ ) { d_data = - * yabs ; } * y = * yabs
; if ( u < 0.0 ) { * y = d_data ; } } static real_T oraw1x3kwu ( real_T kappa
, real_T Vx , real_T Fz , real_T b_gamma , real_T LONGVL , real_T FNOMIN ,
real_T b_FZMIN , real_T b_FZMAX , real_T press , real_T NOMPRES , real_T
PRESMIN , real_T PRESMAX , real_T PCX1 , real_T PDX1 , real_T PDX2 , real_T
PDX3 , real_T PEX1 , real_T PEX2 , real_T PEX3 , real_T PEX4 , real_T PKX1 ,
real_T PKX2 , real_T PKX3 , real_T PHX1 , real_T PHX2 , real_T PVX1 , real_T
PVX2 , real_T PPX1 , real_T PPX2 , real_T PPX3 , real_T PPX4 , real_T lam_Fzo
, real_T lam_muV , real_T lam_mux , real_T lam_Kxkappa , real_T lam_Cx ,
real_T lam_Ex , real_T lam_Hx , real_T lam_Vx ) { real_T Fxo ; real_T dpi ;
real_T dfz ; real_T kappa_x ; real_T Vsx ; real_T Cx ; real_T unusedU0 ;
real_T b_idx_0 ; real_T f_idx_0 ; real_T g_idx_0 ; real_T h_idx_0 ; real_T
Cx_tmp ; b_idx_0 = Fz ; if ( Fz < b_FZMIN ) { b_idx_0 = b_FZMIN ; } if (
b_idx_0 > b_FZMAX ) { b_idx_0 = b_FZMAX ; } dfz = press ; if ( press <
PRESMIN ) { dfz = PRESMIN ; } if ( dfz > PRESMAX ) { dfz = PRESMAX ; } dpi =
( dfz - NOMPRES ) / NOMPRES ; dfz = ( b_idx_0 - FNOMIN * lam_Fzo ) / FNOMIN *
lam_Fzo ; kappa_x = ( PHX2 * dfz + PHX1 ) * lam_Hx + kappa ; Vsx = -
muDoubleScalarAbs ( Vx ) * kappa ; Vsx = lam_mux / ( muDoubleScalarSqrt ( Vsx
* Vsx ) * lam_muV / LONGVL + 1.0 ) ; Cx = PCX1 * lam_Cx ; f_idx_0 = Cx ; if (
Cx < 0.0 ) { f_idx_0 = 0.0 ; } Cx_tmp = dpi * dpi ; Cx = ( ( PPX3 * dpi + 1.0
) + Cx_tmp * PPX4 ) * ( PDX2 * dfz + PDX1 ) * ( 1.0 - b_gamma * b_gamma *
PDX3 ) * Vsx * b_idx_0 ; g_idx_0 = Cx ; if ( Cx < 0.0 ) { g_idx_0 = 0.0 ; }
Cx = ( ( PEX2 * dfz + PEX1 ) + dfz * dfz * PEX3 ) * ( 1.0 -
muDoubleScalarTanh ( 10.0 * kappa_x ) * PEX4 ) * lam_Ex ; h_idx_0 = Cx ; if (
Cx > 1.0 ) { h_idx_0 = 1.0 ; } hh45nhwxle ( f_idx_0 * g_idx_0 , & Cx , &
unusedU0 ) ; dpi = ( PKX2 * dfz + PKX1 ) * b_idx_0 * muDoubleScalarExp ( PKX3
* dfz ) * ( ( PPX1 * dpi + 1.0 ) + Cx_tmp * PPX2 ) * lam_Kxkappa / Cx ; dpi
*= kappa_x ; Fxo = muDoubleScalarSin ( muDoubleScalarAtan ( dpi - ( dpi -
muDoubleScalarAtan ( dpi ) ) * h_idx_0 ) * f_idx_0 ) * g_idx_0 + ( PVX2 * dfz
+ PVX1 ) * b_idx_0 * ( Vsx * 10.0 / ( 9.0 * Vsx + 1.0 ) ) * lam_Vx ; return
Fxo ; } static real_T frme5sc23i ( real_T Fz , real_T omega , real_T Vx ,
real_T press , real_T QSY1 , real_T QSY2 , real_T QSY3 , real_T QSY7 , real_T
QSY8 , real_T UNLOADED_RADIUS , real_T b_FZMIN , real_T b_FZMAX , real_T
PRESMIN , real_T PRESMAX ) { real_T b_idx_0 ; real_T d_idx_0 ; b_idx_0 =
press ; if ( press < PRESMIN ) { b_idx_0 = PRESMIN ; } if ( b_idx_0 > PRESMAX
) { b_idx_0 = PRESMAX ; } d_idx_0 = Fz ; if ( Fz < b_FZMIN ) { d_idx_0 =
b_FZMIN ; } if ( d_idx_0 > b_FZMAX ) { d_idx_0 = b_FZMAX ; } return ( ( QSY2
* muDoubleScalarAbs ( Vx ) + QSY1 ) + Vx * Vx * QSY3 ) * ( muDoubleScalarTanh
( omega ) * UNLOADED_RADIUS ) * ( muDoubleScalarPower ( d_idx_0 , QSY7 ) *
muDoubleScalarPower ( b_idx_0 , QSY8 ) ) ; } static real_T njnyloetbl (
real_T Fx , real_T Fz , real_T omega , real_T Vx , real_T press , real_T
FNOMIN , real_T NOMPRES , real_T QSY1 , real_T QSY2 , real_T QSY3 , real_T
QSY4 , real_T QSY5 , real_T QSY6 , real_T QSY7 , real_T QSY8 , real_T b_gamma
, real_T lam_My , real_T UNLOADED_RADIUS , real_T b_FZMAX , real_T PRESMIN ,
real_T PRESMAX ) { real_T b_idx_0 ; real_T d_idx_0 ; b_idx_0 = press ; if (
press < PRESMIN ) { b_idx_0 = PRESMIN ; } if ( b_idx_0 > PRESMAX ) { b_idx_0
= PRESMAX ; } d_idx_0 = Fz ; if ( Fz < 0.0 ) { d_idx_0 = 0.0 ; } if ( d_idx_0
> b_FZMAX ) { d_idx_0 = b_FZMAX ; } return ( ( ( ( QSY2 * Fx / FNOMIN + QSY1
) + muDoubleScalarAbs ( Vx / 16.7 ) * QSY3 ) + muDoubleScalarPower ( Vx /
16.7 , 4.0 ) * QSY4 ) + ( QSY6 * d_idx_0 / FNOMIN + QSY5 ) * ( b_gamma *
b_gamma ) ) * ( muDoubleScalarTanh ( omega ) * d_idx_0 * UNLOADED_RADIUS ) *
( muDoubleScalarPower ( d_idx_0 / FNOMIN , QSY7 ) * muDoubleScalarPower (
b_idx_0 / NOMPRES , QSY8 ) ) * lam_My ; } void hor3rithbp ( real_T ilffr4btj5
, real_T pfjlghkggb , real_T djfsfpj4qr , real_T exb3burec2 , real_T
btp1gnxg02 , real_T dck3dqvqmx , real_T krmy4cl1um , real_T j4aqt55g2q ,
real_T dmiespubsg , real_T mo4nmz4dui , real_T dlj0yi5tka , real_T hgjkq3rufa
, const real_T * patgulbqmk , real_T lyklokzsu4 , real_T k22p4holuz , real_T
fjx1adphei , real_T kkut5t432y , real_T cizl4iss3n , real_T lbesb2c3zi ,
real_T ehu5lvdfn2 , real_T fuk5zl503w , real_T be0orbfspb , real_T hqmvg12ti0
, real_T npwnugvscc , real_T huic1c4v55 , real_T iirsl31hdo , real_T
g2lysmlhyi , real_T a00ih3oxlk , real_T mczrpgw2wm , real_T aeptep1nip ,
real_T enff4ghtir , real_T ij314icd3s , real_T chjdmyvqxw , real_T kcptdouxiy
, real_T ncqzkqjsi5 , real_T cvk0ncglt2 , real_T nrlhbcvdrj , const real_T *
iwup2rjnly , real_T jk3e44ywwc , real_T a35hpppuoz , real_T ph0ymmh5bd ,
real_T e10q0lhd4i , real_T pznws2ac3n , const real_T c0lh1c1elq [ 3 ] , const
real_T dpvuosztse [ 3 ] , const real_T d3xks5eixq [ 9 ] , real_T nc2kpvmfsf ,
real_T elxybvxjvj , real_T nxgzwxhwto , real_T ce4aots51j , real_T c0g12pojmz
, real_T fvwwfdsk4k , real_T oducigfnlg , real_T aaosao0j1p , real_T
f2fuje5nkj , real_T bjdyk5yqdr , real_T kpf44nicuu , real_T ffpyhdgr2y ,
real_T hwbv55ijok , real_T dexwsni3hm , real_T itpvgcv0fr , const real_T
bjzqtf430o [ 3 ] , const real_T ogihkjapxm [ 3 ] , const real_T bkom5ytmqe [
9 ] , real_T er0fttewvi , real_T gfaavtttqm , real_T n5olq2bccj , real_T
l0oknvdvkx , real_T gu4hswlxp5 , real_T lp5bdiqspv , real_T oy4emxdjoh ,
real_T crno3gqpev , real_T dldnuryub1 , real_T auu5ang0o2 , real_T dyv2j5zovi
, real_T mmmicydxgc , real_T fikyfswgql , real_T gmsc0grzar , real_T
axcwfgjptt , real_T f1tqoyuh4d , real_T mvjvsasyhj , real_T chhocy4irm ,
real_T a2dyewy3jy , real_T c3b2ezb5i3 , real_T bzedi2wtff , real_T psmcmllijr
, real_T orjl001kvi , real_T jdxksqajpx , real_T khsfuldvnp , real_T
n2xncev0ib , real_T h3wdnrrz3n , real_T * jvc4v23k1x , real_T * bwzzfyfbno ,
isppcpplpd * localB , real_T rtp_FZMAX , real_T rtp_FZMIN , real_T rtp_VXLOW
, real_T rtp_kappamax ) { real_T Fx ; real_T Re ; real_T b_FzTire ; real_T
d3xks5eixq_p [ 9 ] ; int32_T i ; real_T Fx_tmp ; localB -> d5h53uezna [ 0 ] =
btp1gnxg02 ; localB -> d5h53uezna [ 1 ] = dck3dqvqmx ; localB -> d5h53uezna [
2 ] = krmy4cl1um ; localB -> d5h53uezna [ 3 ] = j4aqt55g2q ; localB ->
d5h53uezna [ 4 ] = dmiespubsg ; localB -> lfqxtpersw [ 0 ] = mo4nmz4dui ;
localB -> lfqxtpersw [ 1 ] = dlj0yi5tka ; localB -> lfqxtpersw [ 2 ] =
hgjkq3rufa ; localB -> lfqxtpersw [ 3 ] = * patgulbqmk ; localB -> lfqxtpersw
[ 4 ] = lyklokzsu4 ; localB -> lfqxtpersw [ 5 ] = k22p4holuz ; localB ->
lfqxtpersw [ 6 ] = fjx1adphei ; localB -> lfqxtpersw [ 7 ] = kkut5t432y ;
localB -> lfqxtpersw [ 8 ] = cizl4iss3n ; localB -> lfqxtpersw [ 9 ] =
lbesb2c3zi ; localB -> lfqxtpersw [ 10 ] = ehu5lvdfn2 ; localB -> lfqxtpersw
[ 11 ] = fuk5zl503w ; localB -> lfqxtpersw [ 12 ] = be0orbfspb ; localB ->
lfqxtpersw [ 13 ] = hqmvg12ti0 ; localB -> lfqxtpersw [ 14 ] = npwnugvscc ;
localB -> lfqxtpersw [ 15 ] = huic1c4v55 ; localB -> lfqxtpersw [ 16 ] =
iirsl31hdo ; localB -> lfqxtpersw [ 17 ] = g2lysmlhyi ; localB -> lfqxtpersw
[ 18 ] = a00ih3oxlk ; localB -> lfqxtpersw [ 19 ] = mczrpgw2wm ; localB ->
lfqxtpersw [ 20 ] = aeptep1nip ; localB -> lfqxtpersw [ 21 ] = enff4ghtir ;
localB -> lfqxtpersw [ 22 ] = ij314icd3s ; localB -> lfqxtpersw [ 23 ] =
chjdmyvqxw ; localB -> lfqxtpersw [ 24 ] = kcptdouxiy ; localB -> lfqxtpersw
[ 25 ] = ncqzkqjsi5 ; localB -> lfqxtpersw [ 26 ] = cvk0ncglt2 ; localB ->
lfqxtpersw [ 27 ] = nrlhbcvdrj ; localB -> lfqxtpersw [ 28 ] = * iwup2rjnly ;
localB -> lfqxtpersw [ 29 ] = jk3e44ywwc ; localB -> lfqxtpersw [ 30 ] =
a35hpppuoz ; localB -> lfqxtpersw [ 31 ] = ph0ymmh5bd ; localB -> lfqxtpersw
[ 32 ] = e10q0lhd4i ; localB -> lfqxtpersw [ 33 ] = pznws2ac3n ; localB ->
fb312db3ax [ 0 ] = * patgulbqmk ; localB -> fb312db3ax [ 1 ] = nc2kpvmfsf ;
localB -> fb312db3ax [ 2 ] = elxybvxjvj ; localB -> fb312db3ax [ 3 ] =
nxgzwxhwto ; localB -> fb312db3ax [ 4 ] = ce4aots51j ; localB -> fb312db3ax [
5 ] = c0g12pojmz ; localB -> fb312db3ax [ 6 ] = fvwwfdsk4k ; localB ->
fb312db3ax [ 7 ] = oducigfnlg ; localB -> fb312db3ax [ 8 ] = aaosao0j1p ;
localB -> fb312db3ax [ 9 ] = f2fuje5nkj ; localB -> fb312db3ax [ 10 ] =
bjdyk5yqdr ; localB -> fb312db3ax [ 11 ] = kpf44nicuu ; localB -> fb312db3ax
[ 12 ] = ffpyhdgr2y ; localB -> fb312db3ax [ 13 ] = hwbv55ijok ; localB ->
fb312db3ax [ 14 ] = dexwsni3hm ; localB -> fb312db3ax [ 15 ] = itpvgcv0fr ;
localB -> axapykoqoq [ 0 ] = * patgulbqmk ; localB -> axapykoqoq [ 1 ] =
gfaavtttqm ; localB -> axapykoqoq [ 2 ] = n5olq2bccj ; localB -> axapykoqoq [
3 ] = l0oknvdvkx ; localB -> axapykoqoq [ 4 ] = gu4hswlxp5 ; localB ->
axapykoqoq [ 5 ] = lp5bdiqspv ; localB -> axapykoqoq [ 6 ] = oy4emxdjoh ;
localB -> axapykoqoq [ 7 ] = crno3gqpev ; localB -> axapykoqoq [ 8 ] =
dldnuryub1 ; localB -> axapykoqoq [ 9 ] = auu5ang0o2 ; localB -> axapykoqoq [
10 ] = dyv2j5zovi ; localB -> axapykoqoq [ 11 ] = mmmicydxgc ; localB ->
axapykoqoq [ 12 ] = fikyfswgql ; localB -> axapykoqoq [ 13 ] = gmsc0grzar ;
localB -> axapykoqoq [ 14 ] = axcwfgjptt ; localB -> axapykoqoq [ 15 ] =
f1tqoyuh4d ; localB -> axapykoqoq [ 16 ] = mvjvsasyhj ; localB -> axapykoqoq
[ 17 ] = chhocy4irm ; localB -> axapykoqoq [ 18 ] = a2dyewy3jy ; localB ->
axapykoqoq [ 19 ] = c3b2ezb5i3 ; localB -> axapykoqoq [ 20 ] = bzedi2wtff ;
localB -> axapykoqoq [ 21 ] = psmcmllijr ; localB -> axapykoqoq [ 22 ] =
orjl001kvi ; localB -> axapykoqoq [ 23 ] = jdxksqajpx ; switch ( ( int32_T )
h3wdnrrz3n ) { case 0 : Re = ilffr4btj5 + er0fttewvi ; break ; case 1 :
hyxmtil4ba ( er0fttewvi , djfsfpj4qr , & Re , & b_FzTire ) ; break ; case 2 :
Re = ilffr4btj5 + er0fttewvi ; break ; default : Re = ilffr4btj5 + er0fttewvi
; break ; } b_FzTire = ompv3yyu2t ( ilffr4btj5 , djfsfpj4qr , exb3burec2 ,
rtp_VXLOW , rtp_kappamax ) ; switch ( ( int32_T ) khsfuldvnp ) { case 0 : Fx
= pfjlghkggb ; if ( pfjlghkggb < rtp_FZMIN ) { Fx = rtp_FZMIN ; } if ( Fx >
rtp_FZMAX ) { Fx = rtp_FZMAX ; } Fx_tmp = localB -> d5h53uezna [ 2 ] *
b_FzTire ; Fx = muDoubleScalarSin ( muDoubleScalarAtan ( Fx_tmp - ( Fx_tmp -
muDoubleScalarAtan ( Fx_tmp ) ) * localB -> d5h53uezna [ 3 ] ) * localB ->
d5h53uezna [ 1 ] ) * localB -> d5h53uezna [ 0 ] * ( Fx * localB -> d5h53uezna
[ 4 ] ) ; break ; case 2 : Fx = oraw1x3kwu ( b_FzTire , exb3burec2 ,
pfjlghkggb , localB -> lfqxtpersw [ 0 ] , localB -> lfqxtpersw [ 1 ] , localB
-> lfqxtpersw [ 2 ] , rtp_FZMIN , rtp_FZMAX , localB -> lfqxtpersw [ 3 ] ,
localB -> lfqxtpersw [ 4 ] , localB -> lfqxtpersw [ 5 ] , localB ->
lfqxtpersw [ 6 ] , localB -> lfqxtpersw [ 7 ] , localB -> lfqxtpersw [ 8 ] ,
localB -> lfqxtpersw [ 9 ] , localB -> lfqxtpersw [ 10 ] , localB ->
lfqxtpersw [ 11 ] , localB -> lfqxtpersw [ 12 ] , localB -> lfqxtpersw [ 13 ]
, localB -> lfqxtpersw [ 14 ] , localB -> lfqxtpersw [ 15 ] , localB ->
lfqxtpersw [ 16 ] , localB -> lfqxtpersw [ 17 ] , localB -> lfqxtpersw [ 18 ]
, localB -> lfqxtpersw [ 19 ] , localB -> lfqxtpersw [ 20 ] , localB ->
lfqxtpersw [ 21 ] , localB -> lfqxtpersw [ 22 ] , localB -> lfqxtpersw [ 23 ]
, localB -> lfqxtpersw [ 24 ] , localB -> lfqxtpersw [ 25 ] , localB ->
lfqxtpersw [ 26 ] , localB -> lfqxtpersw [ 27 ] , localB -> lfqxtpersw [ 28 ]
, localB -> lfqxtpersw [ 29 ] , localB -> lfqxtpersw [ 30 ] , localB ->
lfqxtpersw [ 31 ] , localB -> lfqxtpersw [ 32 ] , localB -> lfqxtpersw [ 33 ]
) ; break ; case 3 : Fx = pfjlghkggb ; if ( pfjlghkggb < rtp_FZMIN ) { Fx =
rtp_FZMIN ; } if ( Fx > rtp_FZMAX ) { Fx = rtp_FZMAX ; } for ( i = 0 ; i < 3
; i ++ ) { d3xks5eixq_p [ 3 * i ] = d3xks5eixq [ i ] ; d3xks5eixq_p [ 1 + 3 *
i ] = d3xks5eixq [ i + 3 ] ; d3xks5eixq_p [ 2 + 3 * i ] = d3xks5eixq [ i + 6
] ; } Fx = interp2_rm8DQnLL ( c0lh1c1elq , dpvuosztse , d3xks5eixq_p ,
b_FzTire , Fx ) * localB -> d5h53uezna [ 4 ] ; break ; default : Fx = 0.0 ;
b_FzTire = 0.0 ; break ; } switch ( ( int32_T ) n2xncev0ib ) { case 0 :
localB -> jpw2xvx5f1 = 0.0 ; break ; case 1 : localB -> jpw2xvx5f1 =
frme5sc23i ( pfjlghkggb , djfsfpj4qr , exb3burec2 , localB -> fb312db3ax [ 0
] , localB -> fb312db3ax [ 3 ] , localB -> fb312db3ax [ 4 ] , localB ->
fb312db3ax [ 5 ] , localB -> fb312db3ax [ 9 ] , localB -> fb312db3ax [ 10 ] ,
localB -> fb312db3ax [ 13 ] , rtp_FZMIN , rtp_FZMAX , localB -> fb312db3ax [
14 ] , localB -> fb312db3ax [ 15 ] ) ; break ; case 2 : localB -> jpw2xvx5f1
= njnyloetbl ( Fx , pfjlghkggb , djfsfpj4qr , exb3burec2 , localB ->
fb312db3ax [ 0 ] , localB -> fb312db3ax [ 1 ] , localB -> fb312db3ax [ 2 ] ,
localB -> fb312db3ax [ 3 ] , localB -> fb312db3ax [ 4 ] , localB ->
fb312db3ax [ 5 ] , localB -> fb312db3ax [ 6 ] , localB -> fb312db3ax [ 7 ] ,
localB -> fb312db3ax [ 8 ] , localB -> fb312db3ax [ 9 ] , localB ->
fb312db3ax [ 10 ] , localB -> fb312db3ax [ 11 ] , localB -> fb312db3ax [ 12 ]
, localB -> fb312db3ax [ 13 ] , rtp_FZMAX , localB -> fb312db3ax [ 14 ] ,
localB -> fb312db3ax [ 15 ] ) ; break ; case 3 : Fx_tmp = pfjlghkggb ; if (
pfjlghkggb < 0.0 ) { Fx_tmp = 0.0 ; } if ( Fx_tmp > rtp_FZMAX ) { Fx_tmp =
rtp_FZMAX ; } for ( i = 0 ; i < 3 ; i ++ ) { d3xks5eixq_p [ 3 * i ] =
bkom5ytmqe [ i ] ; d3xks5eixq_p [ 1 + 3 * i ] = bkom5ytmqe [ i + 3 ] ;
d3xks5eixq_p [ 2 + 3 * i ] = bkom5ytmqe [ i + 6 ] ; } localB -> jpw2xvx5f1 =
muDoubleScalarTanh ( djfsfpj4qr ) * interp2_rm8DQnLL ( bjzqtf430o ,
ogihkjapxm , d3xks5eixq_p , exb3burec2 , Fx_tmp ) ; break ; default : localB
-> jpw2xvx5f1 = 0.0 ; break ; } localB -> jufyrxj0jc = Fx ; * jvc4v23k1x =
b_FzTire ; * bwzzfyfbno = Re ; } void bgjvfsnvvf ( pa50wxsaaa * const
hokadafud5 ) { if ( rtmGetTaskTime ( hokadafud5 , 0 ) != rtmGetTStart (
hokadafud5 ) ) { ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } } void iibbapsg2n ( pa50wxsaaa * const hokadafud5 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ; }
void ekmk5spjxa ( pa50wxsaaa * const hokadafud5 , real_T * gpmvtxcsc4 ,
orfasxj0ep * localB , liftzd2mdx * localP ) { if ( rtmIsMajorTimeStep (
hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
pxdy3z0dbu = localP -> P_1 ; } * gpmvtxcsc4 = localB -> pxdy3z0dbu ; } static
void gxcyrp3wtv ( real_T Ftire_x , real_T Ftire_y , real_T b_Fxtire_sat ,
real_T b_Fytire_sat , real_T * Ftire_xs , real_T * Ftire_ys ) { real_T
theta_Ftire ; real_T Ftire_mag ; real_T Ftire_x_max ; real_T Ftire_x_max_tmp
; theta_Ftire = muDoubleScalarAtan2 ( Ftire_x , Ftire_y ) ; Ftire_x_max_tmp =
muDoubleScalarCos ( theta_Ftire ) ; Ftire_x_max = b_Fxtire_sat *
Ftire_x_max_tmp ; theta_Ftire = muDoubleScalarSin ( theta_Ftire ) ; Ftire_mag
= b_Fytire_sat * theta_Ftire ; Ftire_mag = b_Fxtire_sat * b_Fytire_sat /
muDoubleScalarSqrt ( Ftire_x_max * Ftire_x_max + Ftire_mag * Ftire_mag ) ;
Ftire_x_max = Ftire_mag * theta_Ftire ; theta_Ftire = Ftire_mag *
Ftire_x_max_tmp ; * Ftire_xs = Ftire_x ; if ( muDoubleScalarAbs ( Ftire_x ) >
muDoubleScalarAbs ( Ftire_x_max ) ) { * Ftire_xs = Ftire_x_max ; } * Ftire_ys
= Ftire_y ; if ( muDoubleScalarAbs ( Ftire_y ) > muDoubleScalarAbs (
theta_Ftire ) ) { * Ftire_ys = theta_Ftire ; } } void hzczw4rimi ( pa50wxsaaa
* const hokadafud5 , bpefjqedzq * localDW , hcqlainyez * localX ) { localX ->
ltaqjpquzu [ 0 ] = becrktx0d0 . P_261 ; localX -> ltaqjpquzu [ 1 ] =
becrktx0d0 . P_261 ; localX -> ltaqjpquzu [ 2 ] = becrktx0d0 . P_261 ; localX
-> ltaqjpquzu [ 3 ] = becrktx0d0 . P_261 ; localX -> k0pz3tariu = becrktx0d0
. P_263 ; localDW -> pksiahpaaw = becrktx0d0 . P_488 ; if (
rtmIsFirstInitCond ( hokadafud5 ) ) { localX -> asiwx55gg1 [ 0 ] = 0.0 ;
localX -> asiwx55gg1 [ 1 ] = 0.0 ; localX -> asiwx55gg1 [ 2 ] = 0.0 ; localX
-> asiwx55gg1 [ 3 ] = 0.0 ; localX -> azckz4uqjy [ 0 ] = 0.0 ; localX ->
azckz4uqjy [ 1 ] = 0.0 ; } localDW -> bkwexe1kru = 1 ; localX -> gswussrcam =
becrktx0d0 . P_319 ; localDW -> lb1nn0qgui = becrktx0d0 . P_490 ; localX ->
ivyedmn25f = becrktx0d0 . P_370 ; localDW -> gbgapftrxi = becrktx0d0 . P_492
; localX -> gn1qleso4d = becrktx0d0 . P_421 ; localDW -> oywcgos5db =
becrktx0d0 . P_494 ; localDW -> pyrwzbu0vd = 1 ; localX -> afwcyok13n =
becrktx0d0 . P_485 ; localX -> mosvej2yjd = becrktx0d0 . P_486 ; if (
rtmIsFirstInitCond ( hokadafud5 ) ) { localX -> gjqeaf15ke = 0.0 ; } localDW
-> em512f0wkt = 1 ; if ( rtmIsFirstInitCond ( hokadafud5 ) ) { localX ->
bxrckvq45q = 0.0 ; localX -> jg0z2f4dcg = 0.0 ; } localDW -> j0vc5sz3xv = 1 ;
localDW -> puigwz3vsu = 1 ; if ( rtmIsFirstInitCond ( hokadafud5 ) ) { localX
-> efxruepcrz = 0.0 ; } localDW -> cy5d015mtw = 1 ; } void ps1ayp5pv5 (
pa50wxsaaa * const hokadafud5 , bpefjqedzq * localDW , hcqlainyez * localX )
{ localX -> ltaqjpquzu [ 0 ] = becrktx0d0 . P_261 ; localX -> ltaqjpquzu [ 1
] = becrktx0d0 . P_261 ; localX -> ltaqjpquzu [ 2 ] = becrktx0d0 . P_261 ;
localX -> ltaqjpquzu [ 3 ] = becrktx0d0 . P_261 ; localX -> k0pz3tariu =
becrktx0d0 . P_263 ; localDW -> pksiahpaaw = becrktx0d0 . P_488 ; if (
rtmIsFirstInitCond ( hokadafud5 ) ) { localX -> asiwx55gg1 [ 0 ] = 0.0 ;
localX -> asiwx55gg1 [ 1 ] = 0.0 ; localX -> asiwx55gg1 [ 2 ] = 0.0 ; localX
-> asiwx55gg1 [ 3 ] = 0.0 ; localX -> azckz4uqjy [ 0 ] = 0.0 ; localX ->
azckz4uqjy [ 1 ] = 0.0 ; } localDW -> bkwexe1kru = 1 ; localX -> gswussrcam =
becrktx0d0 . P_319 ; localDW -> lb1nn0qgui = becrktx0d0 . P_490 ; localX ->
ivyedmn25f = becrktx0d0 . P_370 ; localDW -> gbgapftrxi = becrktx0d0 . P_492
; localX -> gn1qleso4d = becrktx0d0 . P_421 ; localDW -> oywcgos5db =
becrktx0d0 . P_494 ; localDW -> pyrwzbu0vd = 1 ; localX -> afwcyok13n =
becrktx0d0 . P_485 ; localX -> mosvej2yjd = becrktx0d0 . P_486 ; } void
g3iefm0j4w ( pa50wxsaaa * const hokadafud5 , bpefjqedzq * localDW ,
dn0l2t323g * localXdis ) { switch ( localDW -> hl5oc4enil ) { case 0 :
iibbapsg2n ( hokadafud5 ) ; break ; case 1 :
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ;
localXdis -> gjqeaf15ke = 1 ; break ; } localDW -> hl5oc4enil = - 1 ; switch
( localDW -> ngtk3y0d0k ) { case 0 : iibbapsg2n ( hokadafud5 ) ; break ; case
1 : ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS )
; localXdis -> bxrckvq45q = 1 ; break ; } localDW -> ngtk3y0d0k = - 1 ;
switch ( localDW -> jcq45ux2tw ) { case 0 : iibbapsg2n ( hokadafud5 ) ; break
; case 1 : ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; localXdis -> jg0z2f4dcg = 1 ; break ; } localDW ->
jcq45ux2tw = - 1 ; switch ( localDW -> a4hec4xq23 ) { case 0 : iibbapsg2n (
hokadafud5 ) ; break ; case 1 : ssSetBlockStateForSolverChangedAtMajorStep (
hokadafud5 -> _mdlRefSfcnS ) ; localXdis -> efxruepcrz = 1 ; break ; }
localDW -> a4hec4xq23 = - 1 ; } void aoae4c423r ( real_T * hnk0xxowmm ,
real_T * io1pn0hnwg , real_T * av1e2e2zlq , real_T * amgwfcyfmi , real_T *
hzkodf3i3c , real_T g2tnztcpzi [ 4 ] , id4lpjcjia * localB , bpefjqedzq *
localDW ) { localB -> bs2hjc5nu2 = becrktx0d0 . P_152 ; localDW -> eezel21inu
= true ; localDW -> hl5oc4enil = - 1 ; * io1pn0hnwg = becrktx0d0 . P_272 ; *
hnk0xxowmm = becrktx0d0 . P_273 ; localB -> dcwkj3tspn [ 0 ] = becrktx0d0 .
P_284 [ 0 ] ; localB -> agcbzjjxc2 [ 0 ] = becrktx0d0 . P_285 [ 0 ] ; localB
-> dcwkj3tspn [ 1 ] = becrktx0d0 . P_284 [ 1 ] ; localB -> agcbzjjxc2 [ 1 ] =
becrktx0d0 . P_285 [ 1 ] ; localB -> dcwkj3tspn [ 2 ] = becrktx0d0 . P_284 [
2 ] ; localB -> agcbzjjxc2 [ 2 ] = becrktx0d0 . P_285 [ 2 ] ; localB ->
dn24fdverp [ 0 ] = becrktx0d0 . P_289 [ 0 ] ; localB -> mpurjwwdjq [ 0 ] =
becrktx0d0 . P_290 [ 0 ] ; localB -> dn24fdverp [ 1 ] = becrktx0d0 . P_289 [
1 ] ; localB -> mpurjwwdjq [ 1 ] = becrktx0d0 . P_290 [ 1 ] ; localB ->
dn24fdverp [ 2 ] = becrktx0d0 . P_289 [ 2 ] ; localB -> mpurjwwdjq [ 2 ] =
becrktx0d0 . P_290 [ 2 ] ; memcpy ( & localB -> fblkngoubr [ 0 ] , &
becrktx0d0 . P_286 [ 0 ] , 9U * sizeof ( real_T ) ) ; memcpy ( & localB ->
a5hv2ji3cc [ 0 ] , & becrktx0d0 . P_291 [ 0 ] , 9U * sizeof ( real_T ) ) ;
localB -> pxbcgurxxp = becrktx0d0 . P_315 ; localB -> d3b0uleyfa = becrktx0d0
. P_316 ; localB -> gssojkvg2t = becrktx0d0 . P_317 ; localB -> kihaqcuhgw =
becrktx0d0 . P_153 ; localDW -> gmuarwd0x2 = true ; localDW -> ngtk3y0d0k = -
1 ; localB -> n4bp4zjfwv [ 0 ] = becrktx0d0 . P_335 [ 0 ] ; localB ->
frm4syq440 [ 0 ] = becrktx0d0 . P_336 [ 0 ] ; localB -> n4bp4zjfwv [ 1 ] =
becrktx0d0 . P_335 [ 1 ] ; localB -> frm4syq440 [ 1 ] = becrktx0d0 . P_336 [
1 ] ; localB -> n4bp4zjfwv [ 2 ] = becrktx0d0 . P_335 [ 2 ] ; localB ->
frm4syq440 [ 2 ] = becrktx0d0 . P_336 [ 2 ] ; localB -> crkky0j4wi [ 0 ] =
becrktx0d0 . P_340 [ 0 ] ; localB -> oc3syc1had [ 0 ] = becrktx0d0 . P_341 [
0 ] ; localB -> crkky0j4wi [ 1 ] = becrktx0d0 . P_340 [ 1 ] ; localB ->
oc3syc1had [ 1 ] = becrktx0d0 . P_341 [ 1 ] ; localB -> crkky0j4wi [ 2 ] =
becrktx0d0 . P_340 [ 2 ] ; localB -> oc3syc1had [ 2 ] = becrktx0d0 . P_341 [
2 ] ; memcpy ( & localB -> d2yrhfqtgt [ 0 ] , & becrktx0d0 . P_337 [ 0 ] , 9U
* sizeof ( real_T ) ) ; memcpy ( & localB -> momgprkjbh [ 0 ] , & becrktx0d0
. P_342 [ 0 ] , 9U * sizeof ( real_T ) ) ; localB -> lbmhaqyph2 = becrktx0d0
. P_366 ; localB -> d2sicg5t5v = becrktx0d0 . P_367 ; localB -> ddkgx3utjf =
becrktx0d0 . P_368 ; localB -> jqra0qrc4f = becrktx0d0 . P_154 ; localDW ->
axwzh0jhgp = true ; localDW -> jcq45ux2tw = - 1 ; localB -> gzjvzppbfb [ 0 ]
= becrktx0d0 . P_386 [ 0 ] ; localB -> bwdfn5yr4y [ 0 ] = becrktx0d0 . P_387
[ 0 ] ; localB -> gzjvzppbfb [ 1 ] = becrktx0d0 . P_386 [ 1 ] ; localB ->
bwdfn5yr4y [ 1 ] = becrktx0d0 . P_387 [ 1 ] ; localB -> gzjvzppbfb [ 2 ] =
becrktx0d0 . P_386 [ 2 ] ; localB -> bwdfn5yr4y [ 2 ] = becrktx0d0 . P_387 [
2 ] ; localB -> odtlbjxf5w [ 0 ] = becrktx0d0 . P_391 [ 0 ] ; localB ->
pwd3yzcihq [ 0 ] = becrktx0d0 . P_392 [ 0 ] ; localB -> odtlbjxf5w [ 1 ] =
becrktx0d0 . P_391 [ 1 ] ; localB -> pwd3yzcihq [ 1 ] = becrktx0d0 . P_392 [
1 ] ; localB -> odtlbjxf5w [ 2 ] = becrktx0d0 . P_391 [ 2 ] ; localB ->
pwd3yzcihq [ 2 ] = becrktx0d0 . P_392 [ 2 ] ; memcpy ( & localB -> bdxkllszng
[ 0 ] , & becrktx0d0 . P_388 [ 0 ] , 9U * sizeof ( real_T ) ) ; memcpy ( &
localB -> d0ll0sez0n [ 0 ] , & becrktx0d0 . P_393 [ 0 ] , 9U * sizeof (
real_T ) ) ; localB -> i3rgk5at5k = becrktx0d0 . P_417 ; localB -> g1zar4icoz
= becrktx0d0 . P_418 ; localB -> byvynht2aq = becrktx0d0 . P_419 ; localB ->
edkbwlt3se = becrktx0d0 . P_155 ; localDW -> a001iqqtdq = true ; localDW ->
a4hec4xq23 = - 1 ; localB -> if32pa3y2y [ 0 ] = becrktx0d0 . P_437 [ 0 ] ;
localB -> bxgniuki54 [ 0 ] = becrktx0d0 . P_438 [ 0 ] ; localB -> if32pa3y2y
[ 1 ] = becrktx0d0 . P_437 [ 1 ] ; localB -> bxgniuki54 [ 1 ] = becrktx0d0 .
P_438 [ 1 ] ; localB -> if32pa3y2y [ 2 ] = becrktx0d0 . P_437 [ 2 ] ; localB
-> bxgniuki54 [ 2 ] = becrktx0d0 . P_438 [ 2 ] ; localB -> jlcsqepfsn [ 0 ] =
becrktx0d0 . P_442 [ 0 ] ; localB -> dnkaqrpiwe [ 0 ] = becrktx0d0 . P_443 [
0 ] ; localB -> jlcsqepfsn [ 1 ] = becrktx0d0 . P_442 [ 1 ] ; localB ->
dnkaqrpiwe [ 1 ] = becrktx0d0 . P_443 [ 1 ] ; localB -> jlcsqepfsn [ 2 ] =
becrktx0d0 . P_442 [ 2 ] ; localB -> dnkaqrpiwe [ 2 ] = becrktx0d0 . P_443 [
2 ] ; memcpy ( & localB -> hn1eupnvah [ 0 ] , & becrktx0d0 . P_439 [ 0 ] , 9U
* sizeof ( real_T ) ) ; memcpy ( & localB -> og1pl52b0g [ 0 ] , & becrktx0d0
. P_444 [ 0 ] , 9U * sizeof ( real_T ) ) ; localB -> jbiokc52mb = becrktx0d0
. P_468 ; localB -> bdgo5lorke = becrktx0d0 . P_469 ; localB -> lmed21unhr =
becrktx0d0 . P_470 ; localDW -> jp5udlopwm = 0 ; localB -> op20eyqhn0 =
becrktx0d0 . P_5 ; localB -> pj112y04hg = becrktx0d0 . P_6 ; * av1e2e2zlq =
becrktx0d0 . P_482 ; * hzkodf3i3c = becrktx0d0 . P_483 ; * amgwfcyfmi =
becrktx0d0 . P_484 ; g2tnztcpzi [ 0 ] = becrktx0d0 . P_487 [ 0 ] ; g2tnztcpzi
[ 1 ] = becrktx0d0 . P_487 [ 1 ] ; g2tnztcpzi [ 2 ] = becrktx0d0 . P_487 [ 2
] ; g2tnztcpzi [ 3 ] = becrktx0d0 . P_487 [ 3 ] ; } void PassVeh7DOF (
pa50wxsaaa * const hokadafud5 , const real_T fo3cvtmfih [ 4 ] , const real_T
dfx1ca0pmi [ 4 ] , const real_T pf4xf35zus [ 3 ] , const real_T gxlrb30ei4 [
4 ] , const real_T bv2zp3o4ji [ 4 ] , const real_T czlc2qmxmx [ 4 ] , real_T
* lfffcfi0vv , real_T * o4a5winsib , real_T * c040sjjy2f , real_T *
hnk0xxowmm , real_T * io1pn0hnwg , real_T * hb0nga1cnl , real_T cyqteuatay [
4 ] , real_T av2ap4nkgj [ 4 ] , real_T * cqivd3kemx , real_T * n0fjwjtmw3 ,
real_T * dfywnyxbtq , real_T * av1e2e2zlq , real_T * pu1mlebux4 , real_T *
hxjzroc5ux , real_T * amgwfcyfmi , real_T * hzkodf3i3c , real_T eueb01ol1w [
4 ] , real_T g2tnztcpzi [ 4 ] , real_T ebhsrqq1o4 [ 4 ] , real_T eplypn1mx4 [
4 ] , id4lpjcjia * localB , bpefjqedzq * localDW , hcqlainyez * localX ,
pcbmq2m11v * localZCE , dn0l2t323g * localXdis ) { real_T n4z4intnf3 [ 4 ] ;
int32_T eufvenxnxf ; ZCEventType zcEvent ; real_T Fy_f ; real_T Fy_r ; real_T
Fx_ft ; real_T Fy_ft ; real_T Fx_rt ; real_T z_data ; real_T z1_data ; int8_T
rtPrevAction ; int8_T rtAction ; real_T ht543eszrl [ 3 ] ; real_T
ft2a2rkagw_p ; real_T ittjpgmzbj_p ; real_T etj3o5lltd_p ; real_T
orehnlu50o_p ; real_T igexdtwng4_p [ 12 ] ; real_T kofgmkkx4p_p ; real_T
okrrl0uxrk_p ; real_T i2orjcd5ae_p ; real_T fi5veravxh_p [ 3 ] ; real_T
c2xse5ydzd_p [ 6 ] ; real_T a0u2l1bnv1_p [ 9 ] ; real_T jfanoozha1_p [ 12 ] ;
int32_T i ; int32_T loop_ub ; int32_T i_p ; real_T a0u2l1bnv1_e [ 3 ] ;
real_T emippuzm0l_p ; real_T cj3txzi5fm_idx_0 ; real_T cj3txzi5fm_idx_1 ;
real_T cj3txzi5fm_idx_2 ; real_T hiwzfcmaid_idx_1 ; real_T dyojl213t2_idx_0 ;
real_T dyojl213t2_idx_1 ; real_T dyojl213t2_idx_2 ; real_T dyojl213t2_idx_3 ;
real_T kglfuzmg0r_idx_0 ; real_T kglfuzmg0r_idx_1 ; real_T kglfuzmg0r_idx_2 ;
real_T kglfuzmg0r_idx_3 ; real_T i53l3q5jej_idx_1 ; real_T i53l3q5jej_idx_2 ;
real_T Fz_idx_0 ; real_T Fz_idx_1 ; int32_T d1dypaa5pk_idx_2_tmp ;
dyojl213t2_idx_0 = localX -> ltaqjpquzu [ 0 ] ; dyojl213t2_idx_1 = localX ->
ltaqjpquzu [ 1 ] ; dyojl213t2_idx_2 = localX -> ltaqjpquzu [ 2 ] ;
dyojl213t2_idx_3 = localX -> ltaqjpquzu [ 3 ] ; if ( rtmIsMajorTimeStep (
hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
bs2hjc5nu2 = becrktx0d0 . P_152 ; zcEvent = rt_ZCFcn ( ANY_ZERO_CROSSING , &
localZCE -> prsm11mhyx , ( localX -> gjqeaf15ke - becrktx0d0 . P_262 ) ) ; if
( localDW -> aixbqjjzjt == 0 ) { if ( zcEvent != NO_ZCEVENT ) { localB ->
dt0bwnq1k5 = ! localB -> dt0bwnq1k5 ; localDW -> aixbqjjzjt = 1 ; } else if (
localB -> dt0bwnq1k5 ) { if ( localX -> gjqeaf15ke != becrktx0d0 . P_262 ) {
localB -> dt0bwnq1k5 = false ; } } else { if ( localX -> gjqeaf15ke ==
becrktx0d0 . P_262 ) { localB -> dt0bwnq1k5 = true ; } } } else { if ( localX
-> gjqeaf15ke != becrktx0d0 . P_262 ) { localB -> dt0bwnq1k5 = false ; }
localDW -> aixbqjjzjt = 0 ; } localB -> ifttpgshqd = becrktx0d0 . P_152 ; }
ft2a2rkagw_p = localX -> k0pz3tariu ; ittjpgmzbj_p = ( fo3cvtmfih [ 0 ] -
localX -> k0pz3tariu * localB -> ifttpgshqd ) * becrktx0d0 . P_264 ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> euk3scwzss = becrktx0d0 . P_179 ; localB -> libbr311cm =
becrktx0d0 . P_265 * localB -> euk3scwzss ; localB -> obpqast420 = becrktx0d0
. P_234 ; } localB -> fp2ilc0ley = dfx1ca0pmi [ 0 ] * localB -> libbr311cm *
localB -> euk3scwzss * localB -> obpqast420 ; if ( rtmIsMajorTimeStep (
hokadafud5 ) ) { localDW -> iorqcjlmnb = localB -> fp2ilc0ley >= becrktx0d0 .
P_266 ? 1 : localB -> fp2ilc0ley > becrktx0d0 . P_267 ? 0 : - 1 ; }
etj3o5lltd_p = becrktx0d0 . P_156 * becrktx0d0 . P_226 * ( localDW ->
iorqcjlmnb == 1 ? becrktx0d0 . P_266 : localDW -> iorqcjlmnb == - 1 ?
becrktx0d0 . P_267 : localB -> fp2ilc0ley ) ; orehnlu50o_p = becrktx0d0 .
P_230 / becrktx0d0 . P_226 * etj3o5lltd_p ; if ( rtmIsMajorTimeStep (
hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
n4xonjocfu = becrktx0d0 . P_174 * becrktx0d0 . P_268 ; localB -> hm4gocqk3h =
localDW -> pksiahpaaw ; } localB -> g33vvsnq3o = becrktx0d0 . P_489 [ ( ( (
muDoubleScalarAbs ( ( ( 0.0 - ittjpgmzbj_p ) - localB -> n4xonjocfu ) +
localB -> n4xonjocfu ) >= orehnlu50o_p ) + ( ( uint32_T ) ( localB ->
dt0bwnq1k5 && ( muDoubleScalarAbs ( - ittjpgmzbj_p ) <= orehnlu50o_p ) ) << 1
) ) << 1 ) + localB -> hm4gocqk3h ] ; if ( rtmIsMajorTimeStep ( hokadafud5 )
&& rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { if ( localDW -> eezel21inu ) {
localDW -> eezel21inu = false ; orehnlu50o_p = becrktx0d0 . P_270 ; } else {
orehnlu50o_p = becrktx0d0 . P_269 ; } if ( orehnlu50o_p > becrktx0d0 . P_271
) { localB -> auwfmt1imw = becrktx0d0 . P_268 ; } else { localB -> auwfmt1imw
= becrktx0d0 . P_238 ; } } rtPrevAction = localDW -> hl5oc4enil ; if (
rtmIsMajorTimeStep ( hokadafud5 ) ) { rtAction = ( int8_T ) ! localB ->
g33vvsnq3o ; localDW -> hl5oc4enil = rtAction ; } else { rtAction = localDW
-> hl5oc4enil ; } if ( rtPrevAction != rtAction ) { switch ( rtPrevAction ) {
case 0 : iibbapsg2n ( hokadafud5 ) ; break ; case 1 :
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ;
localXdis -> gjqeaf15ke = 1 ; break ; } } switch ( rtAction ) { case 0 : if (
rtAction != rtPrevAction ) { bgjvfsnvvf ( hokadafud5 ) ; } ekmk5spjxa (
hokadafud5 , & localB -> jm1o4v20ho , & localB -> ekmk5spjxa3 , & becrktx0d0
. ekmk5spjxa3 ) ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { srUpdateBC (
localDW -> ekmk5spjxa3 . dygl2vbtcr ) ; } break ; case 1 : if ( rtAction !=
rtPrevAction ) { if ( rtmIsFirstInitCond ( hokadafud5 ) ) { localX ->
gjqeaf15ke = 0.0 ; } localDW -> em512f0wkt = 1 ; if ( rtmGetTaskTime (
hokadafud5 , 0 ) != rtmGetTStart ( hokadafud5 ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ; }
localXdis -> gjqeaf15ke = 0 ; } if ( localDW -> em512f0wkt != 0 ) { localX ->
gjqeaf15ke = localB -> auwfmt1imw ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } localB -> co0vgrhgxv = ( ( muDoubleScalarTanh ( becrktx0d0
. P_251 * localX -> gjqeaf15ke ) * etj3o5lltd_p - ittjpgmzbj_p ) - becrktx0d0
. P_174 * localX -> gjqeaf15ke ) * ( 1.0 / becrktx0d0 . P_21 ) ; localB ->
jm1o4v20ho = localX -> gjqeaf15ke ; if ( rtmIsMajorTimeStep ( hokadafud5 ) )
{ srUpdateBC ( localDW -> hk0nfz3tiy ) ; } break ; } if ( rtmIsMajorTimeStep
( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { * io1pn0hnwg =
becrktx0d0 . P_272 ; localB -> m5n5c0hsov [ 0 ] = becrktx0d0 . P_171 ; localB
-> m5n5c0hsov [ 1 ] = becrktx0d0 . P_150 ; localB -> m5n5c0hsov [ 2 ] =
becrktx0d0 . P_188 ; localB -> jmb25suz33 = * io1pn0hnwg * localB ->
m5n5c0hsov [ 2 ] ; localB -> j2p04sytqr [ 0 ] = becrktx0d0 . P_247 ; localB
-> j2p04sytqr [ 1 ] = becrktx0d0 . P_249 ; localB -> j2p04sytqr [ 2 ] =
becrktx0d0 . P_242 ; localB -> j2p04sytqr [ 3 ] = becrktx0d0 . P_243 ; } if (
localDW -> bkwexe1kru != 0 ) { localX -> asiwx55gg1 [ 0 ] = localB ->
j2p04sytqr [ 0 ] ; localX -> asiwx55gg1 [ 1 ] = localB -> j2p04sytqr [ 1 ] ;
localX -> asiwx55gg1 [ 2 ] = localB -> j2p04sytqr [ 2 ] ; localX ->
asiwx55gg1 [ 3 ] = localB -> j2p04sytqr [ 3 ] ; } kglfuzmg0r_idx_0 = localX
-> asiwx55gg1 [ 0 ] ; kglfuzmg0r_idx_1 = localX -> asiwx55gg1 [ 1 ] ;
kglfuzmg0r_idx_2 = localX -> asiwx55gg1 [ 2 ] ; kglfuzmg0r_idx_3 = localX ->
asiwx55gg1 [ 3 ] ; if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit (
hokadafud5 , 1 , 0 ) ) { * hnk0xxowmm = becrktx0d0 . P_273 ; localB ->
l4pg5xpxp1 = * hnk0xxowmm * localB -> m5n5c0hsov [ 1 ] ; localB -> m4npe54j1c
= * hnk0xxowmm * localB -> m5n5c0hsov [ 2 ] ; localB -> eyxanztqx1 = *
io1pn0hnwg * localB -> m5n5c0hsov [ 0 ] ; localB -> lcls111zdy = becrktx0d0 .
P_274 ; localB -> o0rhvekxea [ 0 ] = - becrktx0d0 . P_172 ; localB ->
o0rhvekxea [ 1 ] = becrktx0d0 . P_151 ; localB -> o0rhvekxea [ 2 ] =
becrktx0d0 . P_188 ; localB -> fvqfpke4jv = * io1pn0hnwg * localB ->
o0rhvekxea [ 2 ] ; localB -> bjsj1dfvfu = * hnk0xxowmm * localB -> o0rhvekxea
[ 1 ] ; localB -> aq2vnamn3e = * hnk0xxowmm * localB -> o0rhvekxea [ 2 ] ;
localB -> nquucjysva = * io1pn0hnwg * localB -> o0rhvekxea [ 0 ] ; }
etj3o5lltd_p = ( localB -> jmb25suz33 - localX -> asiwx55gg1 [ 3 ] * localB
-> m5n5c0hsov [ 1 ] ) + localX -> asiwx55gg1 [ 0 ] ; ittjpgmzbj_p = ( localX
-> asiwx55gg1 [ 3 ] * localB -> m5n5c0hsov [ 0 ] - localB -> m4npe54j1c ) +
localX -> asiwx55gg1 [ 1 ] ; orehnlu50o_p = ( localB -> l4pg5xpxp1 - localB
-> eyxanztqx1 ) + localB -> lcls111zdy ; igexdtwng4_p [ 0 ] = etj3o5lltd_p ;
igexdtwng4_p [ 3 ] = etj3o5lltd_p ; igexdtwng4_p [ 1 ] = ittjpgmzbj_p ;
igexdtwng4_p [ 4 ] = ittjpgmzbj_p ; igexdtwng4_p [ 2 ] = orehnlu50o_p ;
igexdtwng4_p [ 5 ] = orehnlu50o_p ; etj3o5lltd_p = ( localB -> fvqfpke4jv -
localX -> asiwx55gg1 [ 3 ] * localB -> o0rhvekxea [ 1 ] ) + localX ->
asiwx55gg1 [ 0 ] ; ittjpgmzbj_p = ( localX -> asiwx55gg1 [ 3 ] * localB ->
o0rhvekxea [ 0 ] - localB -> aq2vnamn3e ) + localX -> asiwx55gg1 [ 1 ] ;
orehnlu50o_p = ( localB -> bjsj1dfvfu - localB -> nquucjysva ) + localB ->
lcls111zdy ; igexdtwng4_p [ 6 ] = etj3o5lltd_p ; igexdtwng4_p [ 9 ] =
etj3o5lltd_p ; igexdtwng4_p [ 7 ] = ittjpgmzbj_p ; igexdtwng4_p [ 10 ] =
ittjpgmzbj_p ; igexdtwng4_p [ 8 ] = orehnlu50o_p ; igexdtwng4_p [ 11 ] =
orehnlu50o_p ; if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit (
hokadafud5 , 1 , 0 ) ) { localB -> pq0pomxlsc [ 0 ] = becrktx0d0 . P_275 [ 0
] ; localB -> msli3xjzd4 [ 0 ] = becrktx0d0 . P_178 ; localB -> pq0pomxlsc [
1 ] = becrktx0d0 . P_275 [ 1 ] ; localB -> msli3xjzd4 [ 1 ] = becrktx0d0 .
P_178 ; localB -> pq0pomxlsc [ 2 ] = becrktx0d0 . P_275 [ 2 ] ; localB ->
msli3xjzd4 [ 2 ] = becrktx0d0 . P_178 ; localB -> pq0pomxlsc [ 3 ] =
becrktx0d0 . P_275 [ 3 ] ; localB -> msli3xjzd4 [ 3 ] = becrktx0d0 . P_178 ;
localB -> nfqf4trzat = becrktx0d0 . P_276 ; } jfanoozha1_p [ 0 ] = localB ->
pq0pomxlsc [ 0 ] ; jfanoozha1_p [ 1 ] = localB -> msli3xjzd4 [ 0 ] ;
jfanoozha1_p [ 2 ] = gxlrb30ei4 [ 0 ] ; jfanoozha1_p [ 3 ] = localB ->
pq0pomxlsc [ 1 ] ; jfanoozha1_p [ 4 ] = localB -> msli3xjzd4 [ 1 ] ;
jfanoozha1_p [ 5 ] = gxlrb30ei4 [ 1 ] + localB -> nfqf4trzat ; jfanoozha1_p [
6 ] = localB -> pq0pomxlsc [ 2 ] ; jfanoozha1_p [ 7 ] = localB -> msli3xjzd4
[ 2 ] ; jfanoozha1_p [ 8 ] = gxlrb30ei4 [ 2 ] ; jfanoozha1_p [ 9 ] = localB
-> pq0pomxlsc [ 3 ] ; jfanoozha1_p [ 10 ] = localB -> msli3xjzd4 [ 3 ] ;
jfanoozha1_p [ 11 ] = gxlrb30ei4 [ 3 ] + localB -> nfqf4trzat ; for (
eufvenxnxf = 0 ; eufvenxnxf < 4 ; eufvenxnxf ++ ) { etj3o5lltd_p =
jfanoozha1_p [ 3 * eufvenxnxf ] ; loop_ub = 3 * eufvenxnxf + 1 ;
d1dypaa5pk_idx_2_tmp = 3 * eufvenxnxf + 2 ; okrrl0uxrk_p = igexdtwng4_p [ 3 *
eufvenxnxf ] ; i = 3 * eufvenxnxf + 1 ; i_p = 3 * eufvenxnxf + 2 ;
muDoubleScalarSinCos ( jfanoozha1_p [ d1dypaa5pk_idx_2_tmp ] , & fi5veravxh_p
[ 0 ] , & orehnlu50o_p ) ; muDoubleScalarSinCos ( jfanoozha1_p [ loop_ub ] ,
& fi5veravxh_p [ 1 ] , & cj3txzi5fm_idx_2 ) ; muDoubleScalarSinCos (
etj3o5lltd_p , & fi5veravxh_p [ 2 ] , & ittjpgmzbj_p ) ; a0u2l1bnv1_p [ 0 ] =
cj3txzi5fm_idx_2 * orehnlu50o_p ; cj3txzi5fm_idx_0 = fi5veravxh_p [ 2 ] *
fi5veravxh_p [ 1 ] ; a0u2l1bnv1_p [ 1 ] = cj3txzi5fm_idx_0 * orehnlu50o_p -
ittjpgmzbj_p * fi5veravxh_p [ 0 ] ; kofgmkkx4p_p = ittjpgmzbj_p *
fi5veravxh_p [ 1 ] ; a0u2l1bnv1_p [ 2 ] = kofgmkkx4p_p * orehnlu50o_p +
fi5veravxh_p [ 2 ] * fi5veravxh_p [ 0 ] ; a0u2l1bnv1_p [ 3 ] =
cj3txzi5fm_idx_2 * fi5veravxh_p [ 0 ] ; a0u2l1bnv1_p [ 4 ] = cj3txzi5fm_idx_0
* fi5veravxh_p [ 0 ] + ittjpgmzbj_p * orehnlu50o_p ; a0u2l1bnv1_p [ 5 ] =
kofgmkkx4p_p * fi5veravxh_p [ 0 ] - fi5veravxh_p [ 2 ] * orehnlu50o_p ;
a0u2l1bnv1_p [ 6 ] = - fi5veravxh_p [ 1 ] ; a0u2l1bnv1_p [ 7 ] = fi5veravxh_p
[ 2 ] * cj3txzi5fm_idx_2 ; a0u2l1bnv1_p [ 8 ] = ittjpgmzbj_p *
cj3txzi5fm_idx_2 ; for ( loop_ub = 0 ; loop_ub < 3 ; loop_ub ++ ) {
a0u2l1bnv1_e [ loop_ub ] = a0u2l1bnv1_p [ loop_ub + 6 ] * igexdtwng4_p [ i_p
] + ( a0u2l1bnv1_p [ loop_ub + 3 ] * igexdtwng4_p [ i ] + a0u2l1bnv1_p [
loop_ub ] * okrrl0uxrk_p ) ; } localB -> fp0lz1z3pw [ eufvenxnxf ] =
a0u2l1bnv1_e [ 0 ] ; } if ( rtmIsMajorTimeStep ( hokadafud5 ) &&
rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB -> e2x3r2jeks = becrktx0d0 .
P_277 ; localB -> jsbuy1s0zh = becrktx0d0 . P_278 ; localB -> jlqqks3wuo =
becrktx0d0 . P_279 ; localB -> iolwkpz04u = becrktx0d0 . P_280 ; localB ->
mjrra1hfyg = becrktx0d0 . P_281 ; localB -> dae0zhs5fy = becrktx0d0 . P_184 ;
localB -> jp2tjiwtwu = becrktx0d0 . P_26 ; localB -> ann1feexvg = becrktx0d0
. P_8 ; localB -> jkq3y0qfgv = becrktx0d0 . P_35 ; localB -> c2j5gkccdm =
becrktx0d0 . P_282 ; localB -> ard44y2p1h = becrktx0d0 . P_283 ; localB ->
iof1dhclh2 = becrktx0d0 . P_40 ; localB -> fqwn3oyjo3 = becrktx0d0 . P_44 ;
localB -> jrtvmmjxei = becrktx0d0 . P_48 ; localB -> gjz1ie5un1 = becrktx0d0
. P_52 ; localB -> lbp4dfbob0 = becrktx0d0 . P_56 ; localB -> hv1i03vcrx =
becrktx0d0 . P_60 ; localB -> eftgclmxsy = becrktx0d0 . P_64 ; localB ->
b2a12dteat = becrktx0d0 . P_68 ; localB -> lsasi2uldc = becrktx0d0 . P_80 ;
localB -> g5agc0xg32 = becrktx0d0 . P_84 ; localB -> hooc103vyj = becrktx0d0
. P_88 ; localB -> eeb3auw5nx = becrktx0d0 . P_72 ; localB -> ek12timuyq =
becrktx0d0 . P_76 ; localB -> g2srpjb4za = becrktx0d0 . P_108 ; localB ->
ky55fcx12u = becrktx0d0 . P_112 ; localB -> lli4msildn = becrktx0d0 . P_92 ;
localB -> ekonhtwtew = becrktx0d0 . P_96 ; localB -> kzdtcoisvi = becrktx0d0
. P_100 ; localB -> ivswn3mcce = becrktx0d0 . P_104 ; localB -> klywadtuwk =
becrktx0d0 . P_201 ; localB -> bc5mpnnywl = becrktx0d0 . P_221 ; localB ->
p4dxuexhmn = becrktx0d0 . P_209 ; localB -> dgacotjrc4 = becrktx0d0 . P_193 ;
localB -> opivgwwsqb = becrktx0d0 . P_197 ; localB -> abpryvvknk = becrktx0d0
. P_205 ; localB -> kkloewbxvk = becrktx0d0 . P_217 ; localB -> dcwkj3tspn [
0 ] = becrktx0d0 . P_284 [ 0 ] ; localB -> agcbzjjxc2 [ 0 ] = becrktx0d0 .
P_285 [ 0 ] ; localB -> dcwkj3tspn [ 1 ] = becrktx0d0 . P_284 [ 1 ] ; localB
-> agcbzjjxc2 [ 1 ] = becrktx0d0 . P_285 [ 1 ] ; localB -> dcwkj3tspn [ 2 ] =
becrktx0d0 . P_284 [ 2 ] ; localB -> agcbzjjxc2 [ 2 ] = becrktx0d0 . P_285 [
2 ] ; localB -> bgbdvzlrnp = becrktx0d0 . P_8 ; localB -> ei3jjsazbv =
becrktx0d0 . P_35 ; localB -> l1sbdzlbft = becrktx0d0 . P_117 ; localB ->
hrdyz2htuu = becrktx0d0 . P_121 ; localB -> g22rfrhcci = becrktx0d0 . P_125 ;
localB -> d51egdrz0z = becrktx0d0 . P_129 ; localB -> gmqaszorzp = becrktx0d0
. P_133 ; localB -> pu4cguusa5 = becrktx0d0 . P_137 ; localB -> hawqte0lkp =
becrktx0d0 . P_141 ; localB -> fqfqbihpo4 = becrktx0d0 . P_145 ; localB ->
fcmrvrr5m4 = becrktx0d0 . P_184 ; localB -> aewmk31j2l = becrktx0d0 . P_213 ;
localB -> ilblxiaesg = becrktx0d0 . P_161 ; localB -> csbz5vwjbl = becrktx0d0
. P_287 ; localB -> efotijbqgm = becrktx0d0 . P_288 ; localB -> dn24fdverp [
0 ] = becrktx0d0 . P_289 [ 0 ] ; localB -> mpurjwwdjq [ 0 ] = becrktx0d0 .
P_290 [ 0 ] ; localB -> dn24fdverp [ 1 ] = becrktx0d0 . P_289 [ 1 ] ; localB
-> mpurjwwdjq [ 1 ] = becrktx0d0 . P_290 [ 1 ] ; localB -> dn24fdverp [ 2 ] =
becrktx0d0 . P_289 [ 2 ] ; localB -> mpurjwwdjq [ 2 ] = becrktx0d0 . P_290 [
2 ] ; memcpy ( & localB -> fblkngoubr [ 0 ] , & becrktx0d0 . P_286 [ 0 ] , 9U
* sizeof ( real_T ) ) ; memcpy ( & localB -> a5hv2ji3cc [ 0 ] , & becrktx0d0
. P_291 [ 0 ] , 9U * sizeof ( real_T ) ) ; localB -> fkg40b3zq2 = becrktx0d0
. P_292 ; localB -> amzgulqp12 = becrktx0d0 . P_293 ; localB -> ijjphmn2q0 =
becrktx0d0 . P_294 ; localB -> hu5pmd13z1 = becrktx0d0 . P_295 ; localB ->
nfnujv3tc2 = becrktx0d0 . P_296 ; localB -> mqhdsdepts = becrktx0d0 . P_297 ;
localB -> igbd4extak = becrktx0d0 . P_298 ; localB -> onrl0wpwlm = becrktx0d0
. P_299 ; localB -> bonsvi0den = becrktx0d0 . P_300 ; localB -> pe2ebnzhq4 =
becrktx0d0 . P_301 ; localB -> isr01bpmsd = becrktx0d0 . P_302 ; localB ->
glwizfkrzi = becrktx0d0 . P_303 ; localB -> j0032htb5y = becrktx0d0 . P_304 ;
localB -> fmvdhgj0c5 = becrktx0d0 . P_305 ; localB -> obgyaeas1p = becrktx0d0
. P_306 ; localB -> jm54t5nyht = becrktx0d0 . P_307 ; localB -> am0wr3vakl =
becrktx0d0 . P_308 ; localB -> hbjg5ycjap = becrktx0d0 . P_309 ; localB ->
flo2k44qyj = becrktx0d0 . P_310 ; localB -> fsb2e41l0m = becrktx0d0 . P_311 ;
localB -> m2xjbusmco = becrktx0d0 . P_312 ; localB -> lhyhzghz5g = becrktx0d0
. P_313 ; localB -> ldco5bshns = becrktx0d0 . P_314 ; localB -> pxbcgurxxp =
becrktx0d0 . P_315 ; localB -> d3b0uleyfa = becrktx0d0 . P_316 ; localB ->
gssojkvg2t = becrktx0d0 . P_317 ; } hor3rithbp ( localB -> bs2hjc5nu2 ,
dyojl213t2_idx_0 , localB -> jm1o4v20ho , localB -> fp0lz1z3pw [ 0 ] , localB
-> e2x3r2jeks , localB -> jsbuy1s0zh , localB -> jlqqks3wuo , localB ->
iolwkpz04u , localB -> mjrra1hfyg , localB -> dae0zhs5fy , localB ->
jp2tjiwtwu , localB -> ann1feexvg , & bv2zp3o4ji [ 0 ] , localB -> jkq3y0qfgv
, localB -> c2j5gkccdm , localB -> ard44y2p1h , localB -> iof1dhclh2 , localB
-> fqwn3oyjo3 , localB -> jrtvmmjxei , localB -> gjz1ie5un1 , localB ->
lbp4dfbob0 , localB -> hv1i03vcrx , localB -> eftgclmxsy , localB ->
b2a12dteat , localB -> lsasi2uldc , localB -> g5agc0xg32 , localB ->
hooc103vyj , localB -> eeb3auw5nx , localB -> ek12timuyq , localB ->
g2srpjb4za , localB -> ky55fcx12u , localB -> lli4msildn , localB ->
ekonhtwtew , localB -> kzdtcoisvi , localB -> ivswn3mcce , localB ->
klywadtuwk , localB -> bc5mpnnywl , & czlc2qmxmx [ 0 ] , localB -> p4dxuexhmn
, localB -> dgacotjrc4 , localB -> opivgwwsqb , localB -> abpryvvknk , localB
-> kkloewbxvk , localB -> dcwkj3tspn , localB -> agcbzjjxc2 , localB ->
fblkngoubr , localB -> bgbdvzlrnp , localB -> ei3jjsazbv , localB ->
l1sbdzlbft , localB -> hrdyz2htuu , localB -> g22rfrhcci , localB ->
d51egdrz0z , localB -> gmqaszorzp , localB -> pu4cguusa5 , localB ->
hawqte0lkp , localB -> fqfqbihpo4 , localB -> fcmrvrr5m4 , localB ->
aewmk31j2l , localB -> ilblxiaesg , localB -> csbz5vwjbl , localB ->
efotijbqgm , localB -> dn24fdverp , localB -> mpurjwwdjq , localB ->
a5hv2ji3cc , 0.0 , localB -> fkg40b3zq2 , localB -> amzgulqp12 , localB ->
ijjphmn2q0 , localB -> hu5pmd13z1 , localB -> nfnujv3tc2 , localB ->
mqhdsdepts , localB -> igbd4extak , localB -> onrl0wpwlm , localB ->
bonsvi0den , localB -> pe2ebnzhq4 , localB -> isr01bpmsd , localB ->
glwizfkrzi , localB -> j0032htb5y , localB -> fmvdhgj0c5 , localB ->
obgyaeas1p , localB -> jm54t5nyht , localB -> am0wr3vakl , localB ->
hbjg5ycjap , localB -> flo2k44qyj , localB -> fsb2e41l0m , localB ->
m2xjbusmco , localB -> lhyhzghz5g , localB -> ldco5bshns , localB ->
pxbcgurxxp , localB -> d3b0uleyfa , localB -> gssojkvg2t , & cyqteuatay [ 0 ]
, & n4z4intnf3 [ 0 ] , & localB -> azps4qfrqh , becrktx0d0 . P_12 ,
becrktx0d0 . P_16 , becrktx0d0 . P_165 , becrktx0d0 . P_189 ) ;
cj3txzi5fm_idx_0 = localB -> azps4qfrqh . jufyrxj0jc ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> kihaqcuhgw = becrktx0d0 . P_153 ; zcEvent = rt_ZCFcn (
ANY_ZERO_CROSSING , & localZCE -> flpmsfbjwa , ( localX -> bxrckvq45q -
becrktx0d0 . P_318 ) ) ; if ( localDW -> k5yhnl2wmc == 0 ) { if ( zcEvent !=
NO_ZCEVENT ) { localB -> oe5zgjmetl = ! localB -> oe5zgjmetl ; localDW ->
k5yhnl2wmc = 1 ; } else if ( localB -> oe5zgjmetl ) { if ( localX ->
bxrckvq45q != becrktx0d0 . P_318 ) { localB -> oe5zgjmetl = false ; } } else
{ if ( localX -> bxrckvq45q == becrktx0d0 . P_318 ) { localB -> oe5zgjmetl =
true ; } } } else { if ( localX -> bxrckvq45q != becrktx0d0 . P_318 ) {
localB -> oe5zgjmetl = false ; } localDW -> k5yhnl2wmc = 0 ; } localB ->
p4l2o41od2 = becrktx0d0 . P_153 ; } ittjpgmzbj_p = localX -> gswussrcam ;
etj3o5lltd_p = ( fo3cvtmfih [ 1 ] - localX -> gswussrcam * localB ->
p4l2o41od2 ) * becrktx0d0 . P_320 ; if ( rtmIsMajorTimeStep ( hokadafud5 ) &&
rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB -> dlgefiim2f = becrktx0d0 .
P_180 ; localB -> p3yundq3ew = becrktx0d0 . P_321 * localB -> dlgefiim2f ;
localB -> p5c41u4oxs = becrktx0d0 . P_235 ; } localB -> peb3w5yei4 =
dfx1ca0pmi [ 1 ] * localB -> p3yundq3ew * localB -> dlgefiim2f * localB ->
p5c41u4oxs ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { localDW -> lgnoyudawr
= localB -> peb3w5yei4 >= becrktx0d0 . P_322 ? 1 : localB -> peb3w5yei4 >
becrktx0d0 . P_323 ? 0 : - 1 ; } orehnlu50o_p = becrktx0d0 . P_157 *
becrktx0d0 . P_227 * ( localDW -> lgnoyudawr == 1 ? becrktx0d0 . P_322 :
localDW -> lgnoyudawr == - 1 ? becrktx0d0 . P_323 : localB -> peb3w5yei4 ) ;
kofgmkkx4p_p = becrktx0d0 . P_231 / becrktx0d0 . P_227 * orehnlu50o_p ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> nguio0nz2d = becrktx0d0 . P_175 * becrktx0d0 . P_324 ; localB ->
engjw3ctqq = localDW -> lb1nn0qgui ; } localB -> krm0jkmd2d = becrktx0d0 .
P_491 [ ( ( ( muDoubleScalarAbs ( ( ( 0.0 - etj3o5lltd_p ) - localB ->
nguio0nz2d ) + localB -> nguio0nz2d ) >= kofgmkkx4p_p ) + ( ( uint32_T ) (
localB -> oe5zgjmetl && ( muDoubleScalarAbs ( - etj3o5lltd_p ) <=
kofgmkkx4p_p ) ) << 1 ) ) << 1 ) + localB -> engjw3ctqq ] ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ if ( localDW -> gmuarwd0x2 ) { localDW -> gmuarwd0x2 = false ; kofgmkkx4p_p
= becrktx0d0 . P_326 ; } else { kofgmkkx4p_p = becrktx0d0 . P_325 ; } if (
kofgmkkx4p_p > becrktx0d0 . P_327 ) { localB -> g5igejoxg1 = becrktx0d0 .
P_324 ; } else { localB -> g5igejoxg1 = becrktx0d0 . P_239 ; } } rtPrevAction
= localDW -> ngtk3y0d0k ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { rtAction
= ( int8_T ) ! localB -> krm0jkmd2d ; localDW -> ngtk3y0d0k = rtAction ; }
else { rtAction = localDW -> ngtk3y0d0k ; } if ( rtPrevAction != rtAction ) {
switch ( rtPrevAction ) { case 0 : iibbapsg2n ( hokadafud5 ) ; break ; case 1
: ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ;
localXdis -> bxrckvq45q = 1 ; break ; } } switch ( rtAction ) { case 0 : if (
rtAction != rtPrevAction ) { bgjvfsnvvf ( hokadafud5 ) ; } ekmk5spjxa (
hokadafud5 , & localB -> c0ja0z23dg , & localB -> kwvhl4ef3q , & becrktx0d0 .
kwvhl4ef3q ) ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { srUpdateBC (
localDW -> kwvhl4ef3q . dygl2vbtcr ) ; } break ; case 1 : if ( rtAction !=
rtPrevAction ) { if ( rtmIsFirstInitCond ( hokadafud5 ) ) { localX ->
bxrckvq45q = 0.0 ; } localDW -> j0vc5sz3xv = 1 ; if ( rtmGetTaskTime (
hokadafud5 , 0 ) != rtmGetTStart ( hokadafud5 ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ; }
localXdis -> bxrckvq45q = 0 ; } if ( localDW -> j0vc5sz3xv != 0 ) { localX ->
bxrckvq45q = localB -> g5igejoxg1 ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } localB -> jhibd0fk2e = ( ( muDoubleScalarTanh ( becrktx0d0
. P_253 * localX -> bxrckvq45q ) * orehnlu50o_p - etj3o5lltd_p ) - becrktx0d0
. P_175 * localX -> bxrckvq45q ) * ( 1.0 / becrktx0d0 . P_22 ) ; localB ->
c0ja0z23dg = localX -> bxrckvq45q ; if ( rtmIsMajorTimeStep ( hokadafud5 ) )
{ srUpdateBC ( localDW -> dtfk4nn1qz ) ; } break ; } if ( rtmIsMajorTimeStep
( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
gya0kbnvv3 = becrktx0d0 . P_328 ; localB -> e543wt05dh = becrktx0d0 . P_329 ;
localB -> naonrfraas = becrktx0d0 . P_330 ; localB -> d5pcl30hua = becrktx0d0
. P_331 ; localB -> enzmk5pf4o = becrktx0d0 . P_332 ; localB -> njc1netzs3 =
becrktx0d0 . P_185 ; localB -> psrn2rspbv = becrktx0d0 . P_27 ; localB ->
fx4bdcvxja = becrktx0d0 . P_9 ; localB -> hv0jodqqs3 = becrktx0d0 . P_36 ;
localB -> f5mcrvxmrt = becrktx0d0 . P_333 ; localB -> fcxug0bpsn = becrktx0d0
. P_334 ; localB -> jhysjc540s = becrktx0d0 . P_41 ; localB -> mssyoofqpv =
becrktx0d0 . P_45 ; localB -> ffpimvq1sz = becrktx0d0 . P_49 ; localB ->
jf4jh5rlz0 = becrktx0d0 . P_53 ; localB -> jc5dmbapbw = becrktx0d0 . P_57 ;
localB -> pspspmf0qs = becrktx0d0 . P_61 ; localB -> cm4en5t1nq = becrktx0d0
. P_65 ; localB -> mjlza1k4nu = becrktx0d0 . P_69 ; localB -> klxatjmabe =
becrktx0d0 . P_81 ; localB -> dobyt3vkx4 = becrktx0d0 . P_85 ; localB ->
evss2jjgrf = becrktx0d0 . P_89 ; localB -> gd03u24ntw = becrktx0d0 . P_73 ;
localB -> pjb4lrl0ur = becrktx0d0 . P_77 ; localB -> a5enc0h5cl = becrktx0d0
. P_109 ; localB -> fctmvus1du = becrktx0d0 . P_113 ; localB -> jdp4a2z1g5 =
becrktx0d0 . P_93 ; localB -> nf05aww25e = becrktx0d0 . P_97 ; localB ->
goghp2x2da = becrktx0d0 . P_101 ; localB -> mot0j1tqma = becrktx0d0 . P_105 ;
localB -> pq2fabvz5k = becrktx0d0 . P_202 ; localB -> mjreasqhek = becrktx0d0
. P_222 ; localB -> iftdgrsa05 = becrktx0d0 . P_210 ; localB -> apqabofwu5 =
becrktx0d0 . P_194 ; localB -> aqds0ofasd = becrktx0d0 . P_198 ; localB ->
bwclupiqxv = becrktx0d0 . P_206 ; localB -> mo0zpwakun = becrktx0d0 . P_218 ;
localB -> n4bp4zjfwv [ 0 ] = becrktx0d0 . P_335 [ 0 ] ; localB -> frm4syq440
[ 0 ] = becrktx0d0 . P_336 [ 0 ] ; localB -> n4bp4zjfwv [ 1 ] = becrktx0d0 .
P_335 [ 1 ] ; localB -> frm4syq440 [ 1 ] = becrktx0d0 . P_336 [ 1 ] ; localB
-> n4bp4zjfwv [ 2 ] = becrktx0d0 . P_335 [ 2 ] ; localB -> frm4syq440 [ 2 ] =
becrktx0d0 . P_336 [ 2 ] ; localB -> nvi4gppmvv = becrktx0d0 . P_9 ; localB
-> fkxmdwac2r = becrktx0d0 . P_36 ; localB -> htjp5ek3fq = becrktx0d0 . P_118
; localB -> oczgpffard = becrktx0d0 . P_122 ; localB -> az5q3j0bed =
becrktx0d0 . P_126 ; localB -> pmkft3x5ig = becrktx0d0 . P_130 ; localB ->
izf5s33tmm = becrktx0d0 . P_134 ; localB -> bxoaokm1pa = becrktx0d0 . P_138 ;
localB -> a54mfanpi0 = becrktx0d0 . P_142 ; localB -> jng0vonz3d = becrktx0d0
. P_146 ; localB -> jctvycvsp0 = becrktx0d0 . P_185 ; localB -> jrmweg4c4j =
becrktx0d0 . P_214 ; localB -> mhsrh5emdu = becrktx0d0 . P_162 ; localB ->
df5dtpkovu = becrktx0d0 . P_338 ; localB -> bbyxlrphmc = becrktx0d0 . P_339 ;
localB -> crkky0j4wi [ 0 ] = becrktx0d0 . P_340 [ 0 ] ; localB -> oc3syc1had
[ 0 ] = becrktx0d0 . P_341 [ 0 ] ; localB -> crkky0j4wi [ 1 ] = becrktx0d0 .
P_340 [ 1 ] ; localB -> oc3syc1had [ 1 ] = becrktx0d0 . P_341 [ 1 ] ; localB
-> crkky0j4wi [ 2 ] = becrktx0d0 . P_340 [ 2 ] ; localB -> oc3syc1had [ 2 ] =
becrktx0d0 . P_341 [ 2 ] ; memcpy ( & localB -> d2yrhfqtgt [ 0 ] , &
becrktx0d0 . P_337 [ 0 ] , 9U * sizeof ( real_T ) ) ; memcpy ( & localB ->
momgprkjbh [ 0 ] , & becrktx0d0 . P_342 [ 0 ] , 9U * sizeof ( real_T ) ) ;
localB -> hzdrl0i0ia = becrktx0d0 . P_343 ; localB -> p2dtigkgaf = becrktx0d0
. P_344 ; localB -> mimwv5dvzs = becrktx0d0 . P_345 ; localB -> kwzep05ody =
becrktx0d0 . P_346 ; localB -> c2izl10ezo = becrktx0d0 . P_347 ; localB ->
b1kjrb022n = becrktx0d0 . P_348 ; localB -> pvy3vbjvw2 = becrktx0d0 . P_349 ;
localB -> bnf3dwud1m = becrktx0d0 . P_350 ; localB -> idvzhvb5zm = becrktx0d0
. P_351 ; localB -> ebvkurz4ue = becrktx0d0 . P_352 ; localB -> dakmjltvg3 =
becrktx0d0 . P_353 ; localB -> lp31hztb55 = becrktx0d0 . P_354 ; localB ->
kckinb301k = becrktx0d0 . P_355 ; localB -> ibgpb5vvta = becrktx0d0 . P_356 ;
localB -> pwyeshcpv2 = becrktx0d0 . P_357 ; localB -> mq4nm2marh = becrktx0d0
. P_358 ; localB -> gcukvt1mcv = becrktx0d0 . P_359 ; localB -> g00ccjwa2j =
becrktx0d0 . P_360 ; localB -> numplzjehj = becrktx0d0 . P_361 ; localB ->
cdhvl0jekq = becrktx0d0 . P_362 ; localB -> m5x1rc5v2c = becrktx0d0 . P_363 ;
localB -> phkg0eilwd = becrktx0d0 . P_364 ; localB -> e1wyvqrgpd = becrktx0d0
. P_365 ; localB -> lbmhaqyph2 = becrktx0d0 . P_366 ; localB -> d2sicg5t5v =
becrktx0d0 . P_367 ; localB -> ddkgx3utjf = becrktx0d0 . P_368 ; } hor3rithbp
( localB -> kihaqcuhgw , dyojl213t2_idx_1 , localB -> c0ja0z23dg , localB ->
fp0lz1z3pw [ 1 ] , localB -> gya0kbnvv3 , localB -> e543wt05dh , localB ->
naonrfraas , localB -> d5pcl30hua , localB -> enzmk5pf4o , localB ->
njc1netzs3 , localB -> psrn2rspbv , localB -> fx4bdcvxja , & bv2zp3o4ji [ 1 ]
, localB -> hv0jodqqs3 , localB -> f5mcrvxmrt , localB -> fcxug0bpsn , localB
-> jhysjc540s , localB -> mssyoofqpv , localB -> ffpimvq1sz , localB ->
jf4jh5rlz0 , localB -> jc5dmbapbw , localB -> pspspmf0qs , localB ->
cm4en5t1nq , localB -> mjlza1k4nu , localB -> klxatjmabe , localB ->
dobyt3vkx4 , localB -> evss2jjgrf , localB -> gd03u24ntw , localB ->
pjb4lrl0ur , localB -> a5enc0h5cl , localB -> fctmvus1du , localB ->
jdp4a2z1g5 , localB -> nf05aww25e , localB -> goghp2x2da , localB ->
mot0j1tqma , localB -> pq2fabvz5k , localB -> mjreasqhek , & czlc2qmxmx [ 1 ]
, localB -> iftdgrsa05 , localB -> apqabofwu5 , localB -> aqds0ofasd , localB
-> bwclupiqxv , localB -> mo0zpwakun , localB -> n4bp4zjfwv , localB ->
frm4syq440 , localB -> d2yrhfqtgt , localB -> nvi4gppmvv , localB ->
fkxmdwac2r , localB -> htjp5ek3fq , localB -> oczgpffard , localB ->
az5q3j0bed , localB -> pmkft3x5ig , localB -> izf5s33tmm , localB ->
bxoaokm1pa , localB -> a54mfanpi0 , localB -> jng0vonz3d , localB ->
jctvycvsp0 , localB -> jrmweg4c4j , localB -> mhsrh5emdu , localB ->
df5dtpkovu , localB -> bbyxlrphmc , localB -> crkky0j4wi , localB ->
oc3syc1had , localB -> momgprkjbh , 0.0 , localB -> hzdrl0i0ia , localB ->
p2dtigkgaf , localB -> mimwv5dvzs , localB -> kwzep05ody , localB ->
c2izl10ezo , localB -> b1kjrb022n , localB -> pvy3vbjvw2 , localB ->
bnf3dwud1m , localB -> idvzhvb5zm , localB -> ebvkurz4ue , localB ->
dakmjltvg3 , localB -> lp31hztb55 , localB -> kckinb301k , localB ->
ibgpb5vvta , localB -> pwyeshcpv2 , localB -> mq4nm2marh , localB ->
gcukvt1mcv , localB -> g00ccjwa2j , localB -> numplzjehj , localB ->
cdhvl0jekq , localB -> m5x1rc5v2c , localB -> phkg0eilwd , localB ->
e1wyvqrgpd , localB -> lbmhaqyph2 , localB -> d2sicg5t5v , localB ->
ddkgx3utjf , & cyqteuatay [ 1 ] , & n4z4intnf3 [ 1 ] , & localB -> lh5kjqwuvr
, becrktx0d0 . P_13 , becrktx0d0 . P_17 , becrktx0d0 . P_166 , becrktx0d0 .
P_190 ) ; cj3txzi5fm_idx_1 = localB -> lh5kjqwuvr . jufyrxj0jc ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> jqra0qrc4f = becrktx0d0 . P_154 ; zcEvent = rt_ZCFcn (
ANY_ZERO_CROSSING , & localZCE -> bnxldw4l3m , ( localX -> jg0z2f4dcg -
becrktx0d0 . P_369 ) ) ; if ( localDW -> i2lrfe4vsy == 0 ) { if ( zcEvent !=
NO_ZCEVENT ) { localB -> loolhadail = ! localB -> loolhadail ; localDW ->
i2lrfe4vsy = 1 ; } else if ( localB -> loolhadail ) { if ( localX ->
jg0z2f4dcg != becrktx0d0 . P_369 ) { localB -> loolhadail = false ; } } else
{ if ( localX -> jg0z2f4dcg == becrktx0d0 . P_369 ) { localB -> loolhadail =
true ; } } } else { if ( localX -> jg0z2f4dcg != becrktx0d0 . P_369 ) {
localB -> loolhadail = false ; } localDW -> i2lrfe4vsy = 0 ; } localB ->
numsq4h5aq = becrktx0d0 . P_154 ; } etj3o5lltd_p = localX -> ivyedmn25f ;
orehnlu50o_p = ( fo3cvtmfih [ 2 ] - localX -> ivyedmn25f * localB ->
numsq4h5aq ) * becrktx0d0 . P_371 ; if ( rtmIsMajorTimeStep ( hokadafud5 ) &&
rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB -> hxumbizg0d = becrktx0d0 .
P_181 ; localB -> c1ee4phlss = becrktx0d0 . P_372 * localB -> hxumbizg0d ;
localB -> a4c0lwlpcd = becrktx0d0 . P_236 ; } localB -> cwucxqw2pf =
dfx1ca0pmi [ 2 ] * localB -> c1ee4phlss * localB -> hxumbizg0d * localB ->
a4c0lwlpcd ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { localDW -> n2wij4stkw
= localB -> cwucxqw2pf >= becrktx0d0 . P_373 ? 1 : localB -> cwucxqw2pf >
becrktx0d0 . P_374 ? 0 : - 1 ; } kofgmkkx4p_p = becrktx0d0 . P_158 *
becrktx0d0 . P_228 * ( localDW -> n2wij4stkw == 1 ? becrktx0d0 . P_373 :
localDW -> n2wij4stkw == - 1 ? becrktx0d0 . P_374 : localB -> cwucxqw2pf ) ;
okrrl0uxrk_p = becrktx0d0 . P_232 / becrktx0d0 . P_228 * kofgmkkx4p_p ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> ejgbaymku3 = becrktx0d0 . P_176 * becrktx0d0 . P_375 ; localB ->
na0yxcd24g = localDW -> gbgapftrxi ; } localB -> bieyt1db1k = becrktx0d0 .
P_493 [ ( ( ( muDoubleScalarAbs ( ( ( 0.0 - orehnlu50o_p ) - localB ->
ejgbaymku3 ) + localB -> ejgbaymku3 ) >= okrrl0uxrk_p ) + ( ( uint32_T ) (
localB -> loolhadail && ( muDoubleScalarAbs ( - orehnlu50o_p ) <=
okrrl0uxrk_p ) ) << 1 ) ) << 1 ) + localB -> na0yxcd24g ] ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ if ( localDW -> axwzh0jhgp ) { localDW -> axwzh0jhgp = false ; okrrl0uxrk_p
= becrktx0d0 . P_377 ; } else { okrrl0uxrk_p = becrktx0d0 . P_376 ; } if (
okrrl0uxrk_p > becrktx0d0 . P_378 ) { localB -> jiue5code2 = becrktx0d0 .
P_375 ; } else { localB -> jiue5code2 = becrktx0d0 . P_240 ; } } rtPrevAction
= localDW -> jcq45ux2tw ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { rtAction
= ( int8_T ) ! localB -> bieyt1db1k ; localDW -> jcq45ux2tw = rtAction ; }
else { rtAction = localDW -> jcq45ux2tw ; } if ( rtPrevAction != rtAction ) {
switch ( rtPrevAction ) { case 0 : iibbapsg2n ( hokadafud5 ) ; break ; case 1
: ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ;
localXdis -> jg0z2f4dcg = 1 ; break ; } } switch ( rtAction ) { case 0 : if (
rtAction != rtPrevAction ) { bgjvfsnvvf ( hokadafud5 ) ; } ekmk5spjxa (
hokadafud5 , & localB -> ikj1m0o4mz , & localB -> jekbgdtwun , & becrktx0d0 .
jekbgdtwun ) ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { srUpdateBC (
localDW -> jekbgdtwun . dygl2vbtcr ) ; } break ; case 1 : if ( rtAction !=
rtPrevAction ) { if ( rtmIsFirstInitCond ( hokadafud5 ) ) { localX ->
jg0z2f4dcg = 0.0 ; } localDW -> puigwz3vsu = 1 ; if ( rtmGetTaskTime (
hokadafud5 , 0 ) != rtmGetTStart ( hokadafud5 ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ; }
localXdis -> jg0z2f4dcg = 0 ; } if ( localDW -> puigwz3vsu != 0 ) { localX ->
jg0z2f4dcg = localB -> jiue5code2 ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } localB -> fj5nty1pmy = ( ( muDoubleScalarTanh ( becrktx0d0
. P_255 * localX -> jg0z2f4dcg ) * kofgmkkx4p_p - orehnlu50o_p ) - becrktx0d0
. P_176 * localX -> jg0z2f4dcg ) * ( 1.0 / becrktx0d0 . P_23 ) ; localB ->
ikj1m0o4mz = localX -> jg0z2f4dcg ; if ( rtmIsMajorTimeStep ( hokadafud5 ) )
{ srUpdateBC ( localDW -> dvpvfskwai ) ; } break ; } if ( rtmIsMajorTimeStep
( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
ax00hnppth = becrktx0d0 . P_379 ; localB -> k4tb3ntsf3 = becrktx0d0 . P_380 ;
localB -> nphikq3xj1 = becrktx0d0 . P_381 ; localB -> dl30i01l3p = becrktx0d0
. P_382 ; localB -> fd0hla2abn = becrktx0d0 . P_383 ; localB -> lsaj5xk0ks =
becrktx0d0 . P_186 ; localB -> bwvxjyivut = becrktx0d0 . P_28 ; localB ->
mwzifv1a5c = becrktx0d0 . P_10 ; localB -> jmchmvxfhq = becrktx0d0 . P_37 ;
localB -> pqdxxygisp = becrktx0d0 . P_384 ; localB -> ec2ephpzxi = becrktx0d0
. P_385 ; localB -> pyeudtquzg = becrktx0d0 . P_42 ; localB -> dmcfkawsjf =
becrktx0d0 . P_46 ; localB -> hftqavup3t = becrktx0d0 . P_50 ; localB ->
esoh5l5lxo = becrktx0d0 . P_54 ; localB -> idctxzieo0 = becrktx0d0 . P_58 ;
localB -> hphiagg0re = becrktx0d0 . P_62 ; localB -> f1mzffw2ii = becrktx0d0
. P_66 ; localB -> bwacdjho4y = becrktx0d0 . P_70 ; localB -> bkuuxygiqv =
becrktx0d0 . P_82 ; localB -> cvklcpcg5h = becrktx0d0 . P_86 ; localB ->
ks5imzrjrb = becrktx0d0 . P_90 ; localB -> pjn2ul1e5q = becrktx0d0 . P_74 ;
localB -> cq0ulc5p42 = becrktx0d0 . P_78 ; localB -> m4jgqymj3m = becrktx0d0
. P_110 ; localB -> kfu4rsdusc = becrktx0d0 . P_114 ; localB -> agahu4jva1 =
becrktx0d0 . P_94 ; localB -> d0mwow1ynj = becrktx0d0 . P_98 ; localB ->
chvcqjgtkd = becrktx0d0 . P_102 ; localB -> ggy510ulkr = becrktx0d0 . P_106 ;
localB -> fefyztusl5 = becrktx0d0 . P_203 ; localB -> n2oqsfqzgf = becrktx0d0
. P_223 ; localB -> p2ew0hvidw = becrktx0d0 . P_211 ; localB -> kpt4zd10sl =
becrktx0d0 . P_195 ; localB -> iprkzcw0uf = becrktx0d0 . P_199 ; localB ->
gbyou3x5qj = becrktx0d0 . P_207 ; localB -> lxntqw3pa0 = becrktx0d0 . P_219 ;
localB -> gzjvzppbfb [ 0 ] = becrktx0d0 . P_386 [ 0 ] ; localB -> bwdfn5yr4y
[ 0 ] = becrktx0d0 . P_387 [ 0 ] ; localB -> gzjvzppbfb [ 1 ] = becrktx0d0 .
P_386 [ 1 ] ; localB -> bwdfn5yr4y [ 1 ] = becrktx0d0 . P_387 [ 1 ] ; localB
-> gzjvzppbfb [ 2 ] = becrktx0d0 . P_386 [ 2 ] ; localB -> bwdfn5yr4y [ 2 ] =
becrktx0d0 . P_387 [ 2 ] ; localB -> phqr3dlt5s = becrktx0d0 . P_10 ; localB
-> b55anpz0ry = becrktx0d0 . P_37 ; localB -> avaxnmw4it = becrktx0d0 . P_119
; localB -> aawt1jhkmi = becrktx0d0 . P_123 ; localB -> ffzea14g1z =
becrktx0d0 . P_127 ; localB -> my5flu2qpd = becrktx0d0 . P_131 ; localB ->
lvuprdvd3t = becrktx0d0 . P_135 ; localB -> m2ee3ab4rk = becrktx0d0 . P_139 ;
localB -> lgmuosmxxg = becrktx0d0 . P_143 ; localB -> mvhbt05gbg = becrktx0d0
. P_147 ; localB -> jamrnffszs = becrktx0d0 . P_186 ; localB -> osgfr2nr12 =
becrktx0d0 . P_215 ; localB -> gifebyd4pm = becrktx0d0 . P_163 ; localB ->
ccgbuww52i = becrktx0d0 . P_389 ; localB -> g5n0tdcjyr = becrktx0d0 . P_390 ;
localB -> odtlbjxf5w [ 0 ] = becrktx0d0 . P_391 [ 0 ] ; localB -> pwd3yzcihq
[ 0 ] = becrktx0d0 . P_392 [ 0 ] ; localB -> odtlbjxf5w [ 1 ] = becrktx0d0 .
P_391 [ 1 ] ; localB -> pwd3yzcihq [ 1 ] = becrktx0d0 . P_392 [ 1 ] ; localB
-> odtlbjxf5w [ 2 ] = becrktx0d0 . P_391 [ 2 ] ; localB -> pwd3yzcihq [ 2 ] =
becrktx0d0 . P_392 [ 2 ] ; memcpy ( & localB -> bdxkllszng [ 0 ] , &
becrktx0d0 . P_388 [ 0 ] , 9U * sizeof ( real_T ) ) ; memcpy ( & localB ->
d0ll0sez0n [ 0 ] , & becrktx0d0 . P_393 [ 0 ] , 9U * sizeof ( real_T ) ) ;
localB -> jpv5umn2ki = becrktx0d0 . P_394 ; localB -> hh1kadovlv = becrktx0d0
. P_395 ; localB -> cy1u0ypjlh = becrktx0d0 . P_396 ; localB -> gjgv4vigdp =
becrktx0d0 . P_397 ; localB -> ghvh2gsyqo = becrktx0d0 . P_398 ; localB ->
iy3agwh4zg = becrktx0d0 . P_399 ; localB -> lhgq3j20k1 = becrktx0d0 . P_400 ;
localB -> ezwciwsl2z = becrktx0d0 . P_401 ; localB -> hcx3b2oh2i = becrktx0d0
. P_402 ; localB -> l15sbazs2h = becrktx0d0 . P_403 ; localB -> cbktnow5af =
becrktx0d0 . P_404 ; localB -> anpxn4wrup = becrktx0d0 . P_405 ; localB ->
cw3x2kv3z4 = becrktx0d0 . P_406 ; localB -> ai5l40b3iu = becrktx0d0 . P_407 ;
localB -> dlwvafx3n4 = becrktx0d0 . P_408 ; localB -> a0nueplqwy = becrktx0d0
. P_409 ; localB -> lqlya1zs1k = becrktx0d0 . P_410 ; localB -> j5ypkiaj2a =
becrktx0d0 . P_411 ; localB -> nq0m5padfo = becrktx0d0 . P_412 ; localB ->
esrllkz3f1 = becrktx0d0 . P_413 ; localB -> ndadoi2fa3 = becrktx0d0 . P_414 ;
localB -> ffmdhdniyz = becrktx0d0 . P_415 ; localB -> m2ljmb52uk = becrktx0d0
. P_416 ; localB -> i3rgk5at5k = becrktx0d0 . P_417 ; localB -> g1zar4icoz =
becrktx0d0 . P_418 ; localB -> byvynht2aq = becrktx0d0 . P_419 ; } hor3rithbp
( localB -> jqra0qrc4f , dyojl213t2_idx_2 , localB -> ikj1m0o4mz , localB ->
fp0lz1z3pw [ 2 ] , localB -> ax00hnppth , localB -> k4tb3ntsf3 , localB ->
nphikq3xj1 , localB -> dl30i01l3p , localB -> fd0hla2abn , localB ->
lsaj5xk0ks , localB -> bwvxjyivut , localB -> mwzifv1a5c , & bv2zp3o4ji [ 2 ]
, localB -> jmchmvxfhq , localB -> pqdxxygisp , localB -> ec2ephpzxi , localB
-> pyeudtquzg , localB -> dmcfkawsjf , localB -> hftqavup3t , localB ->
esoh5l5lxo , localB -> idctxzieo0 , localB -> hphiagg0re , localB ->
f1mzffw2ii , localB -> bwacdjho4y , localB -> bkuuxygiqv , localB ->
cvklcpcg5h , localB -> ks5imzrjrb , localB -> pjn2ul1e5q , localB ->
cq0ulc5p42 , localB -> m4jgqymj3m , localB -> kfu4rsdusc , localB ->
agahu4jva1 , localB -> d0mwow1ynj , localB -> chvcqjgtkd , localB ->
ggy510ulkr , localB -> fefyztusl5 , localB -> n2oqsfqzgf , & czlc2qmxmx [ 2 ]
, localB -> p2ew0hvidw , localB -> kpt4zd10sl , localB -> iprkzcw0uf , localB
-> gbyou3x5qj , localB -> lxntqw3pa0 , localB -> gzjvzppbfb , localB ->
bwdfn5yr4y , localB -> bdxkllszng , localB -> phqr3dlt5s , localB ->
b55anpz0ry , localB -> avaxnmw4it , localB -> aawt1jhkmi , localB ->
ffzea14g1z , localB -> my5flu2qpd , localB -> lvuprdvd3t , localB ->
m2ee3ab4rk , localB -> lgmuosmxxg , localB -> mvhbt05gbg , localB ->
jamrnffszs , localB -> osgfr2nr12 , localB -> gifebyd4pm , localB ->
ccgbuww52i , localB -> g5n0tdcjyr , localB -> odtlbjxf5w , localB ->
pwd3yzcihq , localB -> d0ll0sez0n , 0.0 , localB -> jpv5umn2ki , localB ->
hh1kadovlv , localB -> cy1u0ypjlh , localB -> gjgv4vigdp , localB ->
ghvh2gsyqo , localB -> iy3agwh4zg , localB -> lhgq3j20k1 , localB ->
ezwciwsl2z , localB -> hcx3b2oh2i , localB -> l15sbazs2h , localB ->
cbktnow5af , localB -> anpxn4wrup , localB -> cw3x2kv3z4 , localB ->
ai5l40b3iu , localB -> dlwvafx3n4 , localB -> a0nueplqwy , localB ->
lqlya1zs1k , localB -> j5ypkiaj2a , localB -> nq0m5padfo , localB ->
esrllkz3f1 , localB -> ndadoi2fa3 , localB -> ffmdhdniyz , localB ->
m2ljmb52uk , localB -> i3rgk5at5k , localB -> g1zar4icoz , localB ->
byvynht2aq , & cyqteuatay [ 2 ] , & n4z4intnf3 [ 2 ] , & localB -> a21t3mltc4
, becrktx0d0 . P_14 , becrktx0d0 . P_18 , becrktx0d0 . P_167 , becrktx0d0 .
P_191 ) ; cj3txzi5fm_idx_2 = localB -> a21t3mltc4 . jufyrxj0jc ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> edkbwlt3se = becrktx0d0 . P_155 ; zcEvent = rt_ZCFcn (
ANY_ZERO_CROSSING , & localZCE -> prj2ssfcy5 , ( localX -> efxruepcrz -
becrktx0d0 . P_420 ) ) ; if ( localDW -> ogjeqhknwa == 0 ) { if ( zcEvent !=
NO_ZCEVENT ) { localB -> c5zkfremby = ! localB -> c5zkfremby ; localDW ->
ogjeqhknwa = 1 ; } else if ( localB -> c5zkfremby ) { if ( localX ->
efxruepcrz != becrktx0d0 . P_420 ) { localB -> c5zkfremby = false ; } } else
{ if ( localX -> efxruepcrz == becrktx0d0 . P_420 ) { localB -> c5zkfremby =
true ; } } } else { if ( localX -> efxruepcrz != becrktx0d0 . P_420 ) {
localB -> c5zkfremby = false ; } localDW -> ogjeqhknwa = 0 ; } localB ->
d0sjqehaob = becrktx0d0 . P_155 ; } orehnlu50o_p = localX -> gn1qleso4d ;
kofgmkkx4p_p = ( fo3cvtmfih [ 3 ] - localX -> gn1qleso4d * localB ->
d0sjqehaob ) * becrktx0d0 . P_422 ; if ( rtmIsMajorTimeStep ( hokadafud5 ) &&
rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB -> pnxjm41zmq = becrktx0d0 .
P_182 ; localB -> ngpz2fg5xy = becrktx0d0 . P_423 * localB -> pnxjm41zmq ;
localB -> mujuob30yn = becrktx0d0 . P_237 ; } localB -> ffjpij0dzo =
dfx1ca0pmi [ 3 ] * localB -> ngpz2fg5xy * localB -> pnxjm41zmq * localB ->
mujuob30yn ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { localDW -> pw1i2shx4s
= localB -> ffjpij0dzo >= becrktx0d0 . P_424 ? 1 : localB -> ffjpij0dzo >
becrktx0d0 . P_425 ? 0 : - 1 ; } okrrl0uxrk_p = becrktx0d0 . P_159 *
becrktx0d0 . P_229 * ( localDW -> pw1i2shx4s == 1 ? becrktx0d0 . P_424 :
localDW -> pw1i2shx4s == - 1 ? becrktx0d0 . P_425 : localB -> ffjpij0dzo ) ;
i2orjcd5ae_p = becrktx0d0 . P_233 / becrktx0d0 . P_229 * okrrl0uxrk_p ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> lukjivu0vn = becrktx0d0 . P_177 * becrktx0d0 . P_426 ; localB ->
dvh2aiwmdo = localDW -> oywcgos5db ; } localB -> cz1wfypt0w = becrktx0d0 .
P_495 [ ( ( ( muDoubleScalarAbs ( ( ( 0.0 - kofgmkkx4p_p ) - localB ->
lukjivu0vn ) + localB -> lukjivu0vn ) >= i2orjcd5ae_p ) + ( ( uint32_T ) (
localB -> c5zkfremby && ( muDoubleScalarAbs ( - kofgmkkx4p_p ) <=
i2orjcd5ae_p ) ) << 1 ) ) << 1 ) + localB -> dvh2aiwmdo ] ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ if ( localDW -> a001iqqtdq ) { localDW -> a001iqqtdq = false ; i2orjcd5ae_p
= becrktx0d0 . P_428 ; } else { i2orjcd5ae_p = becrktx0d0 . P_427 ; } if (
i2orjcd5ae_p > becrktx0d0 . P_429 ) { localB -> nmo0dyqft2 = becrktx0d0 .
P_426 ; } else { localB -> nmo0dyqft2 = becrktx0d0 . P_241 ; } } rtPrevAction
= localDW -> a4hec4xq23 ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { rtAction
= ( int8_T ) ! localB -> cz1wfypt0w ; localDW -> a4hec4xq23 = rtAction ; }
else { rtAction = localDW -> a4hec4xq23 ; } if ( rtPrevAction != rtAction ) {
switch ( rtPrevAction ) { case 0 : iibbapsg2n ( hokadafud5 ) ; break ; case 1
: ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ;
localXdis -> efxruepcrz = 1 ; break ; } } switch ( rtAction ) { case 0 : if (
rtAction != rtPrevAction ) { bgjvfsnvvf ( hokadafud5 ) ; } ekmk5spjxa (
hokadafud5 , & localB -> cahbswhyq0 , & localB -> eiud0ciipq , & becrktx0d0 .
eiud0ciipq ) ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { srUpdateBC (
localDW -> eiud0ciipq . dygl2vbtcr ) ; } break ; case 1 : if ( rtAction !=
rtPrevAction ) { if ( rtmIsFirstInitCond ( hokadafud5 ) ) { localX ->
efxruepcrz = 0.0 ; } localDW -> cy5d015mtw = 1 ; if ( rtmGetTaskTime (
hokadafud5 , 0 ) != rtmGetTStart ( hokadafud5 ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ; }
localXdis -> efxruepcrz = 0 ; } if ( localDW -> cy5d015mtw != 0 ) { localX ->
efxruepcrz = localB -> nmo0dyqft2 ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } localB -> fo02mk51l0 = ( ( muDoubleScalarTanh ( becrktx0d0
. P_257 * localX -> efxruepcrz ) * okrrl0uxrk_p - kofgmkkx4p_p ) - becrktx0d0
. P_177 * localX -> efxruepcrz ) * ( 1.0 / becrktx0d0 . P_24 ) ; localB ->
cahbswhyq0 = localX -> efxruepcrz ; if ( rtmIsMajorTimeStep ( hokadafud5 ) )
{ srUpdateBC ( localDW -> jmdhsygujx ) ; } break ; } if ( rtmIsMajorTimeStep
( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
aw4g54p2uq = becrktx0d0 . P_430 ; localB -> bzighdfjyo = becrktx0d0 . P_431 ;
localB -> i5a0blv02u = becrktx0d0 . P_432 ; localB -> oapfg21ir4 = becrktx0d0
. P_433 ; localB -> oovcrc5txw = becrktx0d0 . P_434 ; localB -> bzyvjhcmks =
becrktx0d0 . P_187 ; localB -> kfwsnou0z4 = becrktx0d0 . P_29 ; localB ->
pbplrkuu32 = becrktx0d0 . P_11 ; localB -> j4wcufg5bl = becrktx0d0 . P_38 ;
localB -> gaudlnhvry = becrktx0d0 . P_435 ; localB -> fjxzajipkt = becrktx0d0
. P_436 ; localB -> hk4hnaqvh4 = becrktx0d0 . P_43 ; localB -> cs5bymast3 =
becrktx0d0 . P_47 ; localB -> p42tgrvop2 = becrktx0d0 . P_51 ; localB ->
fbpvzxbevm = becrktx0d0 . P_55 ; localB -> h3f101zvdb = becrktx0d0 . P_59 ;
localB -> jqkgvym2zy = becrktx0d0 . P_63 ; localB -> fazkrkbsxw = becrktx0d0
. P_67 ; localB -> fazs2yxbxy = becrktx0d0 . P_71 ; localB -> bzm41rdvhu =
becrktx0d0 . P_83 ; localB -> e3rsqlqayr = becrktx0d0 . P_87 ; localB ->
h10xaj22p2 = becrktx0d0 . P_91 ; localB -> mabbx0oage = becrktx0d0 . P_75 ;
localB -> kazjkxua33 = becrktx0d0 . P_79 ; localB -> dwihbkixr5 = becrktx0d0
. P_111 ; localB -> cxjni4j3is = becrktx0d0 . P_115 ; localB -> geyriwpbwk =
becrktx0d0 . P_95 ; localB -> a0g100tdyx = becrktx0d0 . P_99 ; localB ->
dwl1yvwrok = becrktx0d0 . P_103 ; localB -> g1di3z0153 = becrktx0d0 . P_107 ;
localB -> cy1ie2jyct = becrktx0d0 . P_204 ; localB -> ncet2youct = becrktx0d0
. P_224 ; localB -> atyxanxoep = becrktx0d0 . P_212 ; localB -> fmo10qy00d =
becrktx0d0 . P_196 ; localB -> ded4oex3nw = becrktx0d0 . P_200 ; localB ->
lwb0azt42l = becrktx0d0 . P_208 ; localB -> mdk0qxouay = becrktx0d0 . P_220 ;
localB -> if32pa3y2y [ 0 ] = becrktx0d0 . P_437 [ 0 ] ; localB -> bxgniuki54
[ 0 ] = becrktx0d0 . P_438 [ 0 ] ; localB -> if32pa3y2y [ 1 ] = becrktx0d0 .
P_437 [ 1 ] ; localB -> bxgniuki54 [ 1 ] = becrktx0d0 . P_438 [ 1 ] ; localB
-> if32pa3y2y [ 2 ] = becrktx0d0 . P_437 [ 2 ] ; localB -> bxgniuki54 [ 2 ] =
becrktx0d0 . P_438 [ 2 ] ; localB -> lqykprkdhp = becrktx0d0 . P_11 ; localB
-> owjgcyyrc4 = becrktx0d0 . P_38 ; localB -> k0jiqk4jr5 = becrktx0d0 . P_120
; localB -> boiphodd5u = becrktx0d0 . P_124 ; localB -> jlpvps21xb =
becrktx0d0 . P_128 ; localB -> favd3zjtdv = becrktx0d0 . P_132 ; localB ->
iwzzewai5j = becrktx0d0 . P_136 ; localB -> nfccvfr0wr = becrktx0d0 . P_140 ;
localB -> bcuxkc4ifo = becrktx0d0 . P_144 ; localB -> hoswk5rqzo = becrktx0d0
. P_148 ; localB -> cycn42gkig = becrktx0d0 . P_187 ; localB -> g5xthmjg3u =
becrktx0d0 . P_216 ; localB -> axyino1l23 = becrktx0d0 . P_164 ; localB ->
bhwnfpdnfh = becrktx0d0 . P_440 ; localB -> pndhwp3wlp = becrktx0d0 . P_441 ;
localB -> jlcsqepfsn [ 0 ] = becrktx0d0 . P_442 [ 0 ] ; localB -> dnkaqrpiwe
[ 0 ] = becrktx0d0 . P_443 [ 0 ] ; localB -> jlcsqepfsn [ 1 ] = becrktx0d0 .
P_442 [ 1 ] ; localB -> dnkaqrpiwe [ 1 ] = becrktx0d0 . P_443 [ 1 ] ; localB
-> jlcsqepfsn [ 2 ] = becrktx0d0 . P_442 [ 2 ] ; localB -> dnkaqrpiwe [ 2 ] =
becrktx0d0 . P_443 [ 2 ] ; memcpy ( & localB -> hn1eupnvah [ 0 ] , &
becrktx0d0 . P_439 [ 0 ] , 9U * sizeof ( real_T ) ) ; memcpy ( & localB ->
og1pl52b0g [ 0 ] , & becrktx0d0 . P_444 [ 0 ] , 9U * sizeof ( real_T ) ) ;
localB -> eyv2b315td = becrktx0d0 . P_445 ; localB -> oewprz1max = becrktx0d0
. P_446 ; localB -> i4wafwdq1d = becrktx0d0 . P_447 ; localB -> nrhk0fg5tx =
becrktx0d0 . P_448 ; localB -> jxyonkwdpp = becrktx0d0 . P_449 ; localB ->
nfkwuggdv3 = becrktx0d0 . P_450 ; localB -> hd2mkgvcqr = becrktx0d0 . P_451 ;
localB -> bvmbxvyhou = becrktx0d0 . P_452 ; localB -> g0dyej4unr = becrktx0d0
. P_453 ; localB -> adz43gjvi4 = becrktx0d0 . P_454 ; localB -> extqw4ppik =
becrktx0d0 . P_455 ; localB -> i4mqp0hn3c = becrktx0d0 . P_456 ; localB ->
lzx3txh2r5 = becrktx0d0 . P_457 ; localB -> ein31d03ch = becrktx0d0 . P_458 ;
localB -> mddsia1bs4 = becrktx0d0 . P_459 ; localB -> mkx1rcyupl = becrktx0d0
. P_460 ; localB -> cjm2jf0thg = becrktx0d0 . P_461 ; localB -> g41hsn0s2r =
becrktx0d0 . P_462 ; localB -> jzaawga3sf = becrktx0d0 . P_463 ; localB ->
nzfdb2qwys = becrktx0d0 . P_464 ; localB -> jucxtg5ndo = becrktx0d0 . P_465 ;
localB -> ij0qesxo0x = becrktx0d0 . P_466 ; localB -> o01kjgusit = becrktx0d0
. P_467 ; localB -> jbiokc52mb = becrktx0d0 . P_468 ; localB -> bdgo5lorke =
becrktx0d0 . P_469 ; localB -> lmed21unhr = becrktx0d0 . P_470 ; } hor3rithbp
( localB -> edkbwlt3se , dyojl213t2_idx_3 , localB -> cahbswhyq0 , localB ->
fp0lz1z3pw [ 3 ] , localB -> aw4g54p2uq , localB -> bzighdfjyo , localB ->
i5a0blv02u , localB -> oapfg21ir4 , localB -> oovcrc5txw , localB ->
bzyvjhcmks , localB -> kfwsnou0z4 , localB -> pbplrkuu32 , & bv2zp3o4ji [ 3 ]
, localB -> j4wcufg5bl , localB -> gaudlnhvry , localB -> fjxzajipkt , localB
-> hk4hnaqvh4 , localB -> cs5bymast3 , localB -> p42tgrvop2 , localB ->
fbpvzxbevm , localB -> h3f101zvdb , localB -> jqkgvym2zy , localB ->
fazkrkbsxw , localB -> fazs2yxbxy , localB -> bzm41rdvhu , localB ->
e3rsqlqayr , localB -> h10xaj22p2 , localB -> mabbx0oage , localB ->
kazjkxua33 , localB -> dwihbkixr5 , localB -> cxjni4j3is , localB ->
geyriwpbwk , localB -> a0g100tdyx , localB -> dwl1yvwrok , localB ->
g1di3z0153 , localB -> cy1ie2jyct , localB -> ncet2youct , & czlc2qmxmx [ 3 ]
, localB -> atyxanxoep , localB -> fmo10qy00d , localB -> ded4oex3nw , localB
-> lwb0azt42l , localB -> mdk0qxouay , localB -> if32pa3y2y , localB ->
bxgniuki54 , localB -> hn1eupnvah , localB -> lqykprkdhp , localB ->
owjgcyyrc4 , localB -> k0jiqk4jr5 , localB -> boiphodd5u , localB ->
jlpvps21xb , localB -> favd3zjtdv , localB -> iwzzewai5j , localB ->
nfccvfr0wr , localB -> bcuxkc4ifo , localB -> hoswk5rqzo , localB ->
cycn42gkig , localB -> g5xthmjg3u , localB -> axyino1l23 , localB ->
bhwnfpdnfh , localB -> pndhwp3wlp , localB -> jlcsqepfsn , localB ->
dnkaqrpiwe , localB -> og1pl52b0g , 0.0 , localB -> eyv2b315td , localB ->
oewprz1max , localB -> i4wafwdq1d , localB -> nrhk0fg5tx , localB ->
jxyonkwdpp , localB -> nfkwuggdv3 , localB -> hd2mkgvcqr , localB ->
bvmbxvyhou , localB -> g0dyej4unr , localB -> adz43gjvi4 , localB ->
extqw4ppik , localB -> i4mqp0hn3c , localB -> lzx3txh2r5 , localB ->
ein31d03ch , localB -> mddsia1bs4 , localB -> mkx1rcyupl , localB ->
cjm2jf0thg , localB -> g41hsn0s2r , localB -> jzaawga3sf , localB ->
nzfdb2qwys , localB -> jucxtg5ndo , localB -> ij0qesxo0x , localB ->
o01kjgusit , localB -> jbiokc52mb , localB -> bdgo5lorke , localB ->
lmed21unhr , & cyqteuatay [ 3 ] , & n4z4intnf3 [ 3 ] , & localB -> ehqxxy1j0v
, becrktx0d0 . P_15 , becrktx0d0 . P_19 , becrktx0d0 . P_168 , becrktx0d0 .
P_192 ) ; if ( cj3txzi5fm_idx_0 > becrktx0d0 . P_472 ) { cj3txzi5fm_idx_0 -=
becrktx0d0 . P_472 ; } else if ( cj3txzi5fm_idx_0 >= becrktx0d0 . P_471 ) {
cj3txzi5fm_idx_0 = 0.0 ; } else { cj3txzi5fm_idx_0 -= becrktx0d0 . P_471 ; }
if ( cj3txzi5fm_idx_1 > becrktx0d0 . P_472 ) { cj3txzi5fm_idx_1 -= becrktx0d0
. P_472 ; } else if ( cj3txzi5fm_idx_1 >= becrktx0d0 . P_471 ) {
cj3txzi5fm_idx_1 = 0.0 ; } else { cj3txzi5fm_idx_1 -= becrktx0d0 . P_471 ; }
if ( cj3txzi5fm_idx_2 > becrktx0d0 . P_472 ) { cj3txzi5fm_idx_2 -= becrktx0d0
. P_472 ; } else if ( cj3txzi5fm_idx_2 >= becrktx0d0 . P_471 ) {
cj3txzi5fm_idx_2 = 0.0 ; } else { cj3txzi5fm_idx_2 -= becrktx0d0 . P_471 ; }
cj3txzi5fm_idx_0 += cj3txzi5fm_idx_1 ; if ( localB -> ehqxxy1j0v . jufyrxj0jc
> becrktx0d0 . P_472 ) { okrrl0uxrk_p = localB -> ehqxxy1j0v . jufyrxj0jc -
becrktx0d0 . P_472 ; } else if ( localB -> ehqxxy1j0v . jufyrxj0jc >=
becrktx0d0 . P_471 ) { okrrl0uxrk_p = 0.0 ; } else { okrrl0uxrk_p = localB ->
ehqxxy1j0v . jufyrxj0jc - becrktx0d0 . P_471 ; } kofgmkkx4p_p =
cj3txzi5fm_idx_2 + okrrl0uxrk_p ; if ( rtmIsMajorTimeStep ( hokadafud5 ) &&
rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { eueb01ol1w [ 0 ] = - 0.0 ;
eueb01ol1w [ 1 ] = - 0.0 ; eueb01ol1w [ 2 ] = - 0.0 ; eueb01ol1w [ 3 ] = -
0.0 ; localB -> a5yzeqgxla = becrktx0d0 . P_30 ; localB -> eh21inp54r = -
becrktx0d0 . P_165 ; localB -> ckk03rh1z3 = becrktx0d0 . P_165 ; }
okrrl0uxrk_p = localB -> jm1o4v20ho * localB -> ifttpgshqd ; if ( (
okrrl0uxrk_p >= localB -> eh21inp54r ) && ( okrrl0uxrk_p <= localB ->
ckk03rh1z3 ) ) { okrrl0uxrk_p = 0.2 / ( 3.0 - muDoubleScalarPower (
okrrl0uxrk_p / 0.1 , 2.0 ) ) ; } else { okrrl0uxrk_p = muDoubleScalarAbs (
okrrl0uxrk_p ) ; } localB -> n50351ufzw = ( ( localB -> azps4qfrqh .
jpw2xvx5f1 / localB -> ifttpgshqd + localB -> azps4qfrqh . jufyrxj0jc ) -
ft2a2rkagw_p ) * ( okrrl0uxrk_p / localB -> a5yzeqgxla ) ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> oycbd4zsdl = becrktx0d0 . P_31 ; localB -> awmjhwqf1y = -
becrktx0d0 . P_166 ; localB -> g45hl5q3iu = becrktx0d0 . P_166 ; }
ft2a2rkagw_p = localB -> c0ja0z23dg * localB -> p4l2o41od2 ; if ( (
ft2a2rkagw_p >= localB -> awmjhwqf1y ) && ( ft2a2rkagw_p <= localB ->
g45hl5q3iu ) ) { ft2a2rkagw_p = 0.2 / ( 3.0 - muDoubleScalarPower (
ft2a2rkagw_p / 0.1 , 2.0 ) ) ; } else { ft2a2rkagw_p = muDoubleScalarAbs (
ft2a2rkagw_p ) ; } localB -> jb3u14tozr = ( ( localB -> lh5kjqwuvr .
jpw2xvx5f1 / localB -> p4l2o41od2 + localB -> lh5kjqwuvr . jufyrxj0jc ) -
ittjpgmzbj_p ) * ( ft2a2rkagw_p / localB -> oycbd4zsdl ) ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> dwdzvq30lg = becrktx0d0 . P_32 ; localB -> j1uvqqhzuk = -
becrktx0d0 . P_167 ; localB -> la15gblmjr = becrktx0d0 . P_167 ; }
ft2a2rkagw_p = localB -> ikj1m0o4mz * localB -> numsq4h5aq ; if ( (
ft2a2rkagw_p >= localB -> j1uvqqhzuk ) && ( ft2a2rkagw_p <= localB ->
la15gblmjr ) ) { ft2a2rkagw_p = 0.2 / ( 3.0 - muDoubleScalarPower (
ft2a2rkagw_p / 0.1 , 2.0 ) ) ; } else { ft2a2rkagw_p = muDoubleScalarAbs (
ft2a2rkagw_p ) ; } localB -> olxcszanag = ( ( localB -> a21t3mltc4 .
jpw2xvx5f1 / localB -> numsq4h5aq + localB -> a21t3mltc4 . jufyrxj0jc ) -
etj3o5lltd_p ) * ( ft2a2rkagw_p / localB -> dwdzvq30lg ) ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> ewlwxcybqs = becrktx0d0 . P_33 ; localB -> mdhbuol5q1 = -
becrktx0d0 . P_168 ; localB -> efv5l1pqam = becrktx0d0 . P_168 ; }
ft2a2rkagw_p = localB -> cahbswhyq0 * localB -> d0sjqehaob ; if ( (
ft2a2rkagw_p >= localB -> mdhbuol5q1 ) && ( ft2a2rkagw_p <= localB ->
efv5l1pqam ) ) { ft2a2rkagw_p = 0.2 / ( 3.0 - muDoubleScalarPower (
ft2a2rkagw_p / 0.1 , 2.0 ) ) ; } else { ft2a2rkagw_p = muDoubleScalarAbs (
ft2a2rkagw_p ) ; } localB -> p5xem3od3d = ( ( localB -> ehqxxy1j0v .
jpw2xvx5f1 / localB -> d0sjqehaob + localB -> ehqxxy1j0v . jufyrxj0jc ) -
orehnlu50o_p ) * ( ft2a2rkagw_p / localB -> ewlwxcybqs ) ; av2ap4nkgj [ 0 ] =
localB -> jm1o4v20ho ; av2ap4nkgj [ 1 ] = localB -> c0ja0z23dg ; av2ap4nkgj [
2 ] = localB -> ikj1m0o4mz ; av2ap4nkgj [ 3 ] = localB -> cahbswhyq0 ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> bqcncmwkew = becrktx0d0 . P_246 ; localB -> dbjccy0p5m [ 0 ] =
becrktx0d0 . P_476 [ 0 ] ; localB -> dbjccy0p5m [ 1 ] = becrktx0d0 . P_476 [
1 ] ; localB -> dbjccy0p5m [ 2 ] = becrktx0d0 . P_476 [ 2 ] ; }
cj3txzi5fm_idx_1 = ( gxlrb30ei4 [ 0 ] + gxlrb30ei4 [ 1 ] ) * becrktx0d0 .
P_473 ; i2orjcd5ae_p = ( czlc2qmxmx [ 0 ] + czlc2qmxmx [ 1 ] ) * becrktx0d0 .
P_474 ; hiwzfcmaid_idx_1 = ( czlc2qmxmx [ 2 ] + czlc2qmxmx [ 3 ] ) *
becrktx0d0 . P_475 ; muDoubleScalarSinCos ( kglfuzmg0r_idx_2 , & ft2a2rkagw_p
, & okrrl0uxrk_p ) ; fi5veravxh_p [ 0 ] = kglfuzmg0r_idx_0 - ( okrrl0uxrk_p *
pf4xf35zus [ 0 ] + ft2a2rkagw_p * pf4xf35zus [ 1 ] ) ; fi5veravxh_p [ 1 ] =
kglfuzmg0r_idx_1 - ( okrrl0uxrk_p * pf4xf35zus [ 1 ] - ft2a2rkagw_p *
pf4xf35zus [ 0 ] ) ; if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit
( hokadafud5 , 1 , 0 ) ) { localB -> ey5vfxyzqq [ 0 ] = - localB ->
dbjccy0p5m [ 0 ] ; localB -> ey5vfxyzqq [ 1 ] = - localB -> dbjccy0p5m [ 1 ]
; localB -> ey5vfxyzqq [ 2 ] = - localB -> dbjccy0p5m [ 2 ] ; } if (
fi5veravxh_p [ 0 ] >= becrktx0d0 . P_477 ) { orehnlu50o_p = localB ->
dbjccy0p5m [ 0 ] ; } else { orehnlu50o_p = localB -> ey5vfxyzqq [ 0 ] ; } if
( fi5veravxh_p [ 1 ] >= becrktx0d0 . P_477 ) { cj3txzi5fm_idx_2 = localB ->
dbjccy0p5m [ 1 ] ; } else { cj3txzi5fm_idx_2 = localB -> ey5vfxyzqq [ 1 ] ; }
if ( 0.0 - pf4xf35zus [ 2 ] >= becrktx0d0 . P_477 ) { ittjpgmzbj_p = localB
-> dbjccy0p5m [ 2 ] ; } else { ittjpgmzbj_p = localB -> ey5vfxyzqq [ 2 ] ; }
etj3o5lltd_p = ( fi5veravxh_p [ 0 ] * fi5veravxh_p [ 0 ] + fi5veravxh_p [ 1 ]
* fi5veravxh_p [ 1 ] ) + ( 0.0 - pf4xf35zus [ 2 ] ) * ( 0.0 - pf4xf35zus [ 2
] ) ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { if ( localDW -> jp5udlopwm
!= 0 ) { ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; localDW -> jp5udlopwm = 0 ; } ft2a2rkagw_p =
muDoubleScalarSqrt ( etj3o5lltd_p ) ; } else if ( etj3o5lltd_p < 0.0 ) {
ft2a2rkagw_p = - muDoubleScalarSqrt ( muDoubleScalarAbs ( etj3o5lltd_p ) ) ;
localDW -> jp5udlopwm = 1 ; } else { ft2a2rkagw_p = muDoubleScalarSqrt (
etj3o5lltd_p ) ; } etj3o5lltd_p = ft2a2rkagw_p * ft2a2rkagw_p ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> irw5bmjnd2 [ 0 ] = becrktx0d0 . P_1 ; } ft2a2rkagw_p =
muDoubleScalarAtan2 ( fi5veravxh_p [ 1 ] , fi5veravxh_p [ 0 ] ) ; localB ->
irw5bmjnd2 [ 1 ] = look1_binlcpw ( ft2a2rkagw_p , becrktx0d0 . P_173 ,
becrktx0d0 . P_4 , 30U ) ; if ( rtmIsMajorTimeStep ( hokadafud5 ) &&
rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB -> irw5bmjnd2 [ 2 ] =
becrktx0d0 . P_2 ; localB -> k5ghw3u455 = becrktx0d0 . P_3 ; } localB ->
irw5bmjnd2 [ 3 ] = look1_binlxpw ( ft2a2rkagw_p , becrktx0d0 . P_479 ,
becrktx0d0 . P_478 , 1U ) ; localB -> irw5bmjnd2 [ 4 ] = orehnlu50o_p *
localB -> k5ghw3u455 ; localB -> irw5bmjnd2 [ 5 ] = look1_binlxpw (
ft2a2rkagw_p , becrktx0d0 . P_173 , becrktx0d0 . P_7 , 30U ) ; ft2a2rkagw_p =
0.5 * becrktx0d0 . P_0 * becrktx0d0 . P_116 / becrktx0d0 . P_149 / becrktx0d0
. P_160 ; for ( i = 0 ; i < 6 ; i ++ ) { c2xse5ydzd_p [ i ] = etj3o5lltd_p *
localB -> irw5bmjnd2 [ i ] * ft2a2rkagw_p ; } orehnlu50o_p = - ( orehnlu50o_p
* c2xse5ydzd_p [ 0 ] ) ; cj3txzi5fm_idx_2 = - ( cj3txzi5fm_idx_2 *
c2xse5ydzd_p [ 1 ] ) ; emippuzm0l_p = - ( ittjpgmzbj_p * c2xse5ydzd_p [ 2 ] )
; if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 ,
0 ) ) { localB -> hyntqlru1a = becrktx0d0 . P_171 + becrktx0d0 . P_172 ;
localB -> op20eyqhn0 = becrktx0d0 . P_5 ; localB -> pj112y04hg = becrktx0d0 .
P_6 ; } fi5veravxh_p [ 1 ] = - ( c2xse5ydzd_p [ 4 ] * localB -> hyntqlru1a )
; fi5veravxh_p [ 2 ] = - ( c2xse5ydzd_p [ 5 ] * localB -> hyntqlru1a ) ;
ittjpgmzbj_p = becrktx0d0 . P_171 * kglfuzmg0r_idx_3 + kglfuzmg0r_idx_1 ;
ft2a2rkagw_p = kglfuzmg0r_idx_0 * kglfuzmg0r_idx_0 ; okrrl0uxrk_p =
muDoubleScalarSqrt ( ittjpgmzbj_p * ittjpgmzbj_p + ft2a2rkagw_p ) ;
etj3o5lltd_p = kglfuzmg0r_idx_1 - becrktx0d0 . P_172 * kglfuzmg0r_idx_3 ;
ft2a2rkagw_p = muDoubleScalarSqrt ( etj3o5lltd_p * etj3o5lltd_p +
ft2a2rkagw_p ) ; Fz_idx_1 = muDoubleScalarAbs ( kglfuzmg0r_idx_0 ) ; i = 0 ;
if ( Fz_idx_1 < becrktx0d0 . P_248 ) { i = 1 ; } loop_ub = i - 1 ; for ( i_p
= 0 ; i_p <= loop_ub ; i_p ++ ) { z_data = Fz_idx_1 / becrktx0d0 . P_248 ; }
loop_ub = i - 1 ; if ( 0 <= loop_ub ) { memcpy ( & z1_data , & Fz_idx_0 , (
loop_ub + 1 ) * sizeof ( real_T ) ) ; } if ( 1 <= i ) { z1_data = z_data *
z_data ; } loop_ub = i - 1 ; for ( i = 0 ; i <= loop_ub ; i ++ ) { z1_data =
2.0 * becrktx0d0 . P_248 / ( 3.0 - z1_data ) ; } Fz_idx_0 = Fz_idx_1 ; if (
Fz_idx_1 < becrktx0d0 . P_248 ) { Fz_idx_0 = z1_data ; } i = 0 ; if (
kglfuzmg0r_idx_0 < 0.0 ) { i = 1 ; } loop_ub = i - 1 ; for ( i = 0 ; i <=
loop_ub ; i ++ ) { z_data = - Fz_idx_0 ; } if ( kglfuzmg0r_idx_0 < 0.0 ) {
Fz_idx_0 = z_data ; } if ( Fz_idx_1 <= becrktx0d0 . P_248 ) { Fz_idx_1 =
muDoubleScalarTanh ( 4.0 * muDoubleScalarAbs ( kglfuzmg0r_idx_1 ) ) ;
ittjpgmzbj_p = ( muDoubleScalarAtan2 ( becrktx0d0 . P_171 * kglfuzmg0r_idx_3
+ kglfuzmg0r_idx_1 , Fz_idx_0 ) - cj3txzi5fm_idx_1 ) * Fz_idx_1 ;
etj3o5lltd_p = ( muDoubleScalarAtan2 ( kglfuzmg0r_idx_1 - becrktx0d0 . P_172
* kglfuzmg0r_idx_3 , Fz_idx_0 ) - muDoubleScalarTanh ( 4.0 * kglfuzmg0r_idx_1
) * 0.0 ) * Fz_idx_1 ; } else { ittjpgmzbj_p = muDoubleScalarAtan2 (
ittjpgmzbj_p , Fz_idx_0 ) - cj3txzi5fm_idx_1 ; etj3o5lltd_p =
muDoubleScalarAtan2 ( etj3o5lltd_p , Fz_idx_0 ) ; } Fz_idx_0 = 0.0 ; Fz_idx_1
= 0.0 ; for ( i = 0 ; i < 6 ; i ++ ) { if ( i == 0 ) { Fy_r = orehnlu50o_p *
becrktx0d0 . P_188 ; Fz_idx_0 = ( ( ( becrktx0d0 . P_183 * becrktx0d0 . P_172
* becrktx0d0 . P_225 + emippuzm0l_p * becrktx0d0 . P_172 ) + Fy_r ) -
fi5veravxh_p [ 1 ] ) / ( becrktx0d0 . P_171 + becrktx0d0 . P_172 ) ; Fz_idx_1
= ( ( ( becrktx0d0 . P_183 * becrktx0d0 . P_171 * becrktx0d0 . P_225 +
emippuzm0l_p * becrktx0d0 . P_171 ) - Fy_r ) + fi5veravxh_p [ 1 ] ) / (
becrktx0d0 . P_171 + becrktx0d0 . P_172 ) ; if ( Fz_idx_0 < 0.0 ) { Fz_idx_0
= 0.0 ; } if ( Fz_idx_1 < 0.0 ) { Fz_idx_1 = 0.0 ; } } Fy_f = - localB ->
op20eyqhn0 * ittjpgmzbj_p * i2orjcd5ae_p * Fz_idx_0 / becrktx0d0 . P_20 ;
Fy_r = - localB -> pj112y04hg * etj3o5lltd_p * hiwzfcmaid_idx_1 * Fz_idx_1 /
becrktx0d0 . P_20 ; gxcyrp3wtv ( cj3txzi5fm_idx_0 , Fy_f , becrktx0d0 . P_258
* Fz_idx_0 / becrktx0d0 . P_20 , becrktx0d0 . P_259 * Fz_idx_0 / becrktx0d0 .
P_20 , & Fx_ft , & Fy_ft ) ; gxcyrp3wtv ( kofgmkkx4p_p , Fy_r , becrktx0d0 .
P_258 * Fz_idx_1 / becrktx0d0 . P_20 , becrktx0d0 . P_259 * Fz_idx_1 /
becrktx0d0 . P_20 , & Fx_rt , & Fz_idx_0 ) ; Fz_idx_1 = muDoubleScalarSin (
cj3txzi5fm_idx_1 ) ; z_data = muDoubleScalarCos ( cj3txzi5fm_idx_1 ) ; Fx_ft
= Fx_ft * z_data - Fy_ft * Fz_idx_1 ; Fy_f = - Fx_ft * Fz_idx_1 + Fy_f *
z_data ; Fy_ft = Fx_rt - Fz_idx_0 * 0.0 ; Fy_r += - Fy_ft * 0.0 ; Fz_idx_1 =
kglfuzmg0r_idx_1 * kglfuzmg0r_idx_3 ; Fx_ft = ( ( ( Fx_ft + Fy_ft ) -
becrktx0d0 . P_183 * 0.0 ) + orehnlu50o_p ) / becrktx0d0 . P_225 + Fz_idx_1 ;
Fy_ft = ( ( Fy_f + Fy_r ) + cj3txzi5fm_idx_2 ) / becrktx0d0 . P_225 + -
kglfuzmg0r_idx_0 * kglfuzmg0r_idx_3 ; Fy_f = ( ( becrktx0d0 . P_171 * Fy_f -
becrktx0d0 . P_172 * Fy_r ) + fi5veravxh_p [ 2 ] ) / becrktx0d0 . P_25 ; Fy_r
= ( Fx_ft - Fz_idx_1 ) * becrktx0d0 . P_188 ; Fz_idx_0 = ( ( ( ( becrktx0d0 .
P_183 * becrktx0d0 . P_172 - Fy_r ) * becrktx0d0 . P_225 + emippuzm0l_p *
becrktx0d0 . P_172 ) + orehnlu50o_p * becrktx0d0 . P_188 ) - fi5veravxh_p [ 1
] ) / ( becrktx0d0 . P_171 + becrktx0d0 . P_172 ) ; Fz_idx_1 = ( ( ( ( Fy_r +
becrktx0d0 . P_183 * becrktx0d0 . P_171 ) * becrktx0d0 . P_225 + emippuzm0l_p
* becrktx0d0 . P_171 ) - orehnlu50o_p * becrktx0d0 . P_188 ) + fi5veravxh_p [
1 ] ) / ( becrktx0d0 . P_171 + becrktx0d0 . P_172 ) ; if ( Fz_idx_0 < 0.0 ) {
Fz_idx_0 = 0.0 ; } if ( Fz_idx_1 < 0.0 ) { Fz_idx_1 = 0.0 ; } Fy_r = Fz_idx_0
; Fx_rt = Fz_idx_1 ; } localB -> kmtb3usggr [ 0 ] = kglfuzmg0r_idx_0 ; localB
-> kmtb3usggr [ 1 ] = kglfuzmg0r_idx_1 ; localB -> kmtb3usggr [ 2 ] = Fx_ft ;
localB -> kmtb3usggr [ 3 ] = Fy_ft ; orehnlu50o_p = muDoubleScalarSin (
kglfuzmg0r_idx_2 ) ; cj3txzi5fm_idx_2 = muDoubleScalarCos ( kglfuzmg0r_idx_2
) ; localB -> kmtb3usggr [ 4 ] = kglfuzmg0r_idx_0 * cj3txzi5fm_idx_2 -
kglfuzmg0r_idx_1 * orehnlu50o_p ; localB -> kmtb3usggr [ 5 ] =
kglfuzmg0r_idx_0 * orehnlu50o_p + kglfuzmg0r_idx_1 * cj3txzi5fm_idx_2 ;
localB -> kmtb3usggr [ 6 ] = kglfuzmg0r_idx_2 ; localB -> kmtb3usggr [ 7 ] =
kglfuzmg0r_idx_3 ; localB -> kmtb3usggr [ 8 ] = okrrl0uxrk_p *
muDoubleScalarCos ( ittjpgmzbj_p ) ; localB -> kmtb3usggr [ 9 ] =
okrrl0uxrk_p * muDoubleScalarSin ( ittjpgmzbj_p ) ; localB -> kmtb3usggr [ 10
] = ft2a2rkagw_p * muDoubleScalarCos ( etj3o5lltd_p ) ; localB -> kmtb3usggr
[ 11 ] = muDoubleScalarAtan ( kglfuzmg0r_idx_1 / kglfuzmg0r_idx_0 ) ; localB
-> kmtb3usggr [ 12 ] = ft2a2rkagw_p * muDoubleScalarSin ( etj3o5lltd_p ) ;
localB -> kmtb3usggr [ 13 ] = ittjpgmzbj_p ; localB -> kmtb3usggr [ 14 ] =
etj3o5lltd_p ; c2xse5ydzd_p [ 2 ] = Fy_r / becrktx0d0 . P_34 ; c2xse5ydzd_p [
5 ] = Fx_rt / becrktx0d0 . P_39 ; localB -> ec40qvdazf [ 0 ] = Fx_ft ; localB
-> ec40qvdazf [ 1 ] = Fy_ft ; localB -> ec40qvdazf [ 2 ] = kglfuzmg0r_idx_3 ;
localB -> ec40qvdazf [ 3 ] = Fy_f ; if ( c2xse5ydzd_p [ 2 ] > becrktx0d0 .
P_480 ) { Fy_f = becrktx0d0 . P_480 ; } else if ( c2xse5ydzd_p [ 2 ] <
becrktx0d0 . P_481 ) { Fy_f = becrktx0d0 . P_481 ; } else { Fy_f =
c2xse5ydzd_p [ 2 ] ; } localB -> lwsbjgunfw [ 0 ] = ( Fy_f - dyojl213t2_idx_0
) * localB -> bqcncmwkew ; if ( c2xse5ydzd_p [ 2 ] > becrktx0d0 . P_480 ) {
Fy_f = becrktx0d0 . P_480 ; } else if ( c2xse5ydzd_p [ 2 ] < becrktx0d0 .
P_481 ) { Fy_f = becrktx0d0 . P_481 ; } else { Fy_f = c2xse5ydzd_p [ 2 ] ; }
localB -> lwsbjgunfw [ 1 ] = ( Fy_f - dyojl213t2_idx_1 ) * localB ->
bqcncmwkew ; if ( c2xse5ydzd_p [ 5 ] > becrktx0d0 . P_480 ) { Fy_f =
becrktx0d0 . P_480 ; } else if ( c2xse5ydzd_p [ 5 ] < becrktx0d0 . P_481 ) {
Fy_f = becrktx0d0 . P_481 ; } else { Fy_f = c2xse5ydzd_p [ 5 ] ; } localB ->
lwsbjgunfw [ 2 ] = ( Fy_f - dyojl213t2_idx_2 ) * localB -> bqcncmwkew ; if (
c2xse5ydzd_p [ 5 ] > becrktx0d0 . P_480 ) { Fy_f = becrktx0d0 . P_480 ; }
else if ( c2xse5ydzd_p [ 5 ] < becrktx0d0 . P_481 ) { Fy_f = becrktx0d0 .
P_481 ; } else { Fy_f = c2xse5ydzd_p [ 5 ] ; } localB -> lwsbjgunfw [ 3 ] = (
Fy_f - dyojl213t2_idx_3 ) * localB -> bqcncmwkew ; if ( rtmIsMajorTimeStep (
hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
l40oei2hak [ 0 ] = becrktx0d0 . P_169 ; localB -> l40oei2hak [ 1 ] =
becrktx0d0 . P_170 ; } if ( localDW -> pyrwzbu0vd != 0 ) { localX ->
azckz4uqjy [ 0 ] = localB -> l40oei2hak [ 0 ] ; localX -> azckz4uqjy [ 1 ] =
localB -> l40oei2hak [ 1 ] ; } * n0fjwjtmw3 = localX -> azckz4uqjy [ 0 ] ; *
pu1mlebux4 = localB -> kmtb3usggr [ 4 ] ; * dfywnyxbtq = localX -> azckz4uqjy
[ 1 ] ; * hxjzroc5ux = localB -> kmtb3usggr [ 5 ] ; * c040sjjy2f =
kglfuzmg0r_idx_2 ; * hb0nga1cnl = kglfuzmg0r_idx_3 ; * lfffcfi0vv =
kglfuzmg0r_idx_0 ; * o4a5winsib = kglfuzmg0r_idx_1 ; if ( rtmIsMajorTimeStep
( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { * av1e2e2zlq =
becrktx0d0 . P_482 ; * hzkodf3i3c = becrktx0d0 . P_483 ; * amgwfcyfmi =
becrktx0d0 . P_484 ; } muDoubleScalarSinCos ( kglfuzmg0r_idx_2 , & ht543eszrl
[ 0 ] , & kglfuzmg0r_idx_1 ) ; muDoubleScalarSinCos ( * hzkodf3i3c , &
ht543eszrl [ 1 ] , & i53l3q5jej_idx_1 ) ; muDoubleScalarSinCos ( * amgwfcyfmi
, & ht543eszrl [ 2 ] , & i53l3q5jej_idx_2 ) ; a0u2l1bnv1_p [ 0 ] =
i53l3q5jej_idx_1 * kglfuzmg0r_idx_1 ; cj3txzi5fm_idx_0 = ht543eszrl [ 2 ] *
ht543eszrl [ 1 ] ; a0u2l1bnv1_p [ 1 ] = cj3txzi5fm_idx_0 * kglfuzmg0r_idx_1 -
i53l3q5jej_idx_2 * ht543eszrl [ 0 ] ; kofgmkkx4p_p = i53l3q5jej_idx_2 *
ht543eszrl [ 1 ] ; a0u2l1bnv1_p [ 2 ] = kofgmkkx4p_p * kglfuzmg0r_idx_1 +
ht543eszrl [ 2 ] * ht543eszrl [ 0 ] ; a0u2l1bnv1_p [ 3 ] = i53l3q5jej_idx_1 *
ht543eszrl [ 0 ] ; a0u2l1bnv1_p [ 4 ] = cj3txzi5fm_idx_0 * ht543eszrl [ 0 ] +
i53l3q5jej_idx_2 * kglfuzmg0r_idx_1 ; a0u2l1bnv1_p [ 5 ] = kofgmkkx4p_p *
ht543eszrl [ 0 ] - ht543eszrl [ 2 ] * kglfuzmg0r_idx_1 ; a0u2l1bnv1_p [ 6 ] =
- ht543eszrl [ 1 ] ; a0u2l1bnv1_p [ 7 ] = ht543eszrl [ 2 ] * i53l3q5jej_idx_1
; a0u2l1bnv1_p [ 8 ] = i53l3q5jej_idx_2 * i53l3q5jej_idx_1 ; a0u2l1bnv1_e [ 0
] = localX -> azckz4uqjy [ 0 ] ; a0u2l1bnv1_e [ 1 ] = localX -> azckz4uqjy [
1 ] ; a0u2l1bnv1_e [ 2 ] = * av1e2e2zlq ; for ( i = 0 ; i < 3 ; i ++ ) {
fi5veravxh_p [ i ] = a0u2l1bnv1_e [ i ] + ( a0u2l1bnv1_p [ 3 * i + 2 ] *
localB -> m5n5c0hsov [ 2 ] + ( a0u2l1bnv1_p [ 3 * i + 1 ] * localB ->
m5n5c0hsov [ 1 ] + a0u2l1bnv1_p [ 3 * i ] * localB -> m5n5c0hsov [ 0 ] ) ) ;
} muDoubleScalarSinCos ( kglfuzmg0r_idx_2 , & kglfuzmg0r_idx_1 , & ht543eszrl
[ 0 ] ) ; muDoubleScalarSinCos ( * hzkodf3i3c , & i53l3q5jej_idx_1 , &
ht543eszrl [ 1 ] ) ; muDoubleScalarSinCos ( * amgwfcyfmi , & i53l3q5jej_idx_2
, & ht543eszrl [ 2 ] ) ; a0u2l1bnv1_p [ 0 ] = ht543eszrl [ 1 ] * ht543eszrl [
0 ] ; a0u2l1bnv1_p [ 1 ] = i53l3q5jej_idx_2 * i53l3q5jej_idx_1 * ht543eszrl [
0 ] - ht543eszrl [ 2 ] * kglfuzmg0r_idx_1 ; cj3txzi5fm_idx_0 = ht543eszrl [ 2
] * i53l3q5jej_idx_1 ; a0u2l1bnv1_p [ 2 ] = cj3txzi5fm_idx_0 * ht543eszrl [ 0
] + i53l3q5jej_idx_2 * kglfuzmg0r_idx_1 ; a0u2l1bnv1_p [ 3 ] = ht543eszrl [ 1
] * kglfuzmg0r_idx_1 ; a0u2l1bnv1_p [ 4 ] = i53l3q5jej_idx_2 *
i53l3q5jej_idx_1 * kglfuzmg0r_idx_1 + ht543eszrl [ 2 ] * ht543eszrl [ 0 ] ;
a0u2l1bnv1_p [ 5 ] = cj3txzi5fm_idx_0 * kglfuzmg0r_idx_1 - i53l3q5jej_idx_2 *
ht543eszrl [ 0 ] ; a0u2l1bnv1_p [ 6 ] = - i53l3q5jej_idx_1 ; a0u2l1bnv1_p [ 7
] = i53l3q5jej_idx_2 * ht543eszrl [ 1 ] ; a0u2l1bnv1_p [ 8 ] = ht543eszrl [ 2
] * ht543eszrl [ 1 ] ; a0u2l1bnv1_e [ 0 ] = localX -> azckz4uqjy [ 0 ] ;
a0u2l1bnv1_e [ 1 ] = localX -> azckz4uqjy [ 1 ] ; a0u2l1bnv1_e [ 2 ] = *
av1e2e2zlq ; for ( i = 0 ; i < 3 ; i ++ ) { ht543eszrl [ i ] = a0u2l1bnv1_e [
i ] + ( a0u2l1bnv1_p [ 3 * i + 2 ] * localB -> o0rhvekxea [ 2 ] + (
a0u2l1bnv1_p [ 3 * i + 1 ] * localB -> o0rhvekxea [ 1 ] + a0u2l1bnv1_p [ 3 *
i ] * localB -> o0rhvekxea [ 0 ] ) ) ; } * cqivd3kemx = ( kglfuzmg0r_idx_0 *
kglfuzmg0r_idx_3 + localB -> kmtb3usggr [ 3 ] ) * 0.10197162129779282 ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> kiuep21v1r = becrktx0d0 . P_244 ; localB -> mypypk30kt =
becrktx0d0 . P_245 ; g2tnztcpzi [ 0 ] = becrktx0d0 . P_487 [ 0 ] ; g2tnztcpzi
[ 1 ] = becrktx0d0 . P_487 [ 1 ] ; g2tnztcpzi [ 2 ] = becrktx0d0 . P_487 [ 2
] ; g2tnztcpzi [ 3 ] = becrktx0d0 . P_487 [ 3 ] ; } localB -> kday3sgiju = (
ittjpgmzbj_p - localX -> afwcyok13n ) * okrrl0uxrk_p / localB -> kiuep21v1r ;
localB -> ie22dwfqte = ( etj3o5lltd_p - localX -> mosvej2yjd ) * ft2a2rkagw_p
/ localB -> mypypk30kt ; eplypn1mx4 [ 0 ] = fi5veravxh_p [ 1 ] ; eplypn1mx4 [
1 ] = 0.0 ; eplypn1mx4 [ 2 ] = ht543eszrl [ 1 ] ; eplypn1mx4 [ 3 ] = 0.0 ;
ebhsrqq1o4 [ 0 ] = fi5veravxh_p [ 0 ] ; ebhsrqq1o4 [ 1 ] = 0.0 ; ebhsrqq1o4 [
2 ] = ht543eszrl [ 0 ] ; ebhsrqq1o4 [ 3 ] = 0.0 ; } void ii3iorkudk (
pa50wxsaaa * const hokadafud5 , id4lpjcjia * localB , bpefjqedzq * localDW )
{ if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { if ( memcmp ( hokadafud5 ->
nonContDerivSignal [ 0 ] . pCurrVal , hokadafud5 -> nonContDerivSignal [ 0 ]
. pPrevVal , hokadafud5 -> nonContDerivSignal [ 0 ] . sizeInBytes ) != 0 ) {
( void ) memcpy ( hokadafud5 -> nonContDerivSignal [ 0 ] . pPrevVal ,
hokadafud5 -> nonContDerivSignal [ 0 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 0 ] . sizeInBytes ) ; ssSetSolverNeedsReset ( hokadafud5
-> _mdlRefSfcnS ) ; } if ( memcmp ( hokadafud5 -> nonContDerivSignal [ 1 ] .
pCurrVal , hokadafud5 -> nonContDerivSignal [ 1 ] . pPrevVal , hokadafud5 ->
nonContDerivSignal [ 1 ] . sizeInBytes ) != 0 ) { ( void ) memcpy (
hokadafud5 -> nonContDerivSignal [ 1 ] . pPrevVal , hokadafud5 ->
nonContDerivSignal [ 1 ] . pCurrVal , hokadafud5 -> nonContDerivSignal [ 1 ]
. sizeInBytes ) ; ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if
( memcmp ( hokadafud5 -> nonContDerivSignal [ 2 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 2 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 2 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
2 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 2 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 2 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 3 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 3 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 3 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
3 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 3 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 3 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 4 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 4 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 4 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
4 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 4 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 4 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 5 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 5 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 5 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
5 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 5 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 5 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 6 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 6 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 6 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
6 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 6 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 6 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 7 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 7 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 7 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
7 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 7 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 7 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 8 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 8 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 8 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
8 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 8 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 8 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 9 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 9 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 9 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
9 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 9 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 9 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 10 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 10 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 10
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 10 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 10 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 10 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 11 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 11 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 11
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 11 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 11 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 11 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 12 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 12 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 12
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 12 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 12 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 12 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 13 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 13 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 13
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 13 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 13 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 13 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 14 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 14 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 14
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 14 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 14 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 14 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 15 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 15 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 15
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 15 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 15 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 15 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 16 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 16 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 16
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 16 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 16 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 16 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 17 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 17 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 17
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 17 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 17 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 17 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 18 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 18 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 18
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 18 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 18 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 18 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } } if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localDW -> pksiahpaaw = localB -> g33vvsnq3o ; } if ( localDW -> hl5oc4enil
== 1 ) { localDW -> em512f0wkt = 0 ; } localDW -> bkwexe1kru = 0 ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localDW -> lb1nn0qgui = localB -> krm0jkmd2d ; localDW -> gbgapftrxi =
localB -> bieyt1db1k ; } if ( localDW -> ngtk3y0d0k == 1 ) { localDW ->
j0vc5sz3xv = 0 ; } if ( localDW -> jcq45ux2tw == 1 ) { localDW -> puigwz3vsu
= 0 ; } if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5
, 1 , 0 ) ) { localDW -> oywcgos5db = localB -> cz1wfypt0w ; } if ( localDW
-> a4hec4xq23 == 1 ) { localDW -> cy5d015mtw = 0 ; } localDW -> pyrwzbu0vd =
0 ; } void iu231drtpw ( id4lpjcjia * localB , bpefjqedzq * localDW ,
ha25zehowz * localXdot ) { localXdot -> ltaqjpquzu [ 0 ] = localB ->
lwsbjgunfw [ 0 ] ; localXdot -> ltaqjpquzu [ 1 ] = localB -> lwsbjgunfw [ 1 ]
; localXdot -> ltaqjpquzu [ 2 ] = localB -> lwsbjgunfw [ 2 ] ; localXdot ->
ltaqjpquzu [ 3 ] = localB -> lwsbjgunfw [ 3 ] ; localXdot -> k0pz3tariu =
localB -> n50351ufzw ; localXdot -> gjqeaf15ke = 0.0 ; if ( localDW ->
hl5oc4enil == 1 ) { localXdot -> gjqeaf15ke = localB -> co0vgrhgxv ; }
localXdot -> asiwx55gg1 [ 0 ] = localB -> ec40qvdazf [ 0 ] ; localXdot ->
asiwx55gg1 [ 1 ] = localB -> ec40qvdazf [ 1 ] ; localXdot -> asiwx55gg1 [ 2 ]
= localB -> ec40qvdazf [ 2 ] ; localXdot -> asiwx55gg1 [ 3 ] = localB ->
ec40qvdazf [ 3 ] ; localXdot -> gswussrcam = localB -> jb3u14tozr ; localXdot
-> bxrckvq45q = 0.0 ; if ( localDW -> ngtk3y0d0k == 1 ) { localXdot ->
bxrckvq45q = localB -> jhibd0fk2e ; } localXdot -> ivyedmn25f = localB ->
olxcszanag ; localXdot -> jg0z2f4dcg = 0.0 ; if ( localDW -> jcq45ux2tw == 1
) { localXdot -> jg0z2f4dcg = localB -> fj5nty1pmy ; } localXdot ->
gn1qleso4d = localB -> p5xem3od3d ; localXdot -> efxruepcrz = 0.0 ; if (
localDW -> a4hec4xq23 == 1 ) { localXdot -> efxruepcrz = localB -> fo02mk51l0
; } localXdot -> azckz4uqjy [ 0 ] = localB -> kmtb3usggr [ 4 ] ; localXdot ->
azckz4uqjy [ 1 ] = localB -> kmtb3usggr [ 5 ] ; localXdot -> afwcyok13n =
localB -> kday3sgiju ; localXdot -> mosvej2yjd = localB -> ie22dwfqte ; }
void pgy4d5vijx ( id4lpjcjia * localB , kg2zcpxtlx * localZCSV ) { localZCSV
-> klicthxs0q = localB -> fp2ilc0ley - becrktx0d0 . P_266 ; localZCSV ->
cazyieeguw = localB -> fp2ilc0ley - becrktx0d0 . P_267 ; localZCSV ->
fh3cfc1ox3 = localB -> peb3w5yei4 - becrktx0d0 . P_322 ; localZCSV ->
bqibk0ztih = localB -> peb3w5yei4 - becrktx0d0 . P_323 ; localZCSV ->
idcgzr5jvx = localB -> cwucxqw2pf - becrktx0d0 . P_373 ; localZCSV ->
c5u3uo2uhe = localB -> cwucxqw2pf - becrktx0d0 . P_374 ; localZCSV ->
cxdkc53ihg = localB -> ffjpij0dzo - becrktx0d0 . P_424 ; localZCSV ->
nq2jz1rqn1 = localB -> ffjpij0dzo - becrktx0d0 . P_425 ; } void b51av3ulwn (
pa50wxsaaa * const hokadafud5 ) { if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( hokadafud5 -> _mdlRefSfcnS , "PassVeh7DOF" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void lahi4jyhaj (
SimStruct * _mdlRefSfcnS , ssNonContDerivSigFeedingOutports * *
mr_nonContOutputArray , int_T mdlref_TID0 , int_T mdlref_TID1 , pa50wxsaaa *
const hokadafud5 , id4lpjcjia * localB , bpefjqedzq * localDW , hcqlainyez *
localX , pcbmq2m11v * localZCE , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T )
) ; becrktx0d0 . P_266 = rtInf ; becrktx0d0 . P_322 = rtInf ; becrktx0d0 .
P_373 = rtInf ; becrktx0d0 . P_424 = rtInf ; ( void ) memset ( ( void * )
hokadafud5 , 0 , sizeof ( pa50wxsaaa ) ) ; hokadafud5 -> Timing .
mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; hokadafud5 -> Timing .
mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; hokadafud5 -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( hokadafud5 -> _mdlRefSfcnS , "PassVeh7DOF" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } ( void ) memset ( ( ( void *
) localB ) , 0 , sizeof ( id4lpjcjia ) ) ; { int32_T i ; for ( i = 0 ; i < 9
; i ++ ) { localB -> fblkngoubr [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ )
{ localB -> a5hv2ji3cc [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB
-> d2yrhfqtgt [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB ->
momgprkjbh [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB ->
bdxkllszng [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB ->
d0ll0sez0n [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB ->
hn1eupnvah [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB ->
og1pl52b0g [ i ] = 0.0 ; } for ( i = 0 ; i < 6 ; i ++ ) { localB ->
irw5bmjnd2 [ i ] = 0.0 ; } for ( i = 0 ; i < 15 ; i ++ ) { localB ->
kmtb3usggr [ i ] = 0.0 ; } for ( i = 0 ; i < 5 ; i ++ ) { localB ->
ehqxxy1j0v . d5h53uezna [ i ] = 0.0 ; } for ( i = 0 ; i < 34 ; i ++ ) {
localB -> ehqxxy1j0v . lfqxtpersw [ i ] = 0.0 ; } for ( i = 0 ; i < 16 ; i ++
) { localB -> ehqxxy1j0v . fb312db3ax [ i ] = 0.0 ; } for ( i = 0 ; i < 24 ;
i ++ ) { localB -> ehqxxy1j0v . axapykoqoq [ i ] = 0.0 ; } for ( i = 0 ; i <
5 ; i ++ ) { localB -> a21t3mltc4 . d5h53uezna [ i ] = 0.0 ; } for ( i = 0 ;
i < 34 ; i ++ ) { localB -> a21t3mltc4 . lfqxtpersw [ i ] = 0.0 ; } for ( i =
0 ; i < 16 ; i ++ ) { localB -> a21t3mltc4 . fb312db3ax [ i ] = 0.0 ; } for (
i = 0 ; i < 24 ; i ++ ) { localB -> a21t3mltc4 . axapykoqoq [ i ] = 0.0 ; }
for ( i = 0 ; i < 5 ; i ++ ) { localB -> lh5kjqwuvr . d5h53uezna [ i ] = 0.0
; } for ( i = 0 ; i < 34 ; i ++ ) { localB -> lh5kjqwuvr . lfqxtpersw [ i ] =
0.0 ; } for ( i = 0 ; i < 16 ; i ++ ) { localB -> lh5kjqwuvr . fb312db3ax [ i
] = 0.0 ; } for ( i = 0 ; i < 24 ; i ++ ) { localB -> lh5kjqwuvr . axapykoqoq
[ i ] = 0.0 ; } for ( i = 0 ; i < 5 ; i ++ ) { localB -> azps4qfrqh .
d5h53uezna [ i ] = 0.0 ; } for ( i = 0 ; i < 34 ; i ++ ) { localB ->
azps4qfrqh . lfqxtpersw [ i ] = 0.0 ; } for ( i = 0 ; i < 16 ; i ++ ) {
localB -> azps4qfrqh . fb312db3ax [ i ] = 0.0 ; } for ( i = 0 ; i < 24 ; i ++
) { localB -> azps4qfrqh . axapykoqoq [ i ] = 0.0 ; } localB -> bs2hjc5nu2 =
0.0 ; localB -> ifttpgshqd = 0.0 ; localB -> euk3scwzss = 0.0 ; localB ->
libbr311cm = 0.0 ; localB -> obpqast420 = 0.0 ; localB -> fp2ilc0ley = 0.0 ;
localB -> n4xonjocfu = 0.0 ; localB -> auwfmt1imw = 0.0 ; localB ->
jm1o4v20ho = 0.0 ; localB -> m5n5c0hsov [ 0 ] = 0.0 ; localB -> m5n5c0hsov [
1 ] = 0.0 ; localB -> m5n5c0hsov [ 2 ] = 0.0 ; localB -> jmb25suz33 = 0.0 ;
localB -> j2p04sytqr [ 0 ] = 0.0 ; localB -> j2p04sytqr [ 1 ] = 0.0 ; localB
-> j2p04sytqr [ 2 ] = 0.0 ; localB -> j2p04sytqr [ 3 ] = 0.0 ; localB ->
l4pg5xpxp1 = 0.0 ; localB -> m4npe54j1c = 0.0 ; localB -> eyxanztqx1 = 0.0 ;
localB -> lcls111zdy = 0.0 ; localB -> o0rhvekxea [ 0 ] = 0.0 ; localB ->
o0rhvekxea [ 1 ] = 0.0 ; localB -> o0rhvekxea [ 2 ] = 0.0 ; localB ->
fvqfpke4jv = 0.0 ; localB -> bjsj1dfvfu = 0.0 ; localB -> aq2vnamn3e = 0.0 ;
localB -> nquucjysva = 0.0 ; localB -> pq0pomxlsc [ 0 ] = 0.0 ; localB ->
pq0pomxlsc [ 1 ] = 0.0 ; localB -> pq0pomxlsc [ 2 ] = 0.0 ; localB ->
pq0pomxlsc [ 3 ] = 0.0 ; localB -> msli3xjzd4 [ 0 ] = 0.0 ; localB ->
msli3xjzd4 [ 1 ] = 0.0 ; localB -> msli3xjzd4 [ 2 ] = 0.0 ; localB ->
msli3xjzd4 [ 3 ] = 0.0 ; localB -> nfqf4trzat = 0.0 ; localB -> e2x3r2jeks =
0.0 ; localB -> jsbuy1s0zh = 0.0 ; localB -> jlqqks3wuo = 0.0 ; localB ->
iolwkpz04u = 0.0 ; localB -> mjrra1hfyg = 0.0 ; localB -> dae0zhs5fy = 0.0 ;
localB -> jp2tjiwtwu = 0.0 ; localB -> ann1feexvg = 0.0 ; localB ->
jkq3y0qfgv = 0.0 ; localB -> c2j5gkccdm = 0.0 ; localB -> ard44y2p1h = 0.0 ;
localB -> iof1dhclh2 = 0.0 ; localB -> fqwn3oyjo3 = 0.0 ; localB ->
jrtvmmjxei = 0.0 ; localB -> gjz1ie5un1 = 0.0 ; localB -> lbp4dfbob0 = 0.0 ;
localB -> hv1i03vcrx = 0.0 ; localB -> eftgclmxsy = 0.0 ; localB ->
b2a12dteat = 0.0 ; localB -> lsasi2uldc = 0.0 ; localB -> g5agc0xg32 = 0.0 ;
localB -> hooc103vyj = 0.0 ; localB -> eeb3auw5nx = 0.0 ; localB ->
ek12timuyq = 0.0 ; localB -> g2srpjb4za = 0.0 ; localB -> ky55fcx12u = 0.0 ;
localB -> lli4msildn = 0.0 ; localB -> ekonhtwtew = 0.0 ; localB ->
kzdtcoisvi = 0.0 ; localB -> ivswn3mcce = 0.0 ; localB -> klywadtuwk = 0.0 ;
localB -> bc5mpnnywl = 0.0 ; localB -> p4dxuexhmn = 0.0 ; localB ->
dgacotjrc4 = 0.0 ; localB -> opivgwwsqb = 0.0 ; localB -> abpryvvknk = 0.0 ;
localB -> kkloewbxvk = 0.0 ; localB -> dcwkj3tspn [ 0 ] = 0.0 ; localB ->
dcwkj3tspn [ 1 ] = 0.0 ; localB -> dcwkj3tspn [ 2 ] = 0.0 ; localB ->
agcbzjjxc2 [ 0 ] = 0.0 ; localB -> agcbzjjxc2 [ 1 ] = 0.0 ; localB ->
agcbzjjxc2 [ 2 ] = 0.0 ; localB -> bgbdvzlrnp = 0.0 ; localB -> ei3jjsazbv =
0.0 ; localB -> l1sbdzlbft = 0.0 ; localB -> hrdyz2htuu = 0.0 ; localB ->
g22rfrhcci = 0.0 ; localB -> d51egdrz0z = 0.0 ; localB -> gmqaszorzp = 0.0 ;
localB -> pu4cguusa5 = 0.0 ; localB -> hawqte0lkp = 0.0 ; localB ->
fqfqbihpo4 = 0.0 ; localB -> fcmrvrr5m4 = 0.0 ; localB -> aewmk31j2l = 0.0 ;
localB -> ilblxiaesg = 0.0 ; localB -> csbz5vwjbl = 0.0 ; localB ->
efotijbqgm = 0.0 ; localB -> dn24fdverp [ 0 ] = 0.0 ; localB -> dn24fdverp [
1 ] = 0.0 ; localB -> dn24fdverp [ 2 ] = 0.0 ; localB -> mpurjwwdjq [ 0 ] =
0.0 ; localB -> mpurjwwdjq [ 1 ] = 0.0 ; localB -> mpurjwwdjq [ 2 ] = 0.0 ;
localB -> fkg40b3zq2 = 0.0 ; localB -> amzgulqp12 = 0.0 ; localB ->
ijjphmn2q0 = 0.0 ; localB -> hu5pmd13z1 = 0.0 ; localB -> nfnujv3tc2 = 0.0 ;
localB -> mqhdsdepts = 0.0 ; localB -> igbd4extak = 0.0 ; localB ->
onrl0wpwlm = 0.0 ; localB -> bonsvi0den = 0.0 ; localB -> pe2ebnzhq4 = 0.0 ;
localB -> isr01bpmsd = 0.0 ; localB -> glwizfkrzi = 0.0 ; localB ->
j0032htb5y = 0.0 ; localB -> fmvdhgj0c5 = 0.0 ; localB -> obgyaeas1p = 0.0 ;
localB -> jm54t5nyht = 0.0 ; localB -> am0wr3vakl = 0.0 ; localB ->
hbjg5ycjap = 0.0 ; localB -> flo2k44qyj = 0.0 ; localB -> fsb2e41l0m = 0.0 ;
localB -> m2xjbusmco = 0.0 ; localB -> lhyhzghz5g = 0.0 ; localB ->
ldco5bshns = 0.0 ; localB -> pxbcgurxxp = 0.0 ; localB -> d3b0uleyfa = 0.0 ;
localB -> gssojkvg2t = 0.0 ; localB -> kihaqcuhgw = 0.0 ; localB ->
p4l2o41od2 = 0.0 ; localB -> dlgefiim2f = 0.0 ; localB -> p3yundq3ew = 0.0 ;
localB -> p5c41u4oxs = 0.0 ; localB -> peb3w5yei4 = 0.0 ; localB ->
nguio0nz2d = 0.0 ; localB -> g5igejoxg1 = 0.0 ; localB -> c0ja0z23dg = 0.0 ;
localB -> gya0kbnvv3 = 0.0 ; localB -> e543wt05dh = 0.0 ; localB ->
naonrfraas = 0.0 ; localB -> d5pcl30hua = 0.0 ; localB -> enzmk5pf4o = 0.0 ;
localB -> njc1netzs3 = 0.0 ; localB -> psrn2rspbv = 0.0 ; localB ->
fx4bdcvxja = 0.0 ; localB -> hv0jodqqs3 = 0.0 ; localB -> f5mcrvxmrt = 0.0 ;
localB -> fcxug0bpsn = 0.0 ; localB -> jhysjc540s = 0.0 ; localB ->
mssyoofqpv = 0.0 ; localB -> ffpimvq1sz = 0.0 ; localB -> jf4jh5rlz0 = 0.0 ;
localB -> jc5dmbapbw = 0.0 ; localB -> pspspmf0qs = 0.0 ; localB ->
cm4en5t1nq = 0.0 ; localB -> mjlza1k4nu = 0.0 ; localB -> klxatjmabe = 0.0 ;
localB -> dobyt3vkx4 = 0.0 ; localB -> evss2jjgrf = 0.0 ; localB ->
gd03u24ntw = 0.0 ; localB -> pjb4lrl0ur = 0.0 ; localB -> a5enc0h5cl = 0.0 ;
localB -> fctmvus1du = 0.0 ; localB -> jdp4a2z1g5 = 0.0 ; localB ->
nf05aww25e = 0.0 ; localB -> goghp2x2da = 0.0 ; localB -> mot0j1tqma = 0.0 ;
localB -> pq2fabvz5k = 0.0 ; localB -> mjreasqhek = 0.0 ; localB ->
iftdgrsa05 = 0.0 ; localB -> apqabofwu5 = 0.0 ; localB -> aqds0ofasd = 0.0 ;
localB -> bwclupiqxv = 0.0 ; localB -> mo0zpwakun = 0.0 ; localB ->
n4bp4zjfwv [ 0 ] = 0.0 ; localB -> n4bp4zjfwv [ 1 ] = 0.0 ; localB ->
n4bp4zjfwv [ 2 ] = 0.0 ; localB -> frm4syq440 [ 0 ] = 0.0 ; localB ->
frm4syq440 [ 1 ] = 0.0 ; localB -> frm4syq440 [ 2 ] = 0.0 ; localB ->
nvi4gppmvv = 0.0 ; localB -> fkxmdwac2r = 0.0 ; localB -> htjp5ek3fq = 0.0 ;
localB -> oczgpffard = 0.0 ; localB -> az5q3j0bed = 0.0 ; localB ->
pmkft3x5ig = 0.0 ; localB -> izf5s33tmm = 0.0 ; localB -> bxoaokm1pa = 0.0 ;
localB -> a54mfanpi0 = 0.0 ; localB -> jng0vonz3d = 0.0 ; localB ->
jctvycvsp0 = 0.0 ; localB -> jrmweg4c4j = 0.0 ; localB -> mhsrh5emdu = 0.0 ;
localB -> df5dtpkovu = 0.0 ; localB -> bbyxlrphmc = 0.0 ; localB ->
crkky0j4wi [ 0 ] = 0.0 ; localB -> crkky0j4wi [ 1 ] = 0.0 ; localB ->
crkky0j4wi [ 2 ] = 0.0 ; localB -> oc3syc1had [ 0 ] = 0.0 ; localB ->
oc3syc1had [ 1 ] = 0.0 ; localB -> oc3syc1had [ 2 ] = 0.0 ; localB ->
hzdrl0i0ia = 0.0 ; localB -> p2dtigkgaf = 0.0 ; localB -> mimwv5dvzs = 0.0 ;
localB -> kwzep05ody = 0.0 ; localB -> c2izl10ezo = 0.0 ; localB ->
b1kjrb022n = 0.0 ; localB -> pvy3vbjvw2 = 0.0 ; localB -> bnf3dwud1m = 0.0 ;
localB -> idvzhvb5zm = 0.0 ; localB -> ebvkurz4ue = 0.0 ; localB ->
dakmjltvg3 = 0.0 ; localB -> lp31hztb55 = 0.0 ; localB -> kckinb301k = 0.0 ;
localB -> ibgpb5vvta = 0.0 ; localB -> pwyeshcpv2 = 0.0 ; localB ->
mq4nm2marh = 0.0 ; localB -> gcukvt1mcv = 0.0 ; localB -> g00ccjwa2j = 0.0 ;
localB -> numplzjehj = 0.0 ; localB -> cdhvl0jekq = 0.0 ; localB ->
m5x1rc5v2c = 0.0 ; localB -> phkg0eilwd = 0.0 ; localB -> e1wyvqrgpd = 0.0 ;
localB -> lbmhaqyph2 = 0.0 ; localB -> d2sicg5t5v = 0.0 ; localB ->
ddkgx3utjf = 0.0 ; localB -> jqra0qrc4f = 0.0 ; localB -> numsq4h5aq = 0.0 ;
localB -> hxumbizg0d = 0.0 ; localB -> c1ee4phlss = 0.0 ; localB ->
a4c0lwlpcd = 0.0 ; localB -> cwucxqw2pf = 0.0 ; localB -> ejgbaymku3 = 0.0 ;
localB -> jiue5code2 = 0.0 ; localB -> ikj1m0o4mz = 0.0 ; localB ->
ax00hnppth = 0.0 ; localB -> k4tb3ntsf3 = 0.0 ; localB -> nphikq3xj1 = 0.0 ;
localB -> dl30i01l3p = 0.0 ; localB -> fd0hla2abn = 0.0 ; localB ->
lsaj5xk0ks = 0.0 ; localB -> bwvxjyivut = 0.0 ; localB -> mwzifv1a5c = 0.0 ;
localB -> jmchmvxfhq = 0.0 ; localB -> pqdxxygisp = 0.0 ; localB ->
ec2ephpzxi = 0.0 ; localB -> pyeudtquzg = 0.0 ; localB -> dmcfkawsjf = 0.0 ;
localB -> hftqavup3t = 0.0 ; localB -> esoh5l5lxo = 0.0 ; localB ->
idctxzieo0 = 0.0 ; localB -> hphiagg0re = 0.0 ; localB -> f1mzffw2ii = 0.0 ;
localB -> bwacdjho4y = 0.0 ; localB -> bkuuxygiqv = 0.0 ; localB ->
cvklcpcg5h = 0.0 ; localB -> ks5imzrjrb = 0.0 ; localB -> pjn2ul1e5q = 0.0 ;
localB -> cq0ulc5p42 = 0.0 ; localB -> m4jgqymj3m = 0.0 ; localB ->
kfu4rsdusc = 0.0 ; localB -> agahu4jva1 = 0.0 ; localB -> d0mwow1ynj = 0.0 ;
localB -> chvcqjgtkd = 0.0 ; localB -> ggy510ulkr = 0.0 ; localB ->
fefyztusl5 = 0.0 ; localB -> n2oqsfqzgf = 0.0 ; localB -> p2ew0hvidw = 0.0 ;
localB -> kpt4zd10sl = 0.0 ; localB -> iprkzcw0uf = 0.0 ; localB ->
gbyou3x5qj = 0.0 ; localB -> lxntqw3pa0 = 0.0 ; localB -> gzjvzppbfb [ 0 ] =
0.0 ; localB -> gzjvzppbfb [ 1 ] = 0.0 ; localB -> gzjvzppbfb [ 2 ] = 0.0 ;
localB -> bwdfn5yr4y [ 0 ] = 0.0 ; localB -> bwdfn5yr4y [ 1 ] = 0.0 ; localB
-> bwdfn5yr4y [ 2 ] = 0.0 ; localB -> phqr3dlt5s = 0.0 ; localB -> b55anpz0ry
= 0.0 ; localB -> avaxnmw4it = 0.0 ; localB -> aawt1jhkmi = 0.0 ; localB ->
ffzea14g1z = 0.0 ; localB -> my5flu2qpd = 0.0 ; localB -> lvuprdvd3t = 0.0 ;
localB -> m2ee3ab4rk = 0.0 ; localB -> lgmuosmxxg = 0.0 ; localB ->
mvhbt05gbg = 0.0 ; localB -> jamrnffszs = 0.0 ; localB -> osgfr2nr12 = 0.0 ;
localB -> gifebyd4pm = 0.0 ; localB -> ccgbuww52i = 0.0 ; localB ->
g5n0tdcjyr = 0.0 ; localB -> odtlbjxf5w [ 0 ] = 0.0 ; localB -> odtlbjxf5w [
1 ] = 0.0 ; localB -> odtlbjxf5w [ 2 ] = 0.0 ; localB -> pwd3yzcihq [ 0 ] =
0.0 ; localB -> pwd3yzcihq [ 1 ] = 0.0 ; localB -> pwd3yzcihq [ 2 ] = 0.0 ;
localB -> jpv5umn2ki = 0.0 ; localB -> hh1kadovlv = 0.0 ; localB ->
cy1u0ypjlh = 0.0 ; localB -> gjgv4vigdp = 0.0 ; localB -> ghvh2gsyqo = 0.0 ;
localB -> iy3agwh4zg = 0.0 ; localB -> lhgq3j20k1 = 0.0 ; localB ->
ezwciwsl2z = 0.0 ; localB -> hcx3b2oh2i = 0.0 ; localB -> l15sbazs2h = 0.0 ;
localB -> cbktnow5af = 0.0 ; localB -> anpxn4wrup = 0.0 ; localB ->
cw3x2kv3z4 = 0.0 ; localB -> ai5l40b3iu = 0.0 ; localB -> dlwvafx3n4 = 0.0 ;
localB -> a0nueplqwy = 0.0 ; localB -> lqlya1zs1k = 0.0 ; localB ->
j5ypkiaj2a = 0.0 ; localB -> nq0m5padfo = 0.0 ; localB -> esrllkz3f1 = 0.0 ;
localB -> ndadoi2fa3 = 0.0 ; localB -> ffmdhdniyz = 0.0 ; localB ->
m2ljmb52uk = 0.0 ; localB -> i3rgk5at5k = 0.0 ; localB -> g1zar4icoz = 0.0 ;
localB -> byvynht2aq = 0.0 ; localB -> edkbwlt3se = 0.0 ; localB ->
d0sjqehaob = 0.0 ; localB -> pnxjm41zmq = 0.0 ; localB -> ngpz2fg5xy = 0.0 ;
localB -> mujuob30yn = 0.0 ; localB -> ffjpij0dzo = 0.0 ; localB ->
lukjivu0vn = 0.0 ; localB -> nmo0dyqft2 = 0.0 ; localB -> cahbswhyq0 = 0.0 ;
localB -> aw4g54p2uq = 0.0 ; localB -> bzighdfjyo = 0.0 ; localB ->
i5a0blv02u = 0.0 ; localB -> oapfg21ir4 = 0.0 ; localB -> oovcrc5txw = 0.0 ;
localB -> bzyvjhcmks = 0.0 ; localB -> kfwsnou0z4 = 0.0 ; localB ->
pbplrkuu32 = 0.0 ; localB -> j4wcufg5bl = 0.0 ; localB -> gaudlnhvry = 0.0 ;
localB -> fjxzajipkt = 0.0 ; localB -> hk4hnaqvh4 = 0.0 ; localB ->
cs5bymast3 = 0.0 ; localB -> p42tgrvop2 = 0.0 ; localB -> fbpvzxbevm = 0.0 ;
localB -> h3f101zvdb = 0.0 ; localB -> jqkgvym2zy = 0.0 ; localB ->
fazkrkbsxw = 0.0 ; localB -> fazs2yxbxy = 0.0 ; localB -> bzm41rdvhu = 0.0 ;
localB -> e3rsqlqayr = 0.0 ; localB -> h10xaj22p2 = 0.0 ; localB ->
mabbx0oage = 0.0 ; localB -> kazjkxua33 = 0.0 ; localB -> dwihbkixr5 = 0.0 ;
localB -> cxjni4j3is = 0.0 ; localB -> geyriwpbwk = 0.0 ; localB ->
a0g100tdyx = 0.0 ; localB -> dwl1yvwrok = 0.0 ; localB -> g1di3z0153 = 0.0 ;
localB -> cy1ie2jyct = 0.0 ; localB -> ncet2youct = 0.0 ; localB ->
atyxanxoep = 0.0 ; localB -> fmo10qy00d = 0.0 ; localB -> ded4oex3nw = 0.0 ;
localB -> lwb0azt42l = 0.0 ; localB -> mdk0qxouay = 0.0 ; localB ->
if32pa3y2y [ 0 ] = 0.0 ; localB -> if32pa3y2y [ 1 ] = 0.0 ; localB ->
if32pa3y2y [ 2 ] = 0.0 ; localB -> bxgniuki54 [ 0 ] = 0.0 ; localB ->
bxgniuki54 [ 1 ] = 0.0 ; localB -> bxgniuki54 [ 2 ] = 0.0 ; localB ->
lqykprkdhp = 0.0 ; localB -> owjgcyyrc4 = 0.0 ; localB -> k0jiqk4jr5 = 0.0 ;
localB -> boiphodd5u = 0.0 ; localB -> jlpvps21xb = 0.0 ; localB ->
favd3zjtdv = 0.0 ; localB -> iwzzewai5j = 0.0 ; localB -> nfccvfr0wr = 0.0 ;
localB -> bcuxkc4ifo = 0.0 ; localB -> hoswk5rqzo = 0.0 ; localB ->
cycn42gkig = 0.0 ; localB -> g5xthmjg3u = 0.0 ; localB -> axyino1l23 = 0.0 ;
localB -> bhwnfpdnfh = 0.0 ; localB -> pndhwp3wlp = 0.0 ; localB ->
jlcsqepfsn [ 0 ] = 0.0 ; localB -> jlcsqepfsn [ 1 ] = 0.0 ; localB ->
jlcsqepfsn [ 2 ] = 0.0 ; localB -> dnkaqrpiwe [ 0 ] = 0.0 ; localB ->
dnkaqrpiwe [ 1 ] = 0.0 ; localB -> dnkaqrpiwe [ 2 ] = 0.0 ; localB ->
eyv2b315td = 0.0 ; localB -> oewprz1max = 0.0 ; localB -> i4wafwdq1d = 0.0 ;
localB -> nrhk0fg5tx = 0.0 ; localB -> jxyonkwdpp = 0.0 ; localB ->
nfkwuggdv3 = 0.0 ; localB -> hd2mkgvcqr = 0.0 ; localB -> bvmbxvyhou = 0.0 ;
localB -> g0dyej4unr = 0.0 ; localB -> adz43gjvi4 = 0.0 ; localB ->
extqw4ppik = 0.0 ; localB -> i4mqp0hn3c = 0.0 ; localB -> lzx3txh2r5 = 0.0 ;
localB -> ein31d03ch = 0.0 ; localB -> mddsia1bs4 = 0.0 ; localB ->
mkx1rcyupl = 0.0 ; localB -> cjm2jf0thg = 0.0 ; localB -> g41hsn0s2r = 0.0 ;
localB -> jzaawga3sf = 0.0 ; localB -> nzfdb2qwys = 0.0 ; localB ->
jucxtg5ndo = 0.0 ; localB -> ij0qesxo0x = 0.0 ; localB -> o01kjgusit = 0.0 ;
localB -> jbiokc52mb = 0.0 ; localB -> bdgo5lorke = 0.0 ; localB ->
lmed21unhr = 0.0 ; localB -> a5yzeqgxla = 0.0 ; localB -> eh21inp54r = 0.0 ;
localB -> ckk03rh1z3 = 0.0 ; localB -> n50351ufzw = 0.0 ; localB ->
oycbd4zsdl = 0.0 ; localB -> awmjhwqf1y = 0.0 ; localB -> g45hl5q3iu = 0.0 ;
localB -> jb3u14tozr = 0.0 ; localB -> dwdzvq30lg = 0.0 ; localB ->
j1uvqqhzuk = 0.0 ; localB -> la15gblmjr = 0.0 ; localB -> olxcszanag = 0.0 ;
localB -> ewlwxcybqs = 0.0 ; localB -> mdhbuol5q1 = 0.0 ; localB ->
efv5l1pqam = 0.0 ; localB -> p5xem3od3d = 0.0 ; localB -> bqcncmwkew = 0.0 ;
localB -> dbjccy0p5m [ 0 ] = 0.0 ; localB -> dbjccy0p5m [ 1 ] = 0.0 ; localB
-> dbjccy0p5m [ 2 ] = 0.0 ; localB -> ey5vfxyzqq [ 0 ] = 0.0 ; localB ->
ey5vfxyzqq [ 1 ] = 0.0 ; localB -> ey5vfxyzqq [ 2 ] = 0.0 ; localB ->
k5ghw3u455 = 0.0 ; localB -> hyntqlru1a = 0.0 ; localB -> op20eyqhn0 = 0.0 ;
localB -> pj112y04hg = 0.0 ; localB -> lwsbjgunfw [ 0 ] = 0.0 ; localB ->
lwsbjgunfw [ 1 ] = 0.0 ; localB -> lwsbjgunfw [ 2 ] = 0.0 ; localB ->
lwsbjgunfw [ 3 ] = 0.0 ; localB -> l40oei2hak [ 0 ] = 0.0 ; localB ->
l40oei2hak [ 1 ] = 0.0 ; localB -> kiuep21v1r = 0.0 ; localB -> mypypk30kt =
0.0 ; localB -> kday3sgiju = 0.0 ; localB -> ie22dwfqte = 0.0 ; localB ->
ec40qvdazf [ 0 ] = 0.0 ; localB -> ec40qvdazf [ 1 ] = 0.0 ; localB ->
ec40qvdazf [ 2 ] = 0.0 ; localB -> ec40qvdazf [ 3 ] = 0.0 ; localB ->
fp0lz1z3pw [ 0 ] = 0.0 ; localB -> fp0lz1z3pw [ 1 ] = 0.0 ; localB ->
fp0lz1z3pw [ 2 ] = 0.0 ; localB -> fp0lz1z3pw [ 3 ] = 0.0 ; localB ->
fo02mk51l0 = 0.0 ; localB -> fj5nty1pmy = 0.0 ; localB -> jhibd0fk2e = 0.0 ;
localB -> co0vgrhgxv = 0.0 ; localB -> eiud0ciipq . pxdy3z0dbu = 0.0 ; localB
-> ehqxxy1j0v . jufyrxj0jc = 0.0 ; localB -> ehqxxy1j0v . jpw2xvx5f1 = 0.0 ;
localB -> jekbgdtwun . pxdy3z0dbu = 0.0 ; localB -> a21t3mltc4 . jufyrxj0jc =
0.0 ; localB -> a21t3mltc4 . jpw2xvx5f1 = 0.0 ; localB -> kwvhl4ef3q .
pxdy3z0dbu = 0.0 ; localB -> lh5kjqwuvr . jufyrxj0jc = 0.0 ; localB ->
lh5kjqwuvr . jpw2xvx5f1 = 0.0 ; localB -> ekmk5spjxa3 . pxdy3z0dbu = 0.0 ;
localB -> azps4qfrqh . jufyrxj0jc = 0.0 ; localB -> azps4qfrqh . jpw2xvx5f1 =
0.0 ; } ( void ) memset ( ( void * ) localDW , 0 , sizeof ( bpefjqedzq ) ) ;
PassVeh7DOF_InitializeDataMapInfo ( hokadafud5 , localDW , localX , sysRanPtr
, contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != (
NULL ) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & (
hokadafud5 -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( hokadafud5 ->
DataMapInfo . mmi , rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex (
hokadafud5 -> DataMapInfo . mmi , rt_CSTATEIdx ) ; } hokadafud5 ->
nonContDerivSignal [ 0 ] . pPrevVal = ( char_T * ) hokadafud5 ->
NonContDerivMemory . mr_nonContSig0 ; hokadafud5 -> nonContDerivSignal [ 0 ]
. sizeInBytes = ( 3 * sizeof ( real_T ) ) ; hokadafud5 -> nonContDerivSignal
[ 0 ] . pCurrVal = ( char_T * ) ( & localB -> ey5vfxyzqq [ 0 ] ) ; ;
hokadafud5 -> nonContDerivSignal [ 1 ] . pPrevVal = ( char_T * ) hokadafud5
-> NonContDerivMemory . mr_nonContSig1 ; hokadafud5 -> nonContDerivSignal [ 1
] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ; hokadafud5 ->
nonContDerivSignal [ 1 ] . pCurrVal = ( char_T * ) ( & localB -> ngpz2fg5xy )
; ; hokadafud5 -> nonContDerivSignal [ 2 ] . pPrevVal = ( char_T * )
hokadafud5 -> NonContDerivMemory . mr_nonContSig2 ; hokadafud5 ->
nonContDerivSignal [ 2 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 2 ] . pCurrVal = ( char_T * ) ( & localB
-> d0sjqehaob ) ; ; hokadafud5 -> nonContDerivSignal [ 3 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig3 ; hokadafud5 ->
nonContDerivSignal [ 3 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 3 ] . pCurrVal = ( char_T * ) ( & localB
-> c1ee4phlss ) ; ; hokadafud5 -> nonContDerivSignal [ 4 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig4 ; hokadafud5 ->
nonContDerivSignal [ 4 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 4 ] . pCurrVal = ( char_T * ) ( & localB
-> numsq4h5aq ) ; ; hokadafud5 -> nonContDerivSignal [ 5 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig5 ; hokadafud5 ->
nonContDerivSignal [ 5 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 5 ] . pCurrVal = ( char_T * ) ( & localB
-> p3yundq3ew ) ; ; hokadafud5 -> nonContDerivSignal [ 6 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig6 ; hokadafud5 ->
nonContDerivSignal [ 6 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 6 ] . pCurrVal = ( char_T * ) ( & localB
-> p4l2o41od2 ) ; ; hokadafud5 -> nonContDerivSignal [ 7 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig7 ; hokadafud5 ->
nonContDerivSignal [ 7 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 7 ] . pCurrVal = ( char_T * ) ( & localB
-> nquucjysva ) ; ; hokadafud5 -> nonContDerivSignal [ 8 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig8 ; hokadafud5 ->
nonContDerivSignal [ 8 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 8 ] . pCurrVal = ( char_T * ) ( & localB
-> aq2vnamn3e ) ; ; hokadafud5 -> nonContDerivSignal [ 9 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig9 ; hokadafud5 ->
nonContDerivSignal [ 9 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 9 ] . pCurrVal = ( char_T * ) ( & localB
-> bjsj1dfvfu ) ; ; hokadafud5 -> nonContDerivSignal [ 10 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig10 ; hokadafud5 ->
nonContDerivSignal [ 10 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 10 ] . pCurrVal = ( char_T * ) ( & localB
-> fvqfpke4jv ) ; ; hokadafud5 -> nonContDerivSignal [ 11 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig11 ; hokadafud5 ->
nonContDerivSignal [ 11 ] . sizeInBytes = ( 3 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 11 ] . pCurrVal = ( char_T * ) ( & localB
-> o0rhvekxea [ 0 ] ) ; ; hokadafud5 -> nonContDerivSignal [ 12 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig12 ;
hokadafud5 -> nonContDerivSignal [ 12 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 12 ] . pCurrVal = ( char_T * ) ( &
localB -> eyxanztqx1 ) ; ; hokadafud5 -> nonContDerivSignal [ 13 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig13 ;
hokadafud5 -> nonContDerivSignal [ 13 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 13 ] . pCurrVal = ( char_T * ) ( &
localB -> m4npe54j1c ) ; ; hokadafud5 -> nonContDerivSignal [ 14 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig14 ;
hokadafud5 -> nonContDerivSignal [ 14 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 14 ] . pCurrVal = ( char_T * ) ( &
localB -> l4pg5xpxp1 ) ; ; hokadafud5 -> nonContDerivSignal [ 15 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig15 ;
hokadafud5 -> nonContDerivSignal [ 15 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 15 ] . pCurrVal = ( char_T * ) ( &
localB -> jmb25suz33 ) ; ; hokadafud5 -> nonContDerivSignal [ 16 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig16 ;
hokadafud5 -> nonContDerivSignal [ 16 ] . sizeInBytes = ( 3 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 16 ] . pCurrVal = ( char_T * ) ( &
localB -> m5n5c0hsov [ 0 ] ) ; ; hokadafud5 -> nonContDerivSignal [ 17 ] .
pPrevVal = ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig17 ;
hokadafud5 -> nonContDerivSignal [ 17 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 17 ] . pCurrVal = ( char_T * ) ( &
localB -> libbr311cm ) ; ; hokadafud5 -> nonContDerivSignal [ 18 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig18 ;
hokadafud5 -> nonContDerivSignal [ 18 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 18 ] . pCurrVal = ( char_T * ) ( &
localB -> ifttpgshqd ) ; ; if ( mr_nonContOutputArray [ 6 ] != ( NULL ) ) {
mr_nonContOutputArray [ 6 ] [ 0 ] . sizeInBytes = 1 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 6 ] [ 0 ] . currVal = ( char_T * ) & localB ->
nquucjysva ; mr_nonContOutputArray [ 6 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 1 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 1 ] . currVal = ( char_T * ) &
localB -> aq2vnamn3e ; mr_nonContOutputArray [ 6 ] [ 1 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 2 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 2 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 2 ] . currVal = ( char_T * ) &
localB -> bjsj1dfvfu ; mr_nonContOutputArray [ 6 ] [ 2 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 3 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 3 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 3 ] . currVal = ( char_T * ) &
localB -> fvqfpke4jv ; mr_nonContOutputArray [ 6 ] [ 3 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 4 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 4 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 4 ] . currVal = ( char_T * ) &
localB -> o0rhvekxea [ 0 ] ; mr_nonContOutputArray [ 6 ] [ 4 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 5 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 5 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 5 ] . currVal = ( char_T * ) &
localB -> eyxanztqx1 ; mr_nonContOutputArray [ 6 ] [ 5 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 6 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 6 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 6 ] . currVal = ( char_T * ) &
localB -> m4npe54j1c ; mr_nonContOutputArray [ 6 ] [ 6 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 7 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 7 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 7 ] . currVal = ( char_T * ) &
localB -> l4pg5xpxp1 ; mr_nonContOutputArray [ 6 ] [ 7 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 8 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 8 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 8 ] . currVal = ( char_T * ) &
localB -> jmb25suz33 ; mr_nonContOutputArray [ 6 ] [ 8 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 9 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 9 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 9 ] . currVal = ( char_T * ) &
localB -> m5n5c0hsov [ 0 ] ; mr_nonContOutputArray [ 6 ] [ 9 ] . next = (
NULL ) ; } if ( mr_nonContOutputArray [ 8 ] != ( NULL ) ) {
mr_nonContOutputArray [ 8 ] [ 0 ] . sizeInBytes = 3 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 8 ] [ 0 ] . currVal = ( char_T * ) & localB ->
ey5vfxyzqq [ 0 ] ; mr_nonContOutputArray [ 8 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 1 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 1 ] . currVal = ( char_T * ) &
localB -> nquucjysva ; mr_nonContOutputArray [ 8 ] [ 1 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 2 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 2 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 2 ] . currVal = ( char_T * ) &
localB -> aq2vnamn3e ; mr_nonContOutputArray [ 8 ] [ 2 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 3 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 3 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 3 ] . currVal = ( char_T * ) &
localB -> bjsj1dfvfu ; mr_nonContOutputArray [ 8 ] [ 3 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 4 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 4 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 4 ] . currVal = ( char_T * ) &
localB -> fvqfpke4jv ; mr_nonContOutputArray [ 8 ] [ 4 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 5 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 5 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 5 ] . currVal = ( char_T * ) &
localB -> o0rhvekxea [ 0 ] ; mr_nonContOutputArray [ 8 ] [ 5 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 6 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 6 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 6 ] . currVal = ( char_T * ) &
localB -> eyxanztqx1 ; mr_nonContOutputArray [ 8 ] [ 6 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 7 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 7 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 7 ] . currVal = ( char_T * ) &
localB -> m4npe54j1c ; mr_nonContOutputArray [ 8 ] [ 7 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 8 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 8 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 8 ] . currVal = ( char_T * ) &
localB -> l4pg5xpxp1 ; mr_nonContOutputArray [ 8 ] [ 8 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 9 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 9 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 9 ] . currVal = ( char_T * ) &
localB -> jmb25suz33 ; mr_nonContOutputArray [ 8 ] [ 9 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 10 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 10 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 10 ] . currVal = ( char_T * ) &
localB -> m5n5c0hsov [ 0 ] ; mr_nonContOutputArray [ 8 ] [ 10 ] . next = (
NULL ) ; } if ( mr_nonContOutputArray [ 12 ] != ( NULL ) ) {
mr_nonContOutputArray [ 12 ] [ 0 ] . sizeInBytes = 3 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 12 ] [ 0 ] . currVal = ( char_T * ) & localB ->
ey5vfxyzqq [ 0 ] ; mr_nonContOutputArray [ 12 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 12 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 12 ] !=
( NULL ) ) { mr_nonContOutputArray [ 12 ] [ 1 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 12 ] [ 1 ] . currVal = ( char_T * ) &
localB -> nquucjysva ; mr_nonContOutputArray [ 12 ] [ 1 ] . next = & (
mr_nonContOutputArray [ 12 ] [ 2 ] ) ; } if ( mr_nonContOutputArray [ 12 ] !=
( NULL ) ) { mr_nonContOutputArray [ 12 ] [ 2 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 12 ] [ 2 ] . currVal = ( char_T * ) &
localB -> aq2vnamn3e ; mr_nonContOutputArray [ 12 ] [ 2 ] . next = & (
mr_nonContOutputArray [ 12 ] [ 3 ] ) ; } if ( mr_nonContOutputArray [ 12 ] !=
( NULL ) ) { mr_nonContOutputArray [ 12 ] [ 3 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 12 ] [ 3 ] . currVal = ( char_T * ) &
localB -> bjsj1dfvfu ; mr_nonContOutputArray [ 12 ] [ 3 ] . next = & (
mr_nonContOutputArray [ 12 ] [ 4 ] ) ; } if ( mr_nonContOutputArray [ 12 ] !=
( NULL ) ) { mr_nonContOutputArray [ 12 ] [ 4 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 12 ] [ 4 ] . currVal = ( char_T * ) &
localB -> fvqfpke4jv ; mr_nonContOutputArray [ 12 ] [ 4 ] . next = & (
mr_nonContOutputArray [ 12 ] [ 5 ] ) ; } if ( mr_nonContOutputArray [ 12 ] !=
( NULL ) ) { mr_nonContOutputArray [ 12 ] [ 5 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 12 ] [ 5 ] . currVal = ( char_T * ) &
localB -> o0rhvekxea [ 0 ] ; mr_nonContOutputArray [ 12 ] [ 5 ] . next = & (
mr_nonContOutputArray [ 12 ] [ 6 ] ) ; } if ( mr_nonContOutputArray [ 12 ] !=
( NULL ) ) { mr_nonContOutputArray [ 12 ] [ 6 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 12 ] [ 6 ] . currVal = ( char_T * ) &
localB -> eyxanztqx1 ; mr_nonContOutputArray [ 12 ] [ 6 ] . next = & (
mr_nonContOutputArray [ 12 ] [ 7 ] ) ; } if ( mr_nonContOutputArray [ 12 ] !=
( NULL ) ) { mr_nonContOutputArray [ 12 ] [ 7 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 12 ] [ 7 ] . currVal = ( char_T * ) &
localB -> m4npe54j1c ; mr_nonContOutputArray [ 12 ] [ 7 ] . next = & (
mr_nonContOutputArray [ 12 ] [ 8 ] ) ; } if ( mr_nonContOutputArray [ 12 ] !=
( NULL ) ) { mr_nonContOutputArray [ 12 ] [ 8 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 12 ] [ 8 ] . currVal = ( char_T * ) &
localB -> l4pg5xpxp1 ; mr_nonContOutputArray [ 12 ] [ 8 ] . next = & (
mr_nonContOutputArray [ 12 ] [ 9 ] ) ; } if ( mr_nonContOutputArray [ 12 ] !=
( NULL ) ) { mr_nonContOutputArray [ 12 ] [ 9 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 12 ] [ 9 ] . currVal = ( char_T * ) &
localB -> jmb25suz33 ; mr_nonContOutputArray [ 12 ] [ 9 ] . next = & (
mr_nonContOutputArray [ 12 ] [ 10 ] ) ; } if ( mr_nonContOutputArray [ 12 ]
!= ( NULL ) ) { mr_nonContOutputArray [ 12 ] [ 10 ] . sizeInBytes = 3 *
sizeof ( real_T ) ; mr_nonContOutputArray [ 12 ] [ 10 ] . currVal = ( char_T
* ) & localB -> m5n5c0hsov [ 0 ] ; mr_nonContOutputArray [ 12 ] [ 10 ] . next
= ( NULL ) ; } if ( mr_nonContOutputArray [ 13 ] != ( NULL ) ) {
mr_nonContOutputArray [ 13 ] [ 0 ] . sizeInBytes = 3 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 13 ] [ 0 ] . currVal = ( char_T * ) & localB ->
ey5vfxyzqq [ 0 ] ; mr_nonContOutputArray [ 13 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 13 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 13 ] !=
( NULL ) ) { mr_nonContOutputArray [ 13 ] [ 1 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 13 ] [ 1 ] . currVal = ( char_T * ) &
localB -> nquucjysva ; mr_nonContOutputArray [ 13 ] [ 1 ] . next = & (
mr_nonContOutputArray [ 13 ] [ 2 ] ) ; } if ( mr_nonContOutputArray [ 13 ] !=
( NULL ) ) { mr_nonContOutputArray [ 13 ] [ 2 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 13 ] [ 2 ] . currVal = ( char_T * ) &
localB -> aq2vnamn3e ; mr_nonContOutputArray [ 13 ] [ 2 ] . next = & (
mr_nonContOutputArray [ 13 ] [ 3 ] ) ; } if ( mr_nonContOutputArray [ 13 ] !=
( NULL ) ) { mr_nonContOutputArray [ 13 ] [ 3 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 13 ] [ 3 ] . currVal = ( char_T * ) &
localB -> bjsj1dfvfu ; mr_nonContOutputArray [ 13 ] [ 3 ] . next = & (
mr_nonContOutputArray [ 13 ] [ 4 ] ) ; } if ( mr_nonContOutputArray [ 13 ] !=
( NULL ) ) { mr_nonContOutputArray [ 13 ] [ 4 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 13 ] [ 4 ] . currVal = ( char_T * ) &
localB -> fvqfpke4jv ; mr_nonContOutputArray [ 13 ] [ 4 ] . next = & (
mr_nonContOutputArray [ 13 ] [ 5 ] ) ; } if ( mr_nonContOutputArray [ 13 ] !=
( NULL ) ) { mr_nonContOutputArray [ 13 ] [ 5 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 13 ] [ 5 ] . currVal = ( char_T * ) &
localB -> o0rhvekxea [ 0 ] ; mr_nonContOutputArray [ 13 ] [ 5 ] . next = & (
mr_nonContOutputArray [ 13 ] [ 6 ] ) ; } if ( mr_nonContOutputArray [ 13 ] !=
( NULL ) ) { mr_nonContOutputArray [ 13 ] [ 6 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 13 ] [ 6 ] . currVal = ( char_T * ) &
localB -> eyxanztqx1 ; mr_nonContOutputArray [ 13 ] [ 6 ] . next = & (
mr_nonContOutputArray [ 13 ] [ 7 ] ) ; } if ( mr_nonContOutputArray [ 13 ] !=
( NULL ) ) { mr_nonContOutputArray [ 13 ] [ 7 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 13 ] [ 7 ] . currVal = ( char_T * ) &
localB -> m4npe54j1c ; mr_nonContOutputArray [ 13 ] [ 7 ] . next = & (
mr_nonContOutputArray [ 13 ] [ 8 ] ) ; } if ( mr_nonContOutputArray [ 13 ] !=
( NULL ) ) { mr_nonContOutputArray [ 13 ] [ 8 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 13 ] [ 8 ] . currVal = ( char_T * ) &
localB -> l4pg5xpxp1 ; mr_nonContOutputArray [ 13 ] [ 8 ] . next = & (
mr_nonContOutputArray [ 13 ] [ 9 ] ) ; } if ( mr_nonContOutputArray [ 13 ] !=
( NULL ) ) { mr_nonContOutputArray [ 13 ] [ 9 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 13 ] [ 9 ] . currVal = ( char_T * ) &
localB -> jmb25suz33 ; mr_nonContOutputArray [ 13 ] [ 9 ] . next = & (
mr_nonContOutputArray [ 13 ] [ 10 ] ) ; } if ( mr_nonContOutputArray [ 13 ]
!= ( NULL ) ) { mr_nonContOutputArray [ 13 ] [ 10 ] . sizeInBytes = 3 *
sizeof ( real_T ) ; mr_nonContOutputArray [ 13 ] [ 10 ] . currVal = ( char_T
* ) & localB -> m5n5c0hsov [ 0 ] ; mr_nonContOutputArray [ 13 ] [ 10 ] . next
= ( NULL ) ; } if ( mr_nonContOutputArray [ 18 ] != ( NULL ) ) {
mr_nonContOutputArray [ 18 ] [ 0 ] . sizeInBytes = 3 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 18 ] [ 0 ] . currVal = ( char_T * ) & localB ->
o0rhvekxea [ 0 ] ; mr_nonContOutputArray [ 18 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 18 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 18 ] !=
( NULL ) ) { mr_nonContOutputArray [ 18 ] [ 1 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 18 ] [ 1 ] . currVal = ( char_T * ) &
localB -> m5n5c0hsov [ 0 ] ; mr_nonContOutputArray [ 18 ] [ 1 ] . next = (
NULL ) ; } if ( mr_nonContOutputArray [ 19 ] != ( NULL ) ) {
mr_nonContOutputArray [ 19 ] [ 0 ] . sizeInBytes = 3 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 19 ] [ 0 ] . currVal = ( char_T * ) & localB ->
o0rhvekxea [ 0 ] ; mr_nonContOutputArray [ 19 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 19 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 19 ] !=
( NULL ) ) { mr_nonContOutputArray [ 19 ] [ 1 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 19 ] [ 1 ] . currVal = ( char_T * ) &
localB -> m5n5c0hsov [ 0 ] ; mr_nonContOutputArray [ 19 ] [ 1 ] . next = (
NULL ) ; } localZCE -> prsm11mhyx = UNINITIALIZED_ZCSIG ; localZCE ->
flpmsfbjwa = UNINITIALIZED_ZCSIG ; localZCE -> bnxldw4l3m =
UNINITIALIZED_ZCSIG ; localZCE -> prj2ssfcy5 = UNINITIALIZED_ZCSIG ; } void
mr_PassVeh7DOF_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo = false ;
ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if (
regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS
, modelName , rtMdlInfo_PassVeh7DOF , 107 ) ; * retVal = 1 ; } static void
mr_PassVeh7DOF_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) ; static void
mr_PassVeh7DOF_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_PassVeh7DOF_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_PassVeh7DOF_restoreDataFromMxArray ( void * destData , const mxArray
* srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_PassVeh7DOF_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_PassVeh7DOF_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int
j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_PassVeh7DOF_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_PassVeh7DOF_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_PassVeh7DOF_cacheDataToMxArrayWithOffset ( mxArray * destArray , mwIndex i
, int j , mwIndex offset , const void * srcData , size_t numBytes ) ; static
void mr_PassVeh7DOF_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
{ uint8_T * varData = ( uint8_T * ) mxGetData ( mxGetFieldByNumber (
destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData [ offset * numBytes
] , ( const uint8_T * ) srcData , numBytes ) ; } static void
mr_PassVeh7DOF_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_PassVeh7DOF_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_PassVeh7DOF_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray
, mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_PassVeh7DOF_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_PassVeh7DOF_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_PassVeh7DOF_extractBitFieldFromCellArrayWithOffset ( const mxArray
* srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) { const
uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber (
srcArray , i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u
) ; } mxArray * mr_PassVeh7DOF_GetDWork ( const pqca3kvywqf * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "rtzce" , } ;
mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( ssDW , 0 , 0 , & ( mdlrefDW -> rtb ) ,
sizeof ( mdlrefDW -> rtb ) ) ; { static const char * rtdwDataFieldNames [ 35
] = { "mdlrefDW->rtdw.bkwexe1kru" , "mdlrefDW->rtdw.pyrwzbu0vd" ,
"mdlrefDW->rtdw.cy5d015mtw" , "mdlrefDW->rtdw.puigwz3vsu" ,
"mdlrefDW->rtdw.j0vc5sz3xv" , "mdlrefDW->rtdw.em512f0wkt" ,
"mdlrefDW->rtdw.aixbqjjzjt" , "mdlrefDW->rtdw.iorqcjlmnb" ,
"mdlrefDW->rtdw.k5yhnl2wmc" , "mdlrefDW->rtdw.lgnoyudawr" ,
"mdlrefDW->rtdw.i2lrfe4vsy" , "mdlrefDW->rtdw.n2wij4stkw" ,
"mdlrefDW->rtdw.ogjeqhknwa" , "mdlrefDW->rtdw.pw1i2shx4s" ,
"mdlrefDW->rtdw.hl5oc4enil" , "mdlrefDW->rtdw.ngtk3y0d0k" ,
"mdlrefDW->rtdw.jcq45ux2tw" , "mdlrefDW->rtdw.a4hec4xq23" ,
"mdlrefDW->rtdw.jp5udlopwm" , "mdlrefDW->rtdw.jmdhsygujx" ,
"mdlrefDW->rtdw.dvpvfskwai" , "mdlrefDW->rtdw.dtfk4nn1qz" ,
"mdlrefDW->rtdw.hk0nfz3tiy" , "mdlrefDW->rtdw.pksiahpaaw" ,
"mdlrefDW->rtdw.eezel21inu" , "mdlrefDW->rtdw.lb1nn0qgui" ,
"mdlrefDW->rtdw.gmuarwd0x2" , "mdlrefDW->rtdw.gbgapftrxi" ,
"mdlrefDW->rtdw.axwzh0jhgp" , "mdlrefDW->rtdw.oywcgos5db" ,
"mdlrefDW->rtdw.a001iqqtdq" , "mdlrefDW->rtdw.eiud0ciipq.dygl2vbtcr" ,
"mdlrefDW->rtdw.jekbgdtwun.dygl2vbtcr" ,
"mdlrefDW->rtdw.kwvhl4ef3q.dygl2vbtcr" ,
"mdlrefDW->rtdw.ekmk5spjxa3.dygl2vbtcr" , } ; mxArray * rtdwData =
mxCreateStructMatrix ( 1 , 1 , 35 , rtdwDataFieldNames ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 0 , & ( mdlrefDW -> rtdw .
bkwexe1kru ) , sizeof ( mdlrefDW -> rtdw . bkwexe1kru ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 1 , & ( mdlrefDW -> rtdw .
pyrwzbu0vd ) , sizeof ( mdlrefDW -> rtdw . pyrwzbu0vd ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 2 , & ( mdlrefDW -> rtdw .
cy5d015mtw ) , sizeof ( mdlrefDW -> rtdw . cy5d015mtw ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 3 , & ( mdlrefDW -> rtdw .
puigwz3vsu ) , sizeof ( mdlrefDW -> rtdw . puigwz3vsu ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 4 , & ( mdlrefDW -> rtdw .
j0vc5sz3xv ) , sizeof ( mdlrefDW -> rtdw . j0vc5sz3xv ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 5 , & ( mdlrefDW -> rtdw .
em512f0wkt ) , sizeof ( mdlrefDW -> rtdw . em512f0wkt ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 6 , & ( mdlrefDW -> rtdw .
aixbqjjzjt ) , sizeof ( mdlrefDW -> rtdw . aixbqjjzjt ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 7 , & ( mdlrefDW -> rtdw .
iorqcjlmnb ) , sizeof ( mdlrefDW -> rtdw . iorqcjlmnb ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 8 , & ( mdlrefDW -> rtdw .
k5yhnl2wmc ) , sizeof ( mdlrefDW -> rtdw . k5yhnl2wmc ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 9 , & ( mdlrefDW -> rtdw .
lgnoyudawr ) , sizeof ( mdlrefDW -> rtdw . lgnoyudawr ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 10 , & ( mdlrefDW -> rtdw
. i2lrfe4vsy ) , sizeof ( mdlrefDW -> rtdw . i2lrfe4vsy ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 11 , & ( mdlrefDW -> rtdw
. n2wij4stkw ) , sizeof ( mdlrefDW -> rtdw . n2wij4stkw ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 12 , & ( mdlrefDW -> rtdw
. ogjeqhknwa ) , sizeof ( mdlrefDW -> rtdw . ogjeqhknwa ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 13 , & ( mdlrefDW -> rtdw
. pw1i2shx4s ) , sizeof ( mdlrefDW -> rtdw . pw1i2shx4s ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 14 , & ( mdlrefDW -> rtdw
. hl5oc4enil ) , sizeof ( mdlrefDW -> rtdw . hl5oc4enil ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 15 , & ( mdlrefDW -> rtdw
. ngtk3y0d0k ) , sizeof ( mdlrefDW -> rtdw . ngtk3y0d0k ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 16 , & ( mdlrefDW -> rtdw
. jcq45ux2tw ) , sizeof ( mdlrefDW -> rtdw . jcq45ux2tw ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 17 , & ( mdlrefDW -> rtdw
. a4hec4xq23 ) , sizeof ( mdlrefDW -> rtdw . a4hec4xq23 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 18 , & ( mdlrefDW -> rtdw
. jp5udlopwm ) , sizeof ( mdlrefDW -> rtdw . jp5udlopwm ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 19 , & ( mdlrefDW -> rtdw
. jmdhsygujx ) , sizeof ( mdlrefDW -> rtdw . jmdhsygujx ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 20 , & ( mdlrefDW -> rtdw
. dvpvfskwai ) , sizeof ( mdlrefDW -> rtdw . dvpvfskwai ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 21 , & ( mdlrefDW -> rtdw
. dtfk4nn1qz ) , sizeof ( mdlrefDW -> rtdw . dtfk4nn1qz ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 22 , & ( mdlrefDW -> rtdw
. hk0nfz3tiy ) , sizeof ( mdlrefDW -> rtdw . hk0nfz3tiy ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 23 , & ( mdlrefDW -> rtdw
. pksiahpaaw ) , sizeof ( mdlrefDW -> rtdw . pksiahpaaw ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 24 , & ( mdlrefDW -> rtdw
. eezel21inu ) , sizeof ( mdlrefDW -> rtdw . eezel21inu ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 25 , & ( mdlrefDW -> rtdw
. lb1nn0qgui ) , sizeof ( mdlrefDW -> rtdw . lb1nn0qgui ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 26 , & ( mdlrefDW -> rtdw
. gmuarwd0x2 ) , sizeof ( mdlrefDW -> rtdw . gmuarwd0x2 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 27 , & ( mdlrefDW -> rtdw
. gbgapftrxi ) , sizeof ( mdlrefDW -> rtdw . gbgapftrxi ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 28 , & ( mdlrefDW -> rtdw
. axwzh0jhgp ) , sizeof ( mdlrefDW -> rtdw . axwzh0jhgp ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 29 , & ( mdlrefDW -> rtdw
. oywcgos5db ) , sizeof ( mdlrefDW -> rtdw . oywcgos5db ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 30 , & ( mdlrefDW -> rtdw
. a001iqqtdq ) , sizeof ( mdlrefDW -> rtdw . a001iqqtdq ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 31 , & ( mdlrefDW -> rtdw
. eiud0ciipq . dygl2vbtcr ) , sizeof ( mdlrefDW -> rtdw . eiud0ciipq .
dygl2vbtcr ) ) ; mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 32 , & (
mdlrefDW -> rtdw . jekbgdtwun . dygl2vbtcr ) , sizeof ( mdlrefDW -> rtdw .
jekbgdtwun . dygl2vbtcr ) ) ; mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData ,
0 , 33 , & ( mdlrefDW -> rtdw . kwvhl4ef3q . dygl2vbtcr ) , sizeof ( mdlrefDW
-> rtdw . kwvhl4ef3q . dygl2vbtcr ) ) ; mr_PassVeh7DOF_cacheDataAsMxArray (
rtdwData , 0 , 34 , & ( mdlrefDW -> rtdw . ekmk5spjxa3 . dygl2vbtcr ) ,
sizeof ( mdlrefDW -> rtdw . ekmk5spjxa3 . dygl2vbtcr ) ) ; mxSetFieldByNumber
( ssDW , 0 , 1 , rtdwData ) ; } mr_PassVeh7DOF_cacheDataAsMxArray ( ssDW , 0
, 2 , & ( mdlrefDW -> rtzce ) , sizeof ( mdlrefDW -> rtzce ) ) ; return ssDW
; } void mr_PassVeh7DOF_SetDWork ( pqca3kvywqf * mdlrefDW , const mxArray *
ssDW ) { mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtb ) , ssDW
, 0 , 0 , sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ; mr_PassVeh7DOF_restoreDataFromMxArray (
& ( mdlrefDW -> rtdw . bkwexe1kru ) , rtdwData , 0 , 0 , sizeof ( mdlrefDW ->
rtdw . bkwexe1kru ) ) ; mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW
-> rtdw . pyrwzbu0vd ) , rtdwData , 0 , 1 , sizeof ( mdlrefDW -> rtdw .
pyrwzbu0vd ) ) ; mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw
. cy5d015mtw ) , rtdwData , 0 , 2 , sizeof ( mdlrefDW -> rtdw . cy5d015mtw )
) ; mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . puigwz3vsu
) , rtdwData , 0 , 3 , sizeof ( mdlrefDW -> rtdw . puigwz3vsu ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . j0vc5sz3xv ) ,
rtdwData , 0 , 4 , sizeof ( mdlrefDW -> rtdw . j0vc5sz3xv ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . em512f0wkt ) ,
rtdwData , 0 , 5 , sizeof ( mdlrefDW -> rtdw . em512f0wkt ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . aixbqjjzjt ) ,
rtdwData , 0 , 6 , sizeof ( mdlrefDW -> rtdw . aixbqjjzjt ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . iorqcjlmnb ) ,
rtdwData , 0 , 7 , sizeof ( mdlrefDW -> rtdw . iorqcjlmnb ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . k5yhnl2wmc ) ,
rtdwData , 0 , 8 , sizeof ( mdlrefDW -> rtdw . k5yhnl2wmc ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . lgnoyudawr ) ,
rtdwData , 0 , 9 , sizeof ( mdlrefDW -> rtdw . lgnoyudawr ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . i2lrfe4vsy ) ,
rtdwData , 0 , 10 , sizeof ( mdlrefDW -> rtdw . i2lrfe4vsy ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . n2wij4stkw ) ,
rtdwData , 0 , 11 , sizeof ( mdlrefDW -> rtdw . n2wij4stkw ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ogjeqhknwa ) ,
rtdwData , 0 , 12 , sizeof ( mdlrefDW -> rtdw . ogjeqhknwa ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . pw1i2shx4s ) ,
rtdwData , 0 , 13 , sizeof ( mdlrefDW -> rtdw . pw1i2shx4s ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . hl5oc4enil ) ,
rtdwData , 0 , 14 , sizeof ( mdlrefDW -> rtdw . hl5oc4enil ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ngtk3y0d0k ) ,
rtdwData , 0 , 15 , sizeof ( mdlrefDW -> rtdw . ngtk3y0d0k ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . jcq45ux2tw ) ,
rtdwData , 0 , 16 , sizeof ( mdlrefDW -> rtdw . jcq45ux2tw ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . a4hec4xq23 ) ,
rtdwData , 0 , 17 , sizeof ( mdlrefDW -> rtdw . a4hec4xq23 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . jp5udlopwm ) ,
rtdwData , 0 , 18 , sizeof ( mdlrefDW -> rtdw . jp5udlopwm ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . jmdhsygujx ) ,
rtdwData , 0 , 19 , sizeof ( mdlrefDW -> rtdw . jmdhsygujx ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . dvpvfskwai ) ,
rtdwData , 0 , 20 , sizeof ( mdlrefDW -> rtdw . dvpvfskwai ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . dtfk4nn1qz ) ,
rtdwData , 0 , 21 , sizeof ( mdlrefDW -> rtdw . dtfk4nn1qz ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . hk0nfz3tiy ) ,
rtdwData , 0 , 22 , sizeof ( mdlrefDW -> rtdw . hk0nfz3tiy ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . pksiahpaaw ) ,
rtdwData , 0 , 23 , sizeof ( mdlrefDW -> rtdw . pksiahpaaw ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . eezel21inu ) ,
rtdwData , 0 , 24 , sizeof ( mdlrefDW -> rtdw . eezel21inu ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . lb1nn0qgui ) ,
rtdwData , 0 , 25 , sizeof ( mdlrefDW -> rtdw . lb1nn0qgui ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . gmuarwd0x2 ) ,
rtdwData , 0 , 26 , sizeof ( mdlrefDW -> rtdw . gmuarwd0x2 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . gbgapftrxi ) ,
rtdwData , 0 , 27 , sizeof ( mdlrefDW -> rtdw . gbgapftrxi ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . axwzh0jhgp ) ,
rtdwData , 0 , 28 , sizeof ( mdlrefDW -> rtdw . axwzh0jhgp ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . oywcgos5db ) ,
rtdwData , 0 , 29 , sizeof ( mdlrefDW -> rtdw . oywcgos5db ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . a001iqqtdq ) ,
rtdwData , 0 , 30 , sizeof ( mdlrefDW -> rtdw . a001iqqtdq ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . eiud0ciipq .
dygl2vbtcr ) , rtdwData , 0 , 31 , sizeof ( mdlrefDW -> rtdw . eiud0ciipq .
dygl2vbtcr ) ) ; mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw
. jekbgdtwun . dygl2vbtcr ) , rtdwData , 0 , 32 , sizeof ( mdlrefDW -> rtdw .
jekbgdtwun . dygl2vbtcr ) ) ; mr_PassVeh7DOF_restoreDataFromMxArray ( & (
mdlrefDW -> rtdw . kwvhl4ef3q . dygl2vbtcr ) , rtdwData , 0 , 33 , sizeof (
mdlrefDW -> rtdw . kwvhl4ef3q . dygl2vbtcr ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ekmk5spjxa3 .
dygl2vbtcr ) , rtdwData , 0 , 34 , sizeof ( mdlrefDW -> rtdw . ekmk5spjxa3 .
dygl2vbtcr ) ) ; } mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW ->
rtzce ) , ssDW , 0 , 2 , sizeof ( mdlrefDW -> rtzce ) ) ; } void
mr_PassVeh7DOF_RegisterSimStateChecksum ( SimStruct * S ) { const uint32_T
chksum [ 4 ] = { 3626773022U , 82591057U , 1231388383U , 168902607U , } ;
slmrModelRefRegisterSimStateChecksum ( S , "PassVeh7DOF" , & chksum [ 0 ] ) ;
} mxArray * mr_PassVeh7DOF_GetSimStateDisallowedBlocks ( ) { return NULL ; }
