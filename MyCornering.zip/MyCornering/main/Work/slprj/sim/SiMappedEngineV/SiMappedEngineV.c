#include "__cf_SiMappedEngineV.h"
#include "SiMappedEngineV_capi.h"
#include "SiMappedEngineV.h"
#include "SiMappedEngineV_private.h"
#include "look2_binlcpw.h"
static RegMdlInfo rtMdlInfo_SiMappedEngineV [ 45 ] = { { "o2k4rz0uw5x" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "SiMappedEngineV" } , {
"jgubm4xidl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiMappedEngineV" } , { "i3uom1vnc5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "SiMappedEngineV" } , { "dk2lj1ie3v" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiMappedEngineV" } ,
{ "ih0mudozt1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiMappedEngineV" } , { "fpgmc1blog" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "SiMappedEngineV" } , { "m0sbce0q1j" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiMappedEngineV" } ,
{ "bnzlddutvq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiMappedEngineV" } , { "ac505oj1ao" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "SiMappedEngineV" } , { "e3tultvbwk" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiMappedEngineV" } ,
{ "ow0cmqxpyk" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiMappedEngineV" } , { "puu5fcics1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "SiMappedEngineV" } , { "atxsq1iycf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiMappedEngineV" } ,
{ "po5zlrzzyd" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiMappedEngineV" } , { "ecxs4hsbvq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "SiMappedEngineV" } , { "bmpf100lpn" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiMappedEngineV" } ,
{ "pj3vtlmlns" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiMappedEngineV" } , { "f4glzcjee3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "SiMappedEngineV" } , { "f5rmroe5ej" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiMappedEngineV" } ,
{ "fbspkqemka" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiMappedEngineV" } , { "eglqnicaef" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "SiMappedEngineV" } , { "as2gecbwug" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiMappedEngineV" } ,
{ "SiMappedEngineV" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } ,
{ "dvrjeurk0cw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiMappedEngineV" } , { "ip55uwcstvp" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "SiMappedEngineV" } , { "ajamtm0fjy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiMappedEngineV" } ,
{ "exfljitylvg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiMappedEngineV" } , { "dvrjeurk0c" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "SiMappedEngineV" } , { "ip55uwcstv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiMappedEngineV" } ,
{ "mrj2qlehgq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiMappedEngineV" } , { "kgxfljuibq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "SiMappedEngineV" } , { "mr_SiMappedEngineV_SetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "SiMappedEngineV" } , {
"mr_SiMappedEngineV_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void
* ) "SiMappedEngineV" } , { "SiMappedEngineV.h" , MDL_INFO_MODEL_FILENAME , 0
, - 1 , ( NULL ) } , { "SiMappedEngineV.c" , MDL_INFO_MODEL_FILENAME , 0 , -
1 , ( void * ) "SiMappedEngineV" } } ; anoacnregqm anoacnregq = { { 0.0 ,
76.8593923996067 , 105.14048294807517 , 131.53363811102966 ,
157.92679327398395 , 176.65863171654726 , 176.65727295989169 ,
176.65685668583816 , 176.65687907660754 , 176.65709375636698 ,
176.65740451571583 , 176.65772406043246 , 176.65802862609209 ,
176.65832545418598 , 176.65858624365228 , 176.65883416642458 , 0.0 ,
76.8593923996067 , 105.14048294807517 , 131.53363811102966 ,
157.92679327398395 , 176.65863171654726 , 176.65727295989169 ,
176.65685668583816 , 176.65687907660754 , 176.65709375636698 ,
176.65740451571583 , 176.65772406043246 , 176.65802862609209 ,
176.65832545418598 , 176.65858624365228 , 176.65883416642458 , 0.0 ,
78.633430260747247 , 92.431884680725375 , 118.82503984367986 ,
145.21819500663406 , 171.61135016958838 , 198.00450533254264 ,
219.45314552299834 , 219.37200146933023 , 219.31846012267061 ,
219.26491877601097 , 219.21246813348196 , 219.18743031020315 ,
219.17060113004237 , 219.15197161464931 , 219.13869771556796 , 0.0 ,
65.888505581637446 , 85.408711954032015 , 111.80186711698649 ,
138.19502227994082 , 164.58817744289496 , 190.98133260584925 ,
217.37448776880382 , 243.76764293175845 , 252.65391515119802 ,
252.65366038879927 , 252.654127243326 , 252.65450476171185 ,
252.65472980631839 , 252.65482915961925 , 252.65486792857678 , 0.0 ,
61.752953161892336 , 80.953150761828766 , 107.34630592478324 ,
133.73946108773748 , 160.13261625069174 , 186.52577141364603 ,
212.91892657660054 , 239.31213482777596 , 265.70523690250803 ,
290.39637100853656 , 293.20259711648026 , 293.2025174750255 ,
293.202464699828 , 293.20243016451525 , 293.2024076261759 , 0.0 ,
53.005765883751124 , 77.874763029033844 , 104.26791819198834 ,
130.66107335494263 , 157.05422851789692 , 183.44738368085109 ,
209.8405388438056 , 236.23369400675992 , 262.62684916971347 ,
289.02000433267261 , 315.41315949562176 , 341.83993223312285 ,
368.19940894680173 , 394.58689731461504 , 419.18638803255561 , 0.0 ,
57.536163342722126 , 75.620510594782388 , 102.01366575773685 ,
128.40682092069113 , 154.79997608364548 , 181.19313124659962 ,
207.58628640955413 , 233.97944157250839 , 260.375724516588 ,
286.78720767165061 , 313.15890706137071 , 339.55523433894422 ,
365.94461982374816 , 392.33837255025844 , 415.90608036500271 , 0.0 ,
53.378509065233672 , 73.898512207507011 , 100.29166737046151 ,
126.68482253341578 , 153.07797769637 , 179.47113285932429 ,
205.86428802227874 , 232.25744318523289 , 258.64957239000967 ,
285.04375351114578 , 311.44545776119787 , 337.83006383705117 ,
364.3666670300496 , 390.61671118011822 , 412.14365857118486 , 0.0 ,
52.433733161570174 , 72.5401656535692 , 98.933320816523732 ,
125.32647597947791 , 151.71963114243215 , 178.11278630538644 ,
204.50594146834095 , 230.89909663129518 , 257.2926089357415 ,
283.68540695720463 , 310.04537161120334 , 336.47171728311321 ,
362.92273926358189 , 389.37850289152021 , 415.68639455099157 , 0.0 ,
53.558536733215462 , 71.441278553754415 , 97.834433716708858 ,
124.22758887966312 , 150.62074404261739 , 177.01389920557162 ,
203.40705436852622 , 229.80020953148048 , 256.193364694434 ,
282.5865198573897 , 308.97967502034277 , 335.358447367261 ,
361.76598534625174 , 388.10830363126064 , 407.5692212740903 , 0.0 ,
51.945116891417811 , 70.5339922815997 , 96.927147444554066 ,
123.32030260750834 , 149.71345777046258 , 176.10661293341687 ,
202.49976809637133 , 228.89292325932558 , 255.28607842227888 ,
281.68975070996919 , 308.07238874818836 , 334.45774526913351 ,
360.85869907409722 , 387.25185423705256 , 410.65985867472989 , 0.0 ,
48.461571229247355 , 69.772214185167769 , 96.165369348122255 ,
122.55852451107648 , 148.95167967403074 , 175.34483483698489 ,
201.73798999993954 , 228.1311451628938 , 254.52430032584704 ,
280.91920914620442 , 307.31061065175209 , 333.7037658147122 ,
360.09692097766606 , 386.49007614062 , 412.8808916195236 , 0.0 ,
48.867841155296176 , 69.12353851353366 , 95.516693676488117 ,
121.90984883944239 , 148.30300400239668 , 174.69615916535093 ,
201.08931432830545 , 227.48246949125971 , 253.875624654213 ,
280.26917597884858 , 306.675851877622 , 333.08474045669192 ,
359.44741508223495 , 385.84140046899091 , 408.30415040717332 , 0.0 ,
47.522914284593583 , 68.564517203019733 , 94.9576723659742 ,
121.35082752892839 , 147.74398269188271 , 174.13713785483702 ,
200.53029301779151 , 226.92344818074582 , 253.31660334369914 ,
279.709758506654 , 306.10291366962895 , 332.53542387113748 ,
358.88753105887622 , 385.29957811299397 , 399.64771922419459 , 0.0 ,
45.6493412900512 , 68.077764807172969 , 94.470919970127412 ,
120.86407513308171 , 147.257230296036 , 173.65038545899023 ,
200.04354062194477 , 226.43669578489906 , 252.83014903562639 ,
279.25896811170577 , 305.64285780543605 , 332.00752184817219 ,
358.40247159967652 , 384.78977724038521 , 409.8743813457836 , 0.0 ,
44.581631979942287 , 67.650118059393307 , 94.043273222347793 ,
120.43642838530205 , 146.82958354825635 , 173.22273871121058 ,
199.61589387416507 , 226.00904903711947 , 252.40220420007296 ,
278.81445382347988 , 305.251639651581 , 331.57614333045672 ,
357.97172376719965 , 384.36798001484908 , 410.03244487489678 } , { 0.0 ,
649.519052838329 , 912.41962184432055 , 1175.320190850312 ,
1438.2207598563036 , 1701.1213288622862 , 1964.0218978682778 ,
2226.9224668742695 , 2489.8230358802612 , 2752.7236048862524 ,
3015.624173892244 , 3278.5247428982352 , 3541.4253119042187 ,
3804.3258809102103 , 4067.2264499162011 , 4330.1270189221932 } , { 0.0 ,
34.641016151377549 , 61.034171314331807 , 87.427326477286286 ,
113.82048164024056 , 140.21363680319482 , 166.60679196614907 ,
192.99994712910356 , 219.39310229205782 , 245.78625745501117 ,
272.17941261796682 , 298.57256778092011 , 324.96572294387579 ,
351.35887810682908 , 377.75203326978476 , 404.14518843273811 } ,
73.91982714328924 , 251.32741228718345 , 0.0 , 0.0 , 0.0 , 720.0 , 0.0 , 6.0
, { 15U , 15U } } ; void f5rmroe5ej ( fpgmc1blog * localX ) { localX ->
aya33lx1d1 = anoacnregq . P_5 ; localX -> i4suutis5z = anoacnregq . P_6 ;
localX -> lf5wmc502m = anoacnregq . P_7 ; } void f4glzcjee3 ( fpgmc1blog *
localX ) { localX -> aya33lx1d1 = anoacnregq . P_5 ; localX -> i4suutis5z =
anoacnregq . P_6 ; localX -> lf5wmc502m = anoacnregq . P_7 ; } void
SiMappedEngineV ( const real_T * dhoq3itz5d , const real_T * gzpwimsfg2 ,
real_T * p2vuqhqrpz , puu5fcics1 * localB , fpgmc1blog * localX ) { real_T
pxg1yct3fj ; localB -> b0rncibi3m = ( * dhoq3itz5d - localX -> aya33lx1d1 ) *
anoacnregq . P_3 ; pxg1yct3fj = 9.5492965855137211 * * gzpwimsfg2 ; *
p2vuqhqrpz = localX -> i4suutis5z ; localB -> cvu1ggqyuw = ( look2_binlcpw (
localX -> aya33lx1d1 , pxg1yct3fj , anoacnregq . P_2 , anoacnregq . P_1 ,
anoacnregq . P_0 , anoacnregq . P_11 , 16U ) - * p2vuqhqrpz ) * anoacnregq .
P_4 ; localB -> myo3xsikij = anoacnregq . P_10 * pxg1yct3fj ; } void
SiMappedEngineVTID2 ( void ) { } void pj3vtlmlns ( void ) { } void
pj3vtlmlnsTID2 ( void ) { } void bmpf100lpn ( puu5fcics1 * localB ,
ih0mudozt1 * localXdot ) { localXdot -> aya33lx1d1 = localB -> b0rncibi3m ;
localXdot -> i4suutis5z = localB -> cvu1ggqyuw ; localXdot -> lf5wmc502m =
localB -> myo3xsikij ; } void po5zlrzzyd ( kgxfljuibq * const plpdajfsza ) {
if ( ! slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( plpdajfsza
-> _mdlRefSfcnS , "SiMappedEngineV" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void fbspkqemka (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T
mdlref_TID2 , kgxfljuibq * const plpdajfsza , puu5fcics1 * localB ,
fpgmc1blog * localX , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T )
) ; ( void ) memset ( ( void * ) plpdajfsza , 0 , sizeof ( kgxfljuibq ) ) ;
plpdajfsza -> Timing . mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; plpdajfsza ->
Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; plpdajfsza -> Timing .
mdlref_GlobalTID [ 2 ] = mdlref_TID2 ; plpdajfsza -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( plpdajfsza -> _mdlRefSfcnS , "SiMappedEngineV" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> b0rncibi3m = 0.0
; localB -> cvu1ggqyuw = 0.0 ; localB -> myo3xsikij = 0.0 ; }
SiMappedEngineV_InitializeDataMapInfo ( plpdajfsza , localX , sysRanPtr ,
contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL
) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & (
plpdajfsza -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( plpdajfsza ->
DataMapInfo . mmi , rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex (
plpdajfsza -> DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_SiMappedEngineV_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo
= false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ;
if ( regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo (
mdlRefSfcnS , modelName , rtMdlInfo_SiMappedEngineV , 45 ) ; * retVal = 1 ; }
static void mr_SiMappedEngineV_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) ; static void
mr_SiMappedEngineV_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int
j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_SiMappedEngineV_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_SiMappedEngineV_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( (
uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_SiMappedEngineV_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i ,
int j , uint_T bitVal ) ; static void
mr_SiMappedEngineV_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i ,
int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_SiMappedEngineV_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_SiMappedEngineV_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_SiMappedEngineV_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_SiMappedEngineV_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_SiMappedEngineV_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) ; static void mr_SiMappedEngineV_restoreDataFromMxArrayWithOffset
( void * destData , const mxArray * srcArray , mwIndex i , int j , mwIndex
offset , size_t numBytes ) { const uint8_T * varData = ( const uint8_T * )
mxGetData ( mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T *
) destData , ( const uint8_T * ) & varData [ offset * numBytes ] , numBytes )
; } static void mr_SiMappedEngineV_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
; static void mr_SiMappedEngineV_cacheBitFieldToCellArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_SiMappedEngineV_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_SiMappedEngineV_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_SiMappedEngineV_GetDWork ( const
o2k4rz0uw5x * mdlrefDW ) { static const char * ssDWFieldNames [ 3 ] = { "rtb"
, "NULL->rtdw" , "NULL->rtzce" , } ; mxArray * ssDW = mxCreateStructMatrix (
1 , 1 , 3 , ssDWFieldNames ) ; mr_SiMappedEngineV_cacheDataAsMxArray ( ssDW ,
0 , 0 , & ( mdlrefDW -> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; return ssDW ;
} void mr_SiMappedEngineV_SetDWork ( o2k4rz0uw5x * mdlrefDW , const mxArray *
ssDW ) { mr_SiMappedEngineV_restoreDataFromMxArray ( & ( mdlrefDW -> rtb ) ,
ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) ) ; } void
mr_SiMappedEngineV_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 129896255U , 862534075U , 333002146U , 1023077996U
, } ; slmrModelRefRegisterSimStateChecksum ( S , "SiMappedEngineV" , & chksum
[ 0 ] ) ; } mxArray * mr_SiMappedEngineV_GetSimStateDisallowedBlocks ( ) {
return NULL ; }
