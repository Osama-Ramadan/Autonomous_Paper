#include "__cf_LKARefMdl.h"
#ifndef RTW_HEADER_LKARefMdl_capi_h_
#define RTW_HEADER_LKARefMdl_capi_h_
#include "LKARefMdl.h"
extern void LKARefMdl_InitializeDataMapInfo ( a0qef2fbcm * const iu2zxy1bg0 ,
j4ytv2gj5l * localDW , void * sysRanPtr , int contextTid ) ;
#endif
