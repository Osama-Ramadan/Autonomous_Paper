#include "__cf_LKARefMdl.h"
#ifndef RTW_HEADER_LKARefMdl_types_h_
#define RTW_HEADER_LKARefMdl_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#ifndef DEFINED_TYPEDEF_FOR_LaneSensorBoundaries_
#define DEFINED_TYPEDEF_FOR_LaneSensorBoundaries_
typedef struct { real32_T Curvature ; real32_T CurvatureDerivative ; real32_T
HeadingAngle ; real32_T LateralOffset ; real32_T Strength ; uint8_T
sl_padding0 [ 4 ] ; } LaneSensorBoundaries ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_LaneSensor_
#define DEFINED_TYPEDEF_FOR_LaneSensor_
typedef struct { LaneSensorBoundaries Left ; LaneSensorBoundaries Right ; }
LaneSensor ;
#endif
#ifndef struct_tag_sjVaXfrJc3wv5faWU7kmQtG
#define struct_tag_sjVaXfrJc3wv5faWU7kmQtG
struct tag_sjVaXfrJc3wv5faWU7kmQtG { boolean_T LT ; } ;
#endif
#ifndef typedef_jm2nusozjm
#define typedef_jm2nusozjm
typedef struct tag_sjVaXfrJc3wv5faWU7kmQtG jm2nusozjm ;
#endif
#ifndef struct_tag_sKLpTDgVdadEcWmkZEqDlEH
#define struct_tag_sKLpTDgVdadEcWmkZEqDlEH
struct tag_sKLpTDgVdadEcWmkZEqDlEH { uint32_T LT ; uint32_T UT ; uint32_T
UHESS ; uint32_T SYM ; uint32_T POSDEF ; uint32_T RECT ; uint32_T TRANSA ; }
;
#endif
#ifndef typedef_ooblescru3
#define typedef_ooblescru3
typedef struct tag_sKLpTDgVdadEcWmkZEqDlEH ooblescru3 ;
#endif
#ifndef struct_tag_s9s8BC13iTohZXRbLMSIDHE
#define struct_tag_s9s8BC13iTohZXRbLMSIDHE
struct tag_s9s8BC13iTohZXRbLMSIDHE { boolean_T CaseSensitivity ; boolean_T
StructExpand ; boolean_T PartialMatching ; } ;
#endif
#ifndef typedef_jdtvndcfcg
#define typedef_jdtvndcfcg
typedef struct tag_s9s8BC13iTohZXRbLMSIDHE jdtvndcfcg ;
#endif
typedef struct ajghr3ctyrx_ ajghr3ctyrx ; typedef struct cyntjpgsgd
a0qef2fbcm ;
#endif
