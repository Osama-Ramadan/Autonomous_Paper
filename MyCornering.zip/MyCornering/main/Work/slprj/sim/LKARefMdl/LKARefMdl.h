#include "__cf_LKARefMdl.h"
#ifndef RTW_HEADER_LKARefMdl_h_
#define RTW_HEADER_LKARefMdl_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap.h"
#ifndef LKARefMdl_COMMON_INCLUDES_
#define LKARefMdl_COMMON_INCLUDES_
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "sf_runtime/sfc_sdi.h"
#endif
#include "LKARefMdl_types.h"
#include "multiword_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"
#include "rt_assert.h"
#include "rtGetInf.h"
typedef struct { real32_T pa2ccbhiyz [ 7812 ] ; real32_T k3bfvaswdr [ 3720 ]
; real32_T gvlj43vtsb [ 1800 ] ; real32_T iae25d40vx ; real32_T nfr45zfsgr ;
real32_T mmcgmfp2o3 ; real32_T hbjo123h1b ; real32_T kril0wyeg3 ; real32_T
fbs4tfm210 ; real32_T odjgtv4pzb ; real32_T d1uo5hrcw0 ; real32_T pfdh1l3ror
; real32_T lv4o50mg5y ; real32_T ach0dqbfpm ; real32_T i0l5pfyvd3 ; real32_T
ks4nioygh5 ; real32_T loumcs1pnk [ 5 ] ; real32_T pv0cqe5xzb ; real32_T
a2usnvldsr [ 25 ] ; boolean_T bgyuap3dxu ; boolean_T o5pj2sk15l [ 126 ] ; }
llf3xg3ir0 ; typedef struct { struct { void * AQHandles ; void * SlioLTF ; }
d0ox53zfja ; struct { void * AQHandles ; void * SlioLTF ; } dpmuujlupa ;
struct { void * AQHandles ; void * SlioLTF ; } igap1wnipb ; struct { void *
AQHandles ; void * SlioLTF ; } dfhhcydsof ; struct { void * AQHandles ; void
* SlioLTF ; } jtkkjdqprf ; struct { void * AQHandles ; void * SlioLTF ; }
fgtuicwhwc ; struct { void * AQHandles ; void * SlioLTF ; } kpzmvqvw4f ; void
* ojixqir503 ; struct { void * AQHandles ; void * SlioLTF ; } ln45a3lme1 ;
real32_T c20jlygsay ; real32_T hryujm23gv ; real32_T idw3weirf3 ; real32_T
ayeaqphirh ; real32_T kxvvsjr51z ; real32_T jx11wd5i0n [ 5 ] ; real32_T
cf5jrvxca5 [ 5 ] ; real32_T fowmhxaqij [ 25 ] ; boolean_T mbmtbdjeqm ; int8_T
jeftpncfv5 ; int8_T lrava23ncm ; int8_T hiiwcrboab ; int8_T hwadutcumr ;
boolean_T enqs1wotqd [ 126 ] ; } j4ytv2gj5l ; struct ajghr3ctyrx_ { real_T
P_0 ; real_T P_1 ; real_T P_2 ; real32_T P_3 ; real32_T P_4 ; real_T P_5 ;
real32_T P_6 ; real32_T P_7 ; real32_T P_8 ; real32_T P_9 ; real32_T P_10 ;
real32_T P_11 ; real32_T P_12 ; real32_T P_13 ; real32_T P_14 ; real32_T P_15
; real32_T P_16 ; real32_T P_17 ; real32_T P_18 ; real32_T P_19 ; real32_T
P_20 ; real32_T P_21 ; real32_T P_22 ; real32_T P_23 ; real32_T P_24 ;
real32_T P_25 ; real32_T P_26 [ 5 ] ; real32_T P_27 ; real32_T P_28 [ 2 ] ;
real32_T P_29 ; real32_T P_30 ; real32_T P_31 ; real32_T P_32 ; real32_T P_33
; real32_T P_34 ; real32_T P_35 ; real32_T P_36 ; real32_T P_37 ; real32_T
P_38 ; real32_T P_39 [ 2 ] ; real32_T P_40 ; real32_T P_41 ; real32_T P_42 [
2 ] ; real32_T P_43 ; real32_T P_44 ; real32_T P_45 [ 2 ] ; real32_T P_46 [ 2
] ; real32_T P_47 ; real32_T P_48 ; real32_T P_49 ; real32_T P_50 ; real32_T
P_51 ; real32_T P_52 ; real32_T P_53 ; real32_T P_54 ; real32_T P_55 ;
real32_T P_56 ; real32_T P_57 [ 2 ] ; real32_T P_58 ; real32_T P_59 ;
real32_T P_60 ; real32_T P_61 ; real32_T P_62 ; real32_T P_63 ; real32_T P_64
; real32_T P_65 ; real32_T P_66 ; real32_T P_67 ; real32_T P_68 ; real32_T
P_69 ; real32_T P_70 ; real32_T P_71 ; real32_T P_72 ; real32_T P_73 [ 4 ] ;
real32_T P_74 [ 2 ] ; real32_T P_75 [ 2 ] ; real32_T P_76 [ 4 ] ; real32_T
P_77 [ 4 ] ; real32_T P_78 [ 25 ] ; real32_T P_79 ; real32_T P_80 ; uint32_T
P_81 ; uint32_T P_82 ; uint32_T P_83 ; uint32_T P_84 ; uint32_T P_85 ;
boolean_T P_86 [ 126 ] ; boolean_T P_87 ; } ; struct cyntjpgsgd { struct
SimStruct_tag * _mdlRefSfcnS ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ; void * dataAddress [
7 ] ; int32_T * vardimsAddress [ 7 ] ; RTWLoggingFcnPtr loggingPtrs [ 7 ] ;
sysRanDType * systemRan [ 10 ] ; int_T systemTid [ 10 ] ; } DataMapInfo ;
struct { int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ; typedef struct {
llf3xg3ir0 rtb ; j4ytv2gj5l rtdw ; a0qef2fbcm rtm ; } c5e02tcafze ; extern
void c1o4boxk4f ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , a0qef2fbcm * const iu2zxy1bg0 , llf3xg3ir0 * localB ,
j4ytv2gj5l * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_LKARefMdl_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) ; extern mxArray * mr_LKARefMdl_GetDWork ( const c5e02tcafze
* mdlrefDW ) ; extern void mr_LKARefMdl_SetDWork ( c5e02tcafze * mdlrefDW ,
const mxArray * ssDW ) ; extern void mr_LKARefMdl_RegisterSimStateChecksum (
SimStruct * S ) ; extern mxArray * mr_LKARefMdl_GetSimStateDisallowedBlocks (
) ; extern const rtwCAPI_ModelMappingStaticInfo * LKARefMdl_GetCAPIStaticMap
( void ) ; extern void jzx5dnvkfi ( llf3xg3ir0 * localB , j4ytv2gj5l *
localDW ) ; extern void krrs31v12z ( j4ytv2gj5l * localDW ) ; extern void
i04fihmrp3 ( a0qef2fbcm * const iu2zxy1bg0 , j4ytv2gj5l * localDW ) ; extern
void i30xuqpc24 ( llf3xg3ir0 * localB , j4ytv2gj5l * localDW ) ; extern void
i30xuqpc24TID1 ( void ) ; extern void LKARefMdl ( a0qef2fbcm * const
iu2zxy1bg0 , const boolean_T * dl2h23j0yb , const real32_T * ggzreh1sbs ,
const real32_T * gy14yybqge , const real32_T * j5ofsry4is , const LaneSensor
* a0xrpmr0lc , boolean_T * gsarxirkom , real32_T * h0jeecywei , llf3xg3ir0 *
localB , j4ytv2gj5l * localDW ) ; extern void LKARefMdlTID1 ( llf3xg3ir0 *
localB ) ; extern void cpebt4uidm ( a0qef2fbcm * const iu2zxy1bg0 ,
j4ytv2gj5l * localDW ) ;
#endif
