#include "__cf_LKARefMdl.h"
#include "LKARefMdl_capi.h"
#include "LKARefMdl.h"
#include "LKARefMdl_private.h"
#include "expm_cf1QcFJp.h"
#include "eye_1T7g1wOb.h"
#include "eye_XDJCRWpB.h"
#include "kron_Ttkz0gFO.h"
#include "linsolve_EyNVDqi8.h"
#include "mpc_calculatehessian_9zqei9Pk.h"
#include "mpc_checkhessian_TWQ9ptm9.h"
#include "mpc_plantupdate_aUusw0Me.h"
#include "mpc_solveQP_tAv4OttS.h"
#include "mrdivide_fJHemlFH.h"
#define lh4i401auv (0.1)
#define bauenncvm4 (0.0F)
#define cuaadrc4tk (2.0F)
#define f43ek1jv4i (2.0F)
#define fezg14yxt4 (0.0F)
#define gvcozy12gk (100.0F)
#define kkm2wxaox0 (0.0F)
#define o4niutdbjr (0.104563959F)
static RegMdlInfo rtMdlInfo_LKARefMdl [ 49 ] = { { "c5e02tcafze" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"dfyfcgje3y" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"LKARefMdl" } , { "b5qh5jlw2a" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "LKARefMdl" } , { "fuzracfvxj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "LKARefMdl" } , { "lv5ia31ad1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"jmjik2zdrk" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"LKARefMdl" } , { "nq0hadfx3j" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "LKARefMdl" } , { "e2mdoggnhy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "LKARefMdl" } , { "e4yo3kpe0y" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"o0yd1ogfgf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"LKARefMdl" } , { "j4ytv2gj5l" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "LKARefMdl" } , { "llf3xg3ir0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "LKARefMdl" } , { "czhw1awfdh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"cpebt4uidm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"LKARefMdl" } , { "dmps3x051h" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "LKARefMdl" } , { "i30xuqpc24" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "LKARefMdl" } , { "krrs31v12z" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"jzx5dnvkfi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"LKARefMdl" } , { "c1o4boxk4f" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "LKARefMdl" } , { "i04fihmrp3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "LKARefMdl" } , { "pi2hal0oyf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"LKARefMdl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , {
"obhazq4wljz" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"LKARefMdl" } , { "fiicwwhzf55" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "LKARefMdl" } , { "key2goxtas" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"oq4nax3k04w" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"LKARefMdl" } , { "getmygpfj4y" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "LKARefMdl" } , { "iu3ymxn2bga" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"obhazq4wlj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"LKARefMdl" } , { "fiicwwhzf5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "LKARefMdl" } , { "oq4nax3k04" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "LKARefMdl" } , { "cyntjpgsgd" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"a0qef2fbcm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"LKARefMdl" } , { "LaneSensor" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) }
, { "LaneSensorBoundaries" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_LKARefMdl_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "LKARefMdl" } , {
"mr_LKARefMdl_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"mr_LKARefMdl_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"mr_LKARefMdl_restoreDataFromMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "LKARefMdl" } , {
"mr_LKARefMdl_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "LKARefMdl" } , {
"mr_LKARefMdl_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "LKARefMdl" } , { "mr_LKARefMdl_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"mr_LKARefMdl_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1
, ( void * ) "LKARefMdl" } , { "mr_LKARefMdl_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"mr_LKARefMdl_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "LKARefMdl" } , { "mr_LKARefMdl_SetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "LKARefMdl" } , {
"mr_LKARefMdl_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"LKARefMdl" } , { "LKARefMdl.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL
) } , { "LKARefMdl.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"LKARefMdl" } } ; ajghr3ctyrx ajghr3ctyr = { 0.5 , - 0.5 , 0.0 , 5.0F , 0.0F
, 0.1 , 0.5F , 0.5F , 0.5F , 0.5F , 1.0F , 1.8F , 1.8F , 1.0F , 1.8F , 1.8F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.5F , - 0.5F , 0.0F , 0.6F , - 0.6F , {
0.0F , 0.0F , 0.0F , 0.0F , 0.0F } , 0.0F , { 0.0F , 0.0F } , 0.0F , 0.15F ,
- 0.15F , 0.0F , 0.06F , - 0.06F , 1.0F , 1.0F , - 1.8446743E+19F , -
1.8446743E+19F , { 2.0F , 10.0F } , 1.8446743E+19F , 1.8446743E+19F , { 2.0F
, 10.0F } , 0.0F , 1.0F , { 0.0F , 0.0F } , { 0.5F , 0.1F } , 0.0F , 0.0F ,
0.01F , 0.0F , 1.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , { 0.0F , 0.0F } ,
0.0F , 0.0F , 0.0F , 0.1F , 33000.0F , 19000.0F , - 2.0F , 1575.0F , 1.6F ,
1.2F , - 2.0F , 2875.0F , - 2.0F , 2.0F , 2.0F , { 1.0F , 0.0F , 0.0F , 1.0F
} , { 0.0F , 0.0F } , { 0.0F , 0.0F } , { 0.0F , 0.0F , 0.0F , 0.0F } , {
0.0F , 0.0F , 0.0F , 0.0F } , { 1.66797101F , 1.59068179F , 0.0921302512F ,
0.0573913231F , 0.0124118561F , 1.59068179F , 2.21350813F , 0.289069504F ,
0.182445616F , - 0.00430615433F , 0.0921302512F , 0.289069504F , 0.159108192F
, 0.0522713587F , - 0.0542674623F , 0.0573913231F , 0.182445616F ,
0.0522713587F , 0.0281382445F , - 0.0102597103F , 0.0124118561F , -
0.00430615433F , - 0.0542674623F , - 0.0102597103F , 0.135252312F } , - 1.0F
, 1.0F , 1U , 1U , 1U , 1U , 1U , { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } , 0 }
; static real32_T bandf5244w ( real32_T x ) ; static void j3f42jwfjx (
real32_T b_Mlim [ 126 ] , const real32_T b_Mrows [ 126 ] , const real32_T U0
[ 2 ] , const real32_T b_Uscale [ 2 ] , real32_T b_utarget [ 30 ] , const
real32_T Y0 [ 2 ] , const real32_T b_Yscale [ 2 ] , const real32_T old_yoff [
2 ] , const real32_T b_myindex [ 2 ] , const real32_T X0 [ 4 ] , real32_T
b_xoff [ 5 ] , const real32_T DX0 [ 4 ] , real32_T Bv [ 310 ] , real32_T *
new_mvoff , real32_T * new_mdoff , real32_T new_yoff [ 2 ] , real32_T
new_myoff [ 2 ] ) ; static void igprtpl1k4 ( const real32_T ref [ 2 ] , const
real32_T md [ 31 ] , const real32_T b_yoff [ 2 ] , real32_T b_voff , const
real32_T b_RYscale [ 2 ] , real32_T b_RMDscale , real32_T rseq [ 60 ] ,
real32_T vseq [ 62 ] , real32_T v [ 2 ] ) ; static void p2p55rz3qa ( const
real32_T b_A [ 25 ] , const real32_T Bu [ 155 ] , const real32_T Bv [ 310 ] ,
const real32_T b_C [ 10 ] , const real32_T Dv [ 124 ] , const real32_T b_Jm [
90 ] , real32_T b_SuJm [ 180 ] , real32_T b_Sx [ 300 ] , real32_T b_Su1 [ 60
] , real32_T b_Hv [ 3720 ] , llf3xg3ir0 * localB ) ; static void lwcdcfsdhw (
const real32_T rseq [ 60 ] , const real32_T vseq [ 62 ] , real32_T umin ,
real32_T umax , const real32_T ymin [ 2 ] , const real32_T ymax [ 2 ] ,
real32_T switch_in , const real32_T x [ 5 ] , real32_T old_u , const
boolean_T iA [ 126 ] , const real32_T b_Mlim [ 126 ] , real32_T b_Mx [ 630 ]
, real32_T b_Mu1 [ 126 ] , real32_T b_Mv [ 7812 ] , const real32_T b_utarget
[ 30 ] , real32_T b_uoff , const real32_T b_yoff [ 2 ] , real32_T
b_enable_value , real32_T b_H [ 16 ] , real32_T b_Ac [ 504 ] , const real32_T
b_Wy [ 2 ] , const real32_T b_Jm [ 90 ] , const real32_T b_I1 [ 30 ] , const
real32_T b_A [ 25 ] , const real32_T Bu [ 155 ] , const real32_T Bv [ 310 ] ,
const real32_T b_C [ 10 ] , const real32_T Dv [ 124 ] , const real32_T
b_Mrows [ 126 ] , real32_T * u , real32_T useq [ 30 ] , real32_T * status ,
boolean_T iAout [ 126 ] , llf3xg3ir0 * localB ) ; static real32_T bandf5244w
( real32_T x ) { real32_T r ; if ( ( ! muSingleScalarIsInf ( x ) ) && ( !
muSingleScalarIsNaN ( x ) ) ) { if ( x == 0.0F ) { r = 0.0F ; } else { r =
muSingleScalarRem ( x , f43ek1jv4i ) ; if ( r == 0.0F ) { r = 0.0F ; } else {
if ( x < 0.0F ) { r += f43ek1jv4i ; } } } } else { r = ( rtNaNF ) ; } return
r ; } static void j3f42jwfjx ( real32_T b_Mlim [ 126 ] , const real32_T
b_Mrows [ 126 ] , const real32_T U0 [ 2 ] , const real32_T b_Uscale [ 2 ] ,
real32_T b_utarget [ 30 ] , const real32_T Y0 [ 2 ] , const real32_T b_Yscale
[ 2 ] , const real32_T old_yoff [ 2 ] , const real32_T b_myindex [ 2 ] ,
const real32_T X0 [ 4 ] , real32_T b_xoff [ 5 ] , const real32_T DX0 [ 4 ] ,
real32_T Bv [ 310 ] , real32_T * new_mvoff , real32_T * new_mdoff , real32_T
new_yoff [ 2 ] , real32_T new_myoff [ 2 ] ) { real32_T k ; int32_T ct ; *
new_mvoff = U0 [ 0 ] / b_Uscale [ 0 ] ; new_yoff [ 0 ] = Y0 [ 0 ] / b_Yscale
[ 0 ] ; new_yoff [ 1 ] = Y0 [ 1 ] / b_Yscale [ 1 ] ; * new_mdoff = U0 [ 1 ] /
b_Uscale [ 1 ] ; new_myoff [ 0 ] = new_yoff [ ( int32_T ) b_myindex [ 0 ] - 1
] ; new_myoff [ 1 ] = new_yoff [ ( int32_T ) b_myindex [ 1 ] - 1 ] ; for ( ct
= 0 ; ct < 126 ; ct ++ ) { if ( b_Mrows [ ct ] <= 60.0F ) { k = bandf5244w (
b_Mrows [ ct ] - 1.0F ) + 1.0F ; b_Mlim [ ct ] += old_yoff [ ( int32_T ) k -
1 ] - new_yoff [ ( int32_T ) k - 1 ] ; } else if ( b_Mrows [ ct ] <= 120.0F )
{ k = bandf5244w ( ( b_Mrows [ ct ] - 60.0F ) - 1.0F ) + 1.0F ; b_Mlim [ ct ]
-= old_yoff [ ( int32_T ) k - 1 ] - new_yoff [ ( int32_T ) k - 1 ] ; } else
if ( b_Mrows [ ct ] <= 150.0F ) { b_Mlim [ ct ] += kkm2wxaox0 - * new_mvoff ;
} else { if ( b_Mrows [ ct ] <= 180.0F ) { b_Mlim [ ct ] -= kkm2wxaox0 - *
new_mvoff ; } } } for ( ct = 0 ; ct < 30 ; ct ++ ) { b_utarget [ ct ] -= *
new_mvoff ; } b_xoff [ 0 ] = X0 [ 0 ] ; Bv [ 5 ] = DX0 [ 0 ] ; b_xoff [ 1 ] =
X0 [ 1 ] ; Bv [ 6 ] = DX0 [ 1 ] ; b_xoff [ 2 ] = X0 [ 2 ] ; Bv [ 7 ] = DX0 [
2 ] ; b_xoff [ 3 ] = X0 [ 3 ] ; Bv [ 8 ] = DX0 [ 3 ] ; } static void
igprtpl1k4 ( const real32_T ref [ 2 ] , const real32_T md [ 31 ] , const
real32_T b_yoff [ 2 ] , real32_T b_voff , const real32_T b_RYscale [ 2 ] ,
real32_T b_RMDscale , real32_T rseq [ 60 ] , real32_T vseq [ 62 ] , real32_T
v [ 2 ] ) { int32_T i ; int32_T rseq_tmp ; for ( i = 0 ; i < 62 ; i ++ ) {
vseq [ i ] = 0.0F ; } for ( i = 0 ; i < 31 ; i ++ ) { vseq [ ( i * ( int32_T
) cuaadrc4tk + ( int32_T ) cuaadrc4tk ) - 1 ] = 1.0F ; } for ( i = 0 ; i < 60
; i ++ ) { rseq [ i ] = 0.0F ; } for ( i = 0 ; i < 30 ; i ++ ) { rseq_tmp = i
* ( int32_T ) f43ek1jv4i ; rseq [ rseq_tmp ] = ref [ 0 ] * b_RYscale [ 0 ] -
b_yoff [ 0 ] ; rseq [ 1 + rseq_tmp ] = ref [ 1 ] * b_RYscale [ 1 ] - b_yoff [
1 ] ; } for ( i = 0 ; i < 31 ; i ++ ) { vseq [ i * ( int32_T ) cuaadrc4tk ] =
b_RMDscale * md [ i ] - b_voff ; } v [ 0 ] = vseq [ 0 ] ; v [ 1 ] = vseq [ 1
] ; } static void p2p55rz3qa ( const real32_T b_A [ 25 ] , const real32_T Bu
[ 155 ] , const real32_T Bv [ 310 ] , const real32_T b_C [ 10 ] , const
real32_T Dv [ 124 ] , const real32_T b_Jm [ 90 ] , real32_T b_SuJm [ 180 ] ,
real32_T b_Sx [ 300 ] , real32_T b_Su1 [ 60 ] , real32_T b_Hv [ 3720 ] ,
llf3xg3ir0 * localB ) { real32_T CA [ 10 ] ; real32_T Sum [ 2 ] ; int8_T rows
[ 2 ] ; int32_T i ; int32_T i_p ; int32_T i_e ; int32_T i_i ; real32_T b_C_p
[ 4 ] ; int32_T i_m ; int8_T i_g ; real32_T tmp ; real32_T Sum_p [ 60 ] ;
int32_T i_j ; real32_T CA_p [ 124 ] ; real32_T CA_e [ 10 ] ; int32_T tmp_p ;
int32_T CA_tmp ; for ( i_p = 0 ; i_p < 2 ; i_p ++ ) { Sum [ i_p ] = 0.0F ;
for ( i_e = 0 ; i_e < 5 ; i_e ++ ) { CA [ i_p + ( i_e << 1 ) ] = 0.0F ; for (
i_i = 0 ; i_i < 5 ; i_i ++ ) { CA [ i_p + ( i_e << 1 ) ] += b_C [ ( i_i << 1
) + i_p ] * b_A [ 5 * i_e + i_i ] ; } Sum [ i_p ] += b_C [ ( i_e << 1 ) + i_p
] * Bu [ i_e ] ; } for ( i_e = 0 ; i_e < 2 ; i_e ++ ) { b_C_p [ i_p + ( i_e
<< 1 ) ] = 0.0F ; for ( i_i = 0 ; i_i < 5 ; i_i ++ ) { b_C_p [ i_p + ( i_e <<
1 ) ] += b_C [ ( i_i << 1 ) + i_p ] * Bv [ 5 * i_e + i_i ] ; } } } b_Hv [ 0 ]
= b_C_p [ 0 ] ; b_Hv [ 120 ] = Dv [ 0 ] ; b_Hv [ 1 ] = b_C_p [ 1 ] ; b_Hv [
121 ] = Dv [ 1 ] ; b_Hv [ 60 ] = b_C_p [ 2 ] ; b_Hv [ 180 ] = Dv [ 2 ] ; b_Hv
[ 61 ] = b_C_p [ 3 ] ; b_Hv [ 181 ] = Dv [ 3 ] ; i_p = 0 ; for ( i_e = 0 ;
i_e < 58 ; i_e ++ ) { b_Hv [ i_p + 240 ] = 0.0F ; b_Hv [ i_p + 241 ] = 0.0F ;
i_p += 60 ; } i_p = 0 ; for ( i_e = 0 ; i_e < 62 ; i_e ++ ) { for ( i_i = 0 ;
i_i < 58 ; i_i ++ ) { b_Hv [ ( i_i + i_p ) + 2 ] = 0.0F ; } i_p += 60 ; } i_p
= 0 ; i_e = 0 ; for ( i_i = 0 ; i_i < 5 ; i_i ++ ) { b_Sx [ i_p ] = CA [ i_e
] ; b_Sx [ i_p + 1 ] = CA [ i_e + 1 ] ; for ( i_m = 0 ; i_m < 58 ; i_m ++ ) {
b_Sx [ ( i_m + i_p ) + 2 ] = 0.0F ; } i_p += 60 ; i_e += 2 ; } b_Su1 [ 0 ] =
Sum [ 0 ] ; b_Su1 [ 1 ] = Sum [ 1 ] ; for ( i = 0 ; i < 58 ; i ++ ) { b_Su1 [
i + 2 ] = 0.0F ; } localB -> gvlj43vtsb [ 0 ] = Sum [ 0 ] ; localB ->
gvlj43vtsb [ 1 ] = Sum [ 1 ] ; i_p = 0 ; for ( i_e = 0 ; i_e < 29 ; i_e ++ )
{ localB -> gvlj43vtsb [ i_p + 60 ] = 0.0F ; localB -> gvlj43vtsb [ i_p + 61
] = 0.0F ; i_p += 60 ; } i_p = 0 ; for ( i_e = 0 ; i_e < 30 ; i_e ++ ) { for
( i_i = 0 ; i_i < 58 ; i_i ++ ) { localB -> gvlj43vtsb [ ( i_i + i_p ) + 2 ]
= 0.0F ; } i_p += 60 ; } for ( i = 0 ; i < 29 ; i ++ ) { i_g = ( int8_T ) ( (
( i + 1 ) << 1 ) + 1 ) ; for ( i_p = 0 ; i_p < 2 ; i_p ++ ) { rows [ i_p ] =
( int8_T ) ( i_p + i_g ) ; tmp = 0.0F ; i_e = 0 ; for ( i_i = 0 ; i_i < 5 ;
i_i ++ ) { tmp += CA [ i_e + i_p ] * Bu [ i_i ] ; i_e += 2 ; } Sum [ i_p ] +=
tmp ; } b_Su1 [ rows [ 0 ] - 1 ] = Sum [ 0 ] ; Sum_p [ 0 ] = Sum [ 0 ] ;
b_Su1 [ rows [ 1 ] - 1 ] = Sum [ 1 ] ; Sum_p [ 1 ] = Sum [ 1 ] ; for ( i_p =
0 ; i_p < 29 ; i_p ++ ) { Sum_p [ ( i_p + 1 ) << 1 ] = localB -> gvlj43vtsb [
( 60 * i_p + rows [ 0 ] ) - 3 ] ; Sum_p [ 1 + ( ( i_p + 1 ) << 1 ) ] = localB
-> gvlj43vtsb [ ( 60 * i_p + rows [ 1 ] ) - 3 ] ; } for ( i_p = 0 ; i_p < 30
; i_p ++ ) { localB -> gvlj43vtsb [ ( rows [ 0 ] + 60 * i_p ) - 1 ] = Sum_p [
i_p << 1 ] ; localB -> gvlj43vtsb [ ( rows [ 1 ] + 60 * i_p ) - 1 ] = Sum_p [
( i_p << 1 ) + 1 ] ; } for ( i_p = 0 ; i_p < 2 ; i_p ++ ) { i_e = 0 ; i_i = 0
; for ( i_m = 0 ; i_m < 2 ; i_m ++ ) { CA_tmp = i_e + i_p ; b_C_p [ CA_tmp ]
= 0.0F ; tmp_p = 0 ; for ( i_j = 0 ; i_j < 5 ; i_j ++ ) { b_C_p [ CA_tmp ] +=
CA [ tmp_p + i_p ] * Bv [ i_j + i_i ] ; tmp_p += 2 ; } i_e += 2 ; i_i += 5 ;
} } CA_p [ 0 ] = b_C_p [ 0 ] ; CA_p [ 1 ] = b_C_p [ 1 ] ; CA_p [ 2 ] = b_C_p
[ 2 ] ; CA_p [ 3 ] = b_C_p [ 3 ] ; for ( i_p = 0 ; i_p < 60 ; i_p ++ ) { CA_p
[ ( i_p + 2 ) << 1 ] = b_Hv [ ( 60 * i_p + rows [ 0 ] ) - 3 ] ; CA_p [ 1 + (
( i_p + 2 ) << 1 ) ] = b_Hv [ ( 60 * i_p + rows [ 1 ] ) - 3 ] ; } for ( i_p =
0 ; i_p < 62 ; i_p ++ ) { b_Hv [ ( rows [ 0 ] + 60 * i_p ) - 1 ] = CA_p [ i_p
<< 1 ] ; b_Hv [ ( rows [ 1 ] + 60 * i_p ) - 1 ] = CA_p [ ( i_p << 1 ) + 1 ] ;
} for ( i_p = 0 ; i_p < 2 ; i_p ++ ) { i_e = 0 ; i_i = 0 ; for ( i_m = 0 ;
i_m < 5 ; i_m ++ ) { CA_tmp = i_e + i_p ; CA_e [ CA_tmp ] = 0.0F ; tmp_p = 0
; for ( i_j = 0 ; i_j < 5 ; i_j ++ ) { CA_e [ CA_tmp ] += CA [ tmp_p + i_p ]
* b_A [ i_j + i_i ] ; tmp_p += 2 ; } i_e += 2 ; i_i += 5 ; } } for ( i_p = 0
; i_p < 5 ; i_p ++ ) { b_Sx [ ( rows [ 0 ] + 60 * i_p ) - 1 ] = CA_e [ i_p <<
1 ] ; CA [ i_p << 1 ] = CA_e [ i_p << 1 ] ; b_Sx [ ( rows [ 1 ] + 60 * i_p )
- 1 ] = CA_e [ ( i_p << 1 ) + 1 ] ; CA [ 1 + ( i_p << 1 ) ] = CA_e [ ( i_p <<
1 ) + 1 ] ; } } i_p = 0 ; i_e = 0 ; for ( i_i = 0 ; i_i < 3 ; i_i ++ ) { for
( i_m = 0 ; i_m < 60 ; i_m ++ ) { i = i_m + i_p ; b_SuJm [ i ] = 0.0F ; tmp_p
= 0 ; for ( i_j = 0 ; i_j < 30 ; i_j ++ ) { b_SuJm [ i ] += localB ->
gvlj43vtsb [ tmp_p + i_m ] * b_Jm [ i_j + i_e ] ; tmp_p += 60 ; } } i_p += 60
; i_e += 30 ; } } static void lwcdcfsdhw ( const real32_T rseq [ 60 ] , const
real32_T vseq [ 62 ] , real32_T umin , real32_T umax , const real32_T ymin [
2 ] , const real32_T ymax [ 2 ] , real32_T switch_in , const real32_T x [ 5 ]
, real32_T old_u , const boolean_T iA [ 126 ] , const real32_T b_Mlim [ 126 ]
, real32_T b_Mx [ 630 ] , real32_T b_Mu1 [ 126 ] , real32_T b_Mv [ 7812 ] ,
const real32_T b_utarget [ 30 ] , real32_T b_uoff , const real32_T b_yoff [ 2
] , real32_T b_enable_value , real32_T b_H [ 16 ] , real32_T b_Ac [ 504 ] ,
const real32_T b_Wy [ 2 ] , const real32_T b_Jm [ 90 ] , const real32_T b_I1
[ 30 ] , const real32_T b_A [ 25 ] , const real32_T Bu [ 155 ] , const
real32_T Bv [ 310 ] , const real32_T b_C [ 10 ] , const real32_T Dv [ 124 ] ,
const real32_T b_Mrows [ 126 ] , real32_T * u , real32_T useq [ 30 ] ,
real32_T * status , boolean_T iAout [ 126 ] , llf3xg3ir0 * localB ) {
real32_T c_Linv [ 16 ] ; real32_T Bc [ 126 ] ; real32_T ymax_incr [ 2 ] ;
real32_T ymin_incr [ 2 ] ; real32_T umax_incr ; real32_T umin_incr ; real32_T
DelBound ; real32_T ii ; real32_T c_SuJm [ 180 ] ; real32_T c_Sx [ 300 ] ;
real32_T c_Su1 [ 60 ] ; real32_T b [ 9 ] ; real32_T c_Ku1 [ 3 ] ; real32_T
c_Kut [ 90 ] ; real32_T c_Kx [ 15 ] ; real32_T c_Kv [ 186 ] ; real32_T c_Kr [
180 ] ; real32_T d_Linv [ 16 ] ; real32_T zopt [ 4 ] ; real32_T f [ 4 ] ;
int32_T b_i ; static const real32_T c [ 900 ] = { 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F ,
0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F ,
1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F ,
1.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 1.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 1.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 1.0F } ; int32_T i ; real32_T tmp [ 16 ] ;
real32_T tmp_p [ 900 ] ; real32_T tmp_e [ 90 ] ; int32_T i_p ; real32_T
b_Mv_p [ 126 ] ; int32_T b_Mrows_p ; int32_T i_e ; int32_T c_Linv_tmp ;
boolean_T exitg1 ; boolean_T guard1 = false ; for ( i = 0 ; i < 30 ; i ++ ) {
useq [ i ] = 0.0F ; } * status = 1.0F ; memset ( & iAout [ 0 ] , 0 , 126U *
sizeof ( boolean_T ) ) ; if ( switch_in != b_enable_value ) { * u = old_u +
b_uoff ; for ( i = 0 ; i < 30 ; i ++ ) { useq [ i ] = * u ; } } else {
p2p55rz3qa ( b_A , Bu , Bv , b_C , Dv , b_Jm , c_SuJm , c_Sx , c_Su1 , localB
-> k3bfvaswdr , localB ) ; if ( b_Mrows [ 0 ] > 0.0F ) { i = 0 ; exitg1 =
false ; while ( ( ! exitg1 ) && ( i < 126 ) ) { if ( b_Mrows [ i ] <= 60.0F )
{ b_Mrows_p = ( int32_T ) b_Mrows [ i ] ; b_Ac [ i ] = - c_SuJm [ b_Mrows_p -
1 ] ; b_Ac [ i + 126 ] = - c_SuJm [ b_Mrows_p + 59 ] ; b_Ac [ i + 252 ] = -
c_SuJm [ b_Mrows_p + 119 ] ; b_Mrows_p = ( int32_T ) b_Mrows [ i ] ; for (
b_i = 0 ; b_i < 5 ; b_i ++ ) { b_Mx [ i + 126 * b_i ] = - c_Sx [ ( 60 * b_i +
b_Mrows_p ) - 1 ] ; } b_Mu1 [ i ] = - c_Su1 [ ( int32_T ) b_Mrows [ i ] - 1 ]
; b_Mrows_p = ( int32_T ) b_Mrows [ i ] ; for ( b_i = 0 ; b_i < 62 ; b_i ++ )
{ b_Mv [ i + 126 * b_i ] = - localB -> k3bfvaswdr [ ( 60 * b_i + b_Mrows_p )
- 1 ] ; } i ++ ; } else if ( b_Mrows [ i ] <= 120.0F ) { b_Mrows_p = (
int32_T ) ( b_Mrows [ i ] - 60.0F ) ; b_Ac [ i ] = c_SuJm [ b_Mrows_p - 1 ] ;
b_Ac [ i + 126 ] = c_SuJm [ b_Mrows_p + 59 ] ; b_Ac [ i + 252 ] = c_SuJm [
b_Mrows_p + 119 ] ; b_Mrows_p = ( int32_T ) ( b_Mrows [ i ] - 60.0F ) ; for (
b_i = 0 ; b_i < 5 ; b_i ++ ) { b_Mx [ i + 126 * b_i ] = c_Sx [ ( 60 * b_i +
b_Mrows_p ) - 1 ] ; } b_Mu1 [ i ] = c_Su1 [ ( int32_T ) ( b_Mrows [ i ] -
60.0F ) - 1 ] ; b_Mrows_p = ( int32_T ) ( b_Mrows [ i ] - 60.0F ) ; for ( b_i
= 0 ; b_i < 62 ; b_i ++ ) { b_Mv [ i + 126 * b_i ] = localB -> k3bfvaswdr [ (
60 * b_i + b_Mrows_p ) - 1 ] ; } i ++ ; } else { exitg1 = true ; } } }
kron_Ttkz0gFO ( c , 1.0F , tmp_p ) ; b_i = 0 ; for ( i = 0 ; i < 3 ; i ++ ) {
for ( b_Mrows_p = 0 ; b_Mrows_p < 30 ; b_Mrows_p ++ ) { i_e = b_Mrows_p + b_i
; tmp_e [ i_e ] = 0.0F ; c_Linv_tmp = 0 ; for ( i_p = 0 ; i_p < 30 ; i_p ++ )
{ tmp_e [ i_e ] += tmp_p [ c_Linv_tmp + b_Mrows_p ] * b_Jm [ i_p + b_i ] ;
c_Linv_tmp += 30 ; } } b_i += 30 ; } mpc_calculatehessian_9zqei9Pk ( b_Wy ,
fezg14yxt4 , o4niutdbjr , c_SuJm , tmp_e , b_Jm , b_I1 , c_Su1 , c_Sx ,
localB -> k3bfvaswdr , b , c_Ku1 , c_Kut , c_Kx , c_Kv , c_Kr ) ; b_i = 0 ; i
= 0 ; for ( b_Mrows_p = 0 ; b_Mrows_p < 3 ; b_Mrows_p ++ ) { b_H [ b_i ] = b
[ i ] ; b_H [ b_i + 1 ] = b [ i + 1 ] ; b_H [ b_i + 2 ] = b [ i + 2 ] ; b_i
+= 4 ; i += 3 ; } memcpy ( & c_Linv [ 0 ] , & b_H [ 0 ] , sizeof ( real32_T )
<< 4U ) ; mpc_checkhessian_TWQ9ptm9 ( c_Linv , d_Linv , & umax_incr ) ; if (
umax_incr > 1.0F ) { * u = old_u + b_uoff ; for ( i = 0 ; i < 30 ; i ++ ) {
useq [ i ] = * u ; } * status = - 2.0F ; } else { eye_XDJCRWpB ( tmp ) ;
linsolve_EyNVDqi8 ( d_Linv , tmp , c_Linv ) ; for ( b_i = 0 ; b_i < 126 ; b_i
++ ) { umax_incr = 0.0F ; for ( i = 0 ; i < 5 ; i ++ ) { umax_incr += b_Mx [
126 * i + b_i ] * x [ i ] ; } b_Mv_p [ b_i ] = 0.0F ; for ( i = 0 ; i < 62 ;
i ++ ) { b_Mv_p [ b_i ] += b_Mv [ 126 * i + b_i ] * vseq [ i ] ; } Bc [ b_i ]
= - ( ( ( b_Mlim [ b_i ] + umax_incr ) + b_Mu1 [ b_i ] * old_u ) + b_Mv_p [
b_i ] ) ; } ymax_incr [ 0 ] = ( rtNaNF ) ; ymin_incr [ 0 ] = ( rtNaNF ) ;
ymax_incr [ 1 ] = ( rtNaNF ) ; ymin_incr [ 1 ] = ( rtNaNF ) ; umax_incr = (
rtNaNF ) ; umin_incr = ( rtNaNF ) ; if ( b_Mrows [ 0 ] > 0.0F ) { b_i = 0 ;
exitg1 = false ; while ( ( ! exitg1 ) && ( b_i < 126 ) ) { guard1 = false ;
if ( b_Mrows [ b_i ] <= 60.0F ) { ii = bandf5244w ( b_Mrows [ b_i ] - 1.0F )
+ 1.0F ; if ( muSingleScalarIsNaN ( ymax_incr [ ( int32_T ) ii - 1 ] ) ) {
DelBound = - ( ymax [ ( int32_T ) ii - 1 ] - b_yoff [ ( int32_T ) ii - 1 ] )
- ( - b_Mlim [ b_i ] ) ; } else { DelBound = ymax_incr [ ( int32_T ) ii - 1 ]
; } ymax_incr [ ( int32_T ) ii - 1 ] = DelBound ; guard1 = true ; } else if (
b_Mrows [ b_i ] <= 120.0F ) { ii = bandf5244w ( ( b_Mrows [ b_i ] - 60.0F ) -
1.0F ) + 1.0F ; if ( muSingleScalarIsNaN ( ymin_incr [ ( int32_T ) ii - 1 ] )
) { DelBound = ( ymin [ ( int32_T ) ii - 1 ] - b_yoff [ ( int32_T ) ii - 1 ]
) - ( - b_Mlim [ b_i ] ) ; } else { DelBound = ymin_incr [ ( int32_T ) ii - 1
] ; } ymin_incr [ ( int32_T ) ii - 1 ] = DelBound ; guard1 = true ; } else if
( b_Mrows [ b_i ] <= 150.0F ) { if ( muSingleScalarIsNaN ( umax_incr ) ) {
umax_incr = - ( umax - b_uoff ) - ( - b_Mlim [ b_i ] ) ; } DelBound =
umax_incr ; guard1 = true ; } else if ( b_Mrows [ b_i ] <= 180.0F ) { if (
muSingleScalarIsNaN ( umin_incr ) ) { umin_incr = ( umin - b_uoff ) - ( -
b_Mlim [ b_i ] ) ; } DelBound = umin_incr ; guard1 = true ; } else { exitg1 =
true ; } if ( guard1 ) { Bc [ b_i ] += DelBound ; b_i ++ ; } } } memcpy ( &
iAout [ 0 ] , & iA [ 0 ] , 126U * sizeof ( boolean_T ) ) ; b_i = 0 ; for ( i
= 0 ; i < 4 ; i ++ ) { b_Mrows_p = 0 ; for ( i_e = 0 ; i_e < 4 ; i_e ++ ) {
c_Linv_tmp = b_Mrows_p + i ; d_Linv [ c_Linv_tmp ] = 0.0F ; d_Linv [
c_Linv_tmp ] += c_Linv [ b_i ] * c_Linv [ b_Mrows_p ] ; d_Linv [ c_Linv_tmp ]
= c_Linv [ b_i + 1 ] * c_Linv [ b_Mrows_p + 1 ] + d_Linv [ b_Mrows_p + i ] ;
d_Linv [ c_Linv_tmp ] = c_Linv [ b_i + 2 ] * c_Linv [ b_Mrows_p + 2 ] +
d_Linv [ b_Mrows_p + i ] ; d_Linv [ c_Linv_tmp ] = c_Linv [ b_i + 3 ] *
c_Linv [ b_Mrows_p + 3 ] + d_Linv [ b_Mrows_p + i ] ; b_Mrows_p += 4 ; } b_i
+= 4 ; } mpc_solveQP_tAv4OttS ( x , c_Kx , c_Kr , rseq , c_Ku1 , old_u , c_Kv
, vseq , c_Kut , b_utarget , c_Linv , d_Linv , b_Ac , Bc , iAout , zopt , f ,
status ) ; * u = ( old_u + zopt [ 0 ] ) + b_uoff ; } } } void jzx5dnvkfi (
llf3xg3ir0 * localB , j4ytv2gj5l * localDW ) { int32_T i ; memcpy ( & localDW
-> enqs1wotqd [ 0 ] , & ajghr3ctyr . P_86 [ 0 ] , 126U * sizeof ( boolean_T )
) ; localDW -> c20jlygsay = ajghr3ctyr . P_16 ; localDW -> hryujm23gv =
ajghr3ctyr . P_17 ; localDW -> idw3weirf3 = ajghr3ctyr . P_18 ; localDW ->
ayeaqphirh = ajghr3ctyr . P_19 ; for ( i = 0 ; i < 5 ; i ++ ) { localDW ->
cf5jrvxca5 [ i ] = ajghr3ctyr . P_26 [ i ] ; } localDW -> kxvvsjr51z =
ajghr3ctyr . P_27 ; memcpy ( & localDW -> fowmhxaqij [ 0 ] , & ajghr3ctyr .
P_78 [ 0 ] , 25U * sizeof ( real32_T ) ) ; for ( i = 0 ; i < 5 ; i ++ ) {
localDW -> jx11wd5i0n [ i ] = ajghr3ctyr . P_4 ; } localDW -> mbmtbdjeqm =
ajghr3ctyr . P_87 ; localB -> iae25d40vx = ajghr3ctyr . P_20 ; localB ->
nfr45zfsgr = ajghr3ctyr . P_23 ; localB -> mmcgmfp2o3 = ajghr3ctyr . P_29 ;
localB -> hbjo123h1b = ajghr3ctyr . P_32 ; } void krrs31v12z ( j4ytv2gj5l *
localDW ) { int32_T i ; memcpy ( & localDW -> enqs1wotqd [ 0 ] , & ajghr3ctyr
. P_86 [ 0 ] , 126U * sizeof ( boolean_T ) ) ; localDW -> c20jlygsay =
ajghr3ctyr . P_16 ; localDW -> hryujm23gv = ajghr3ctyr . P_17 ; localDW ->
idw3weirf3 = ajghr3ctyr . P_18 ; localDW -> ayeaqphirh = ajghr3ctyr . P_19 ;
for ( i = 0 ; i < 5 ; i ++ ) { localDW -> cf5jrvxca5 [ i ] = ajghr3ctyr .
P_26 [ i ] ; } localDW -> kxvvsjr51z = ajghr3ctyr . P_27 ; memcpy ( & localDW
-> fowmhxaqij [ 0 ] , & ajghr3ctyr . P_78 [ 0 ] , 25U * sizeof ( real32_T ) )
; for ( i = 0 ; i < 5 ; i ++ ) { localDW -> jx11wd5i0n [ i ] = ajghr3ctyr .
P_4 ; } localDW -> mbmtbdjeqm = ajghr3ctyr . P_87 ; } void i04fihmrp3 (
a0qef2fbcm * const iu2zxy1bg0 , j4ytv2gj5l * localDW ) { if ( ( ssGetSimMode
( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( iu2zxy1bg0 ->
_mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void * slioCatalogue =
rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) :
sdiGetSlioCatalogue ( iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath ) ; if ( ! slioCatalogue || ! rtwDisableStreamingToRepository (
slioCatalogue ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "assisted_steer" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "assisted_steer" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"LKARefMdl/Lane Keeping Controller" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiDims forEachMdlRefDims ; int_T forEachMdlRefDimsArray
[ 32 ] ; sdiLabelU sigName = sdiGetLabelFromChars ( "assisted_steer" ) ;
sdiAsyncQueueHandle hForEachParent = ( NULL ) ; sdiAsyncRepoDataTypeHandle
hDT = sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_SINGLE ) ; {
sdiComplexity sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1
; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; if (
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDims . nDims = 0 ; } else
{ forEachMdlRefDims . nDims = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> d0ox53zfja . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , iu2zxy1bg0 -> DataMapInfo
. mmi . InstanceMap . fullPath , "0a07d14e-4c45-4c29-ab01-8f01b4a8d9fc" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if (
localDW -> d0ox53zfja . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> d0ox53zfja . AQHandles , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) ) ;
sdiSetRunStartTime ( localDW -> d0ox53zfja . AQHandles , rtmGetTaskTime (
iu2zxy1bg0 , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
d0ox53zfja . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> d0ox53zfja . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> d0ox53zfja . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 1 ,
"assisted_steer" , "zoh" , 0 , ( unsigned int * ) sigDimsArray , 1 , "single"
, "" , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) , treeVector ) ; }
signalDescriptor = rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 ,
"assisted_steer" , "" , iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath , "LKARefMdl/Lane Keeping Controller" , 1 , 0 , slioCatalogue ,
forEachMdlRefDimsArraySize ? ( const uint_T * ) forEachMdlRefDimsArray : (
NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0 ) ; if ( !
rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( iu2zxy1bg0 -> DataMapInfo .
mmi . InstanceMap . fullPath , "LKARefMdl/Lane Keeping Controller" , 1 ,
"assisted_steer" ) ; } if ( rtwLoggingOverride ( signalDescriptor ,
slioCatalogue ) ) { if ( iu2zxy1bg0 -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) { loggingInterval = rtliGetLoggingInterval ( iu2zxy1bg0 -> _mdlRefSfcnS ->
mdlInfo -> rtwLogInfo ) ; } else { loggingInterval = sdiGetLoggingIntervals (
iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = ""
; } accessor = rtwGetAccessor ( signalDescriptor , loggingInterval ) ;
rtwAddR2Client ( accessor , signalDescriptor , slioCatalogue , datasetName ,
1 ) ; localDW -> d0ox53zfja . SlioLTF = accessor ; } } } } if ( (
ssGetSimMode ( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
iu2zxy1bg0 -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void * slioCatalogue =
rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) :
sdiGetSlioCatalogue ( iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath ) ; if ( ! slioCatalogue || ! rtwDisableStreamingToRepository (
slioCatalogue ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "departure_detected" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "departure_detected" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"LKARefMdl/Detect Lane Departure" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiDims forEachMdlRefDims ; int_T forEachMdlRefDimsArray
[ 32 ] ; sdiLabelU sigName = sdiGetLabelFromChars ( "departure_detected" ) ;
sdiAsyncQueueHandle hForEachParent = ( NULL ) ; sdiAsyncRepoDataTypeHandle
hDT = sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_BOOLEAN ) ; {
sdiComplexity sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1
; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; if (
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDims . nDims = 0 ; } else
{ forEachMdlRefDims . nDims = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> dpmuujlupa . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , iu2zxy1bg0 -> DataMapInfo
. mmi . InstanceMap . fullPath , "2ea9d914-06c3-464f-8f86-bc28858c783c" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if (
localDW -> dpmuujlupa . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> dpmuujlupa . AQHandles , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) ) ;
sdiSetRunStartTime ( localDW -> dpmuujlupa . AQHandles , rtmGetTaskTime (
iu2zxy1bg0 , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
dpmuujlupa . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> dpmuujlupa . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> dpmuujlupa . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 8 ,
"departure_detected" , "zoh" , 0 , ( unsigned int * ) sigDimsArray , 1 ,
"logical" , "" , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) , treeVector ) ; }
signalDescriptor = rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 ,
"departure_detected" , "" , iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath , "LKARefMdl/Detect Lane Departure" , 1 , 0 , slioCatalogue ,
forEachMdlRefDimsArraySize ? ( const uint_T * ) forEachMdlRefDimsArray : (
NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0 ) ; if ( !
rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( iu2zxy1bg0 -> DataMapInfo .
mmi . InstanceMap . fullPath , "LKARefMdl/Detect Lane Departure" , 1 ,
"departure_detected" ) ; } if ( rtwLoggingOverride ( signalDescriptor ,
slioCatalogue ) ) { if ( iu2zxy1bg0 -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) { loggingInterval = rtliGetLoggingInterval ( iu2zxy1bg0 -> _mdlRefSfcnS ->
mdlInfo -> rtwLogInfo ) ; } else { loggingInterval = sdiGetLoggingIntervals (
iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = ""
; } accessor = rtwGetAccessor ( signalDescriptor , loggingInterval ) ;
rtwAddR2Client ( accessor , signalDescriptor , slioCatalogue , datasetName ,
1 ) ; localDW -> dpmuujlupa . SlioLTF = accessor ; } } } } if ( (
ssGetSimMode ( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
iu2zxy1bg0 -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void * slioCatalogue =
rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) :
sdiGetSlioCatalogue ( iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath ) ; if ( ! slioCatalogue || ! rtwDisableStreamingToRepository (
slioCatalogue ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "right_assist_offset" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "right_assist_offset" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"LKARefMdl/Detect Lane Departure/Gain" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiDims forEachMdlRefDims ; int_T forEachMdlRefDimsArray
[ 32 ] ; sdiLabelU sigName = sdiGetLabelFromChars ( "right_assist_offset" ) ;
sdiAsyncQueueHandle hForEachParent = ( NULL ) ; sdiAsyncRepoDataTypeHandle
hDT = sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_SINGLE ) ; {
sdiComplexity sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1
; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; if (
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDims . nDims = 0 ; } else
{ forEachMdlRefDims . nDims = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> igap1wnipb . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , iu2zxy1bg0 -> DataMapInfo
. mmi . InstanceMap . fullPath , "7e9bd9c4-c2eb-402c-a901-3ce40104972e" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if (
localDW -> igap1wnipb . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> igap1wnipb . AQHandles , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) ) ;
sdiSetRunStartTime ( localDW -> igap1wnipb . AQHandles , rtmGetTaskTime (
iu2zxy1bg0 , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
igap1wnipb . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> igap1wnipb . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> igap1wnipb . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 1 ,
"right_assist_offset" , "zoh" , 0 , ( unsigned int * ) sigDimsArray , 1 ,
"single" , "" , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) , treeVector ) ; }
signalDescriptor = rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 ,
"right_assist_offset" , "" , iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath , "LKARefMdl/Detect Lane Departure/Gain" , 1 , 0 , slioCatalogue ,
forEachMdlRefDimsArraySize ? ( const uint_T * ) forEachMdlRefDimsArray : (
NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0 ) ; if ( !
rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( iu2zxy1bg0 -> DataMapInfo .
mmi . InstanceMap . fullPath , "LKARefMdl/Detect Lane Departure/Gain" , 1 ,
"right_assist_offset" ) ; } if ( rtwLoggingOverride ( signalDescriptor ,
slioCatalogue ) ) { if ( iu2zxy1bg0 -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) { loggingInterval = rtliGetLoggingInterval ( iu2zxy1bg0 -> _mdlRefSfcnS ->
mdlInfo -> rtwLogInfo ) ; } else { loggingInterval = sdiGetLoggingIntervals (
iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = ""
; } accessor = rtwGetAccessor ( signalDescriptor , loggingInterval ) ;
rtwAddR2Client ( accessor , signalDescriptor , slioCatalogue , datasetName ,
1 ) ; localDW -> igap1wnipb . SlioLTF = accessor ; } } } } if ( (
ssGetSimMode ( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
iu2zxy1bg0 -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void * slioCatalogue =
rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) :
sdiGetSlioCatalogue ( iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath ) ; if ( ! slioCatalogue || ! rtwDisableStreamingToRepository (
slioCatalogue ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "right_lateral_offset" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "right_lateral_offset" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"LKARefMdl/Detect Lane Departure/In Bus Element1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiDims forEachMdlRefDims ; int_T forEachMdlRefDimsArray
[ 32 ] ; sdiLabelU sigName = sdiGetLabelFromChars ( "right_lateral_offset" )
; sdiAsyncQueueHandle hForEachParent = ( NULL ) ; sdiAsyncRepoDataTypeHandle
hDT = sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_SINGLE ) ; {
sdiComplexity sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1
; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; if (
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDims . nDims = 0 ; } else
{ forEachMdlRefDims . nDims = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> dfhhcydsof . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , iu2zxy1bg0 -> DataMapInfo
. mmi . InstanceMap . fullPath , "905c52a3-0a49-453b-808e-0053ec39816e" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "m" ) ; if (
localDW -> dfhhcydsof . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> dfhhcydsof . AQHandles , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) ) ;
sdiSetRunStartTime ( localDW -> dfhhcydsof . AQHandles , rtmGetTaskTime (
iu2zxy1bg0 , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
dfhhcydsof . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> dfhhcydsof . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> dfhhcydsof . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 1 ,
"right_lateral_offset" , "zoh" , 0 , ( unsigned int * ) sigDimsArray , 1 ,
"single" , "m" , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) , treeVector ) ; }
signalDescriptor = rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 ,
"right_lateral_offset" , "" , iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath , "LKARefMdl/Detect Lane Departure/In Bus Element1" , 1 , 0 ,
slioCatalogue , forEachMdlRefDimsArraySize ? ( const uint_T * )
forEachMdlRefDimsArray : ( NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0
) ; if ( ! rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath ,
"LKARefMdl/Detect Lane Departure/In Bus Element1" , 1 ,
"right_lateral_offset" ) ; } if ( rtwLoggingOverride ( signalDescriptor ,
slioCatalogue ) ) { if ( iu2zxy1bg0 -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) { loggingInterval = rtliGetLoggingInterval ( iu2zxy1bg0 -> _mdlRefSfcnS ->
mdlInfo -> rtwLogInfo ) ; } else { loggingInterval = sdiGetLoggingIntervals (
iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = ""
; } accessor = rtwGetAccessor ( signalDescriptor , loggingInterval ) ;
rtwAddR2Client ( accessor , signalDescriptor , slioCatalogue , datasetName ,
1 ) ; localDW -> dfhhcydsof . SlioLTF = accessor ; } } } } if ( (
ssGetSimMode ( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
iu2zxy1bg0 -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void * slioCatalogue =
rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) :
sdiGetSlioCatalogue ( iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath ) ; if ( ! slioCatalogue || ! rtwDisableStreamingToRepository (
slioCatalogue ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "left_lateral_offset" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "left_lateral_offset" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"LKARefMdl/Detect Lane Departure/In Bus Element" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiDims forEachMdlRefDims ; int_T forEachMdlRefDimsArray
[ 32 ] ; sdiLabelU sigName = sdiGetLabelFromChars ( "left_lateral_offset" ) ;
sdiAsyncQueueHandle hForEachParent = ( NULL ) ; sdiAsyncRepoDataTypeHandle
hDT = sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_SINGLE ) ; {
sdiComplexity sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1
; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; if (
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDims . nDims = 0 ; } else
{ forEachMdlRefDims . nDims = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> jtkkjdqprf . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , iu2zxy1bg0 -> DataMapInfo
. mmi . InstanceMap . fullPath , "4fb9e2e0-a996-4274-a83a-31d88686304d" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "m" ) ; if (
localDW -> jtkkjdqprf . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> jtkkjdqprf . AQHandles , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) ) ;
sdiSetRunStartTime ( localDW -> jtkkjdqprf . AQHandles , rtmGetTaskTime (
iu2zxy1bg0 , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
jtkkjdqprf . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> jtkkjdqprf . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> jtkkjdqprf . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 1 ,
"left_lateral_offset" , "zoh" , 0 , ( unsigned int * ) sigDimsArray , 1 ,
"single" , "m" , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) , treeVector ) ; }
signalDescriptor = rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 ,
"left_lateral_offset" , "" , iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath , "LKARefMdl/Detect Lane Departure/In Bus Element" , 1 , 0 ,
slioCatalogue , forEachMdlRefDimsArraySize ? ( const uint_T * )
forEachMdlRefDimsArray : ( NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0
) ; if ( ! rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath ,
"LKARefMdl/Detect Lane Departure/In Bus Element" , 1 , "left_lateral_offset"
) ; } if ( rtwLoggingOverride ( signalDescriptor , slioCatalogue ) ) { if (
iu2zxy1bg0 -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo ) { loggingInterval =
rtliGetLoggingInterval ( iu2zxy1bg0 -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) ; } else { loggingInterval = sdiGetLoggingIntervals ( iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = "" ; } accessor
= rtwGetAccessor ( signalDescriptor , loggingInterval ) ; rtwAddR2Client (
accessor , signalDescriptor , slioCatalogue , datasetName , 1 ) ; localDW ->
jtkkjdqprf . SlioLTF = accessor ; } } } } if ( ( ssGetSimMode ( iu2zxy1bg0 ->
_mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( iu2zxy1bg0 -> _mdlRefSfcnS )
-> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void *
slioCatalogue = rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr (
rt_slioCatalogue ( ) ) : sdiGetSlioCatalogue ( iu2zxy1bg0 -> DataMapInfo .
mmi . InstanceMap . fullPath ) ; if ( ! slioCatalogue || !
rtwDisableStreamingToRepository ( slioCatalogue ) ) { { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "relative_yaw_angle"
) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "relative_yaw_angle" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "LKARefMdl/Estimate Lane Center" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiDims forEachMdlRefDims ;
int_T forEachMdlRefDimsArray [ 32 ] ; sdiLabelU sigName =
sdiGetLabelFromChars ( "relative_yaw_angle" ) ; sdiAsyncQueueHandle
hForEachParent = ( NULL ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_SINGLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 2 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; if (
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDims . nDims = 0 ; } else
{ forEachMdlRefDims . nDims = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> fgtuicwhwc . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , iu2zxy1bg0 -> DataMapInfo
. mmi . InstanceMap . fullPath , "86a47e71-eb35-4f25-8e34-9e8d66ad313c" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if (
localDW -> fgtuicwhwc . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> fgtuicwhwc . AQHandles , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) ) ;
sdiSetRunStartTime ( localDW -> fgtuicwhwc . AQHandles , rtmGetTaskTime (
iu2zxy1bg0 , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
fgtuicwhwc . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> fgtuicwhwc . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> fgtuicwhwc . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 1 ,
"relative_yaw_angle" , "zoh" , 0 , ( unsigned int * ) sigDimsArray , 1 ,
"single" , "" , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) , treeVector ) ; }
signalDescriptor = rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 ,
"relative_yaw_angle" , "" , iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath , "LKARefMdl/Estimate Lane Center" , 3 , 0 , slioCatalogue ,
forEachMdlRefDimsArraySize ? ( const uint_T * ) forEachMdlRefDimsArray : (
NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0 ) ; if ( !
rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( iu2zxy1bg0 -> DataMapInfo .
mmi . InstanceMap . fullPath , "LKARefMdl/Estimate Lane Center" , 3 ,
"relative_yaw_angle" ) ; } if ( rtwLoggingOverride ( signalDescriptor ,
slioCatalogue ) ) { if ( iu2zxy1bg0 -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) { loggingInterval = rtliGetLoggingInterval ( iu2zxy1bg0 -> _mdlRefSfcnS ->
mdlInfo -> rtwLogInfo ) ; } else { loggingInterval = sdiGetLoggingIntervals (
iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = ""
; } accessor = rtwGetAccessor ( signalDescriptor , loggingInterval ) ;
rtwAddR2Client ( accessor , signalDescriptor , slioCatalogue , datasetName ,
1 ) ; localDW -> fgtuicwhwc . SlioLTF = accessor ; } } } } if ( (
ssGetSimMode ( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
iu2zxy1bg0 -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void * slioCatalogue =
rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) :
sdiGetSlioCatalogue ( iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath ) ; if ( ! slioCatalogue || ! rtwDisableStreamingToRepository (
slioCatalogue ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "lateral_deviation" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "lateral_deviation" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"LKARefMdl/Estimate Lane Center" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiDims forEachMdlRefDims ; int_T forEachMdlRefDimsArray
[ 32 ] ; sdiLabelU sigName = sdiGetLabelFromChars ( "lateral_deviation" ) ;
sdiAsyncQueueHandle hForEachParent = ( NULL ) ; sdiAsyncRepoDataTypeHandle
hDT = sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_SINGLE ) ; {
sdiComplexity sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1
; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; if (
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDims . nDims = 0 ; } else
{ forEachMdlRefDims . nDims = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> kpzmvqvw4f . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , iu2zxy1bg0 -> DataMapInfo
. mmi . InstanceMap . fullPath , "c4c0fa1d-b210-4fd5-8d98-c51bcacb834f" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if (
localDW -> kpzmvqvw4f . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> kpzmvqvw4f . AQHandles , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) ) ;
sdiSetRunStartTime ( localDW -> kpzmvqvw4f . AQHandles , rtmGetTaskTime (
iu2zxy1bg0 , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
kpzmvqvw4f . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> kpzmvqvw4f . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> kpzmvqvw4f . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 1 ,
"lateral_deviation" , "zoh" , 0 , ( unsigned int * ) sigDimsArray , 1 ,
"single" , "" , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) , treeVector ) ; }
signalDescriptor = rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 ,
"lateral_deviation" , "" , iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath , "LKARefMdl/Estimate Lane Center" , 2 , 0 , slioCatalogue ,
forEachMdlRefDimsArraySize ? ( const uint_T * ) forEachMdlRefDimsArray : (
NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0 ) ; if ( !
rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( iu2zxy1bg0 -> DataMapInfo .
mmi . InstanceMap . fullPath , "LKARefMdl/Estimate Lane Center" , 2 ,
"lateral_deviation" ) ; } if ( rtwLoggingOverride ( signalDescriptor ,
slioCatalogue ) ) { if ( iu2zxy1bg0 -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) { loggingInterval = rtliGetLoggingInterval ( iu2zxy1bg0 -> _mdlRefSfcnS ->
mdlInfo -> rtwLogInfo ) ; } else { loggingInterval = sdiGetLoggingIntervals (
iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = ""
; } accessor = rtwGetAccessor ( signalDescriptor , loggingInterval ) ;
rtwAddR2Client ( accessor , signalDescriptor , slioCatalogue , datasetName ,
1 ) ; localDW -> kpzmvqvw4f . SlioLTF = accessor ; } } } } if ( (
ssGetSimMode ( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
iu2zxy1bg0 -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void * slioCatalogue =
rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) :
sdiGetSlioCatalogue ( iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath ) ; if ( ! slioCatalogue || ! rtwDisableStreamingToRepository (
slioCatalogue ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "left_assist_offset" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "left_assist_offset" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"LKARefMdl/Detect Lane Departure/Lane Assist Offset" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiDims forEachMdlRefDims ; int_T forEachMdlRefDimsArray
[ 32 ] ; sdiLabelU sigName = sdiGetLabelFromChars ( "left_assist_offset" ) ;
sdiAsyncQueueHandle hForEachParent = ( NULL ) ; sdiAsyncRepoDataTypeHandle
hDT = sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_SINGLE ) ; {
sdiComplexity sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1
; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; if (
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDims . nDims = 0 ; } else
{ forEachMdlRefDims . nDims = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> ln45a3lme1 . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , iu2zxy1bg0 -> DataMapInfo
. mmi . InstanceMap . fullPath , "20745e8f-002e-4289-b294-a4b1a269b68c" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "m" ) ; if (
localDW -> ln45a3lme1 . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> ln45a3lme1 . AQHandles , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) ) ;
sdiSetRunStartTime ( localDW -> ln45a3lme1 . AQHandles , rtmGetTaskTime (
iu2zxy1bg0 , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
ln45a3lme1 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> ln45a3lme1 . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> ln45a3lme1 . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( iu2zxy1bg0
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 1 ,
"left_assist_offset" , "zoh" , 0 , ( unsigned int * ) sigDimsArray , 1 ,
"single" , "m" , "0.1" , 0.1 , rtmGetTFinal ( iu2zxy1bg0 ) , treeVector ) ; }
signalDescriptor = rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 ,
"left_assist_offset" , "" , iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap .
fullPath , "LKARefMdl/Detect Lane Departure/Lane Assist Offset" , 1 , 0 ,
slioCatalogue , forEachMdlRefDimsArraySize ? ( const uint_T * )
forEachMdlRefDimsArray : ( NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0
) ; if ( ! rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( iu2zxy1bg0 ->
DataMapInfo . mmi . InstanceMap . fullPath ,
"LKARefMdl/Detect Lane Departure/Lane Assist Offset" , 1 ,
"left_assist_offset" ) ; } if ( rtwLoggingOverride ( signalDescriptor ,
slioCatalogue ) ) { if ( iu2zxy1bg0 -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) { loggingInterval = rtliGetLoggingInterval ( iu2zxy1bg0 -> _mdlRefSfcnS ->
mdlInfo -> rtwLogInfo ) ; } else { loggingInterval = sdiGetLoggingIntervals (
iu2zxy1bg0 -> DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = ""
; } accessor = rtwGetAccessor ( signalDescriptor , loggingInterval ) ;
rtwAddR2Client ( accessor , signalDescriptor , slioCatalogue , datasetName ,
1 ) ; localDW -> ln45a3lme1 . SlioLTF = accessor ; } } } } } void LKARefMdl (
a0qef2fbcm * const iu2zxy1bg0 , const boolean_T * dl2h23j0yb , const real32_T
* ggzreh1sbs , const real32_T * gy14yybqge , const real32_T * j5ofsry4is ,
const LaneSensor * a0xrpmr0lc , boolean_T * gsarxirkom , real32_T *
h0jeecywei , llf3xg3ir0 * localB , j4ytv2gj5l * localDW ) { real32_T
cjpq4sbzb4 ; real32_T haabair13z ; real32_T ezxxoe0g3z ; real32_T bth5edrrpr
; real32_T o4ugtpgvyj ; real32_T dtl4ybo5ws ; boolean_T nadxvhdukv ; real_T t
[ 31 ] ; int32_T i ; real32_T a ; real32_T Af [ 16 ] ; real32_T h ; real32_T
Ai [ 16 ] ; int32_T Coef ; int8_T I [ 16 ] ; real32_T b [ 16 ] ; static const
int8_T d [ 6 ] = { 1 , 0 , 0 , 1 , 0 , - 1 } ; real32_T xk [ 5 ] ; real32_T
Bu [ 155 ] ; real32_T Bv [ 310 ] ; real32_T Dv [ 124 ] ; real32_T Dvm [ 124 ]
; real32_T Cm [ 310 ] ; real32_T Kinv [ 4 ] ; real32_T L [ 10 ] ; real32_T
y_innov [ 2 ] ; real32_T b_p [ 10 ] ; real32_T Qk [ 25 ] ; real32_T Rk [ 4 ]
; real32_T Nk [ 10 ] ; real32_T b_Mlim [ 126 ] ; real32_T b_voff ; real32_T
b_yoff [ 2 ] ; real32_T b_xoff [ 5 ] ; real32_T rseq [ 60 ] ; real32_T vseq [
62 ] ; real32_T v [ 2 ] ; real32_T b_A [ 25 ] ; real32_T b_C [ 10 ] ; static
const real32_T d_p [ 25 ] = { 0.571899F , 0.0870433748F , 0.0803755671F ,
0.00528917322F , 0.0F , - 0.64695704F , 0.522808373F , 0.0181439444F ,
0.0747095719F , 0.0F , 0.0F , 0.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.39F
, 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F } ; static const real32_T e
[ 30 ] = { 1.25096309F , 1.31256521F , 0.113198221F , 0.0702190548F , 0.0F ,
0.0F , 0.0F , - 0.000695F , - 0.001F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.1F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F } ; static const int8_T f [ 10 ] = { 0 , 0 ,
0 , 0 , 2 , 0 , 0 , 10 , 0 , 1 } ; static const int8_T g [ 12 ] = { 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 } ; static const real32_T h_p [ 2 ] = {
1.0F , 0.01F } ; static const real32_T i_p [ 2 ] = { 0.5F , 0.1F } ; static
const real32_T j [ 126 ] = { 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 3.68934859E+19F , 1.84467423E+20F ,
3.68934859E+19F , 1.84467423E+20F , 0.5F , 0.5F , 0.5F , 0.5F , 0.5F , 0.5F }
; static const real32_T k [ 126 ] = { 1.0F , 2.0F , 3.0F , 4.0F , 5.0F , 6.0F
, 7.0F , 8.0F , 9.0F , 10.0F , 11.0F , 12.0F , 13.0F , 14.0F , 15.0F , 16.0F
, 17.0F , 18.0F , 19.0F , 20.0F , 21.0F , 22.0F , 23.0F , 24.0F , 25.0F ,
26.0F , 27.0F , 28.0F , 29.0F , 30.0F , 31.0F , 32.0F , 33.0F , 34.0F , 35.0F
, 36.0F , 37.0F , 38.0F , 39.0F , 40.0F , 41.0F , 42.0F , 43.0F , 44.0F ,
45.0F , 46.0F , 47.0F , 48.0F , 49.0F , 50.0F , 51.0F , 52.0F , 53.0F , 54.0F
, 55.0F , 56.0F , 57.0F , 58.0F , 59.0F , 60.0F , 61.0F , 62.0F , 63.0F ,
64.0F , 65.0F , 66.0F , 67.0F , 68.0F , 69.0F , 70.0F , 71.0F , 72.0F , 73.0F
, 74.0F , 75.0F , 76.0F , 77.0F , 78.0F , 79.0F , 80.0F , 81.0F , 82.0F ,
83.0F , 84.0F , 85.0F , 86.0F , 87.0F , 88.0F , 89.0F , 90.0F , 91.0F , 92.0F
, 93.0F , 94.0F , 95.0F , 96.0F , 97.0F , 98.0F , 99.0F , 100.0F , 101.0F ,
102.0F , 103.0F , 104.0F , 105.0F , 106.0F , 107.0F , 108.0F , 109.0F ,
110.0F , 111.0F , 112.0F , 113.0F , 114.0F , 115.0F , 116.0F , 117.0F ,
118.0F , 119.0F , 120.0F , 121.0F , 122.0F , 123.0F , 151.0F , 152.0F ,
153.0F } ; static const real32_T r [ 630 ] = { - 0.160751134F , -
0.0528917313F , - 0.270547062F , - 0.148170188F , - 0.358720332F , -
0.233679429F , - 0.44132787F , - 0.293433934F , - 0.525525212F , -
0.328465611F , - 0.613440454F , - 0.345583826F , - 0.704860926F , -
0.351876289F , - 0.798797488F , - 0.352682471F , - 0.894243062F , -
0.351329267F , - 0.990446568F , - 0.349561423F , - 1.08694363F , -
0.34810698F , - 1.18349278F , - 0.347142935F , - 1.27999461F , - 0.346604317F
, - 1.3764261F , - 0.346357256F , - 1.47279751F , - 0.346278161F , -
1.56912804F , - 0.346279353F , - 1.66543519F , - 0.346308768F , - 1.76173127F
, - 0.346340537F , - 1.85802352F , - 0.346364886F , - 1.95431566F , -
0.346380204F , - 2.05060887F , - 0.34638837F , - 2.14690328F , - 0.346391857F
, - 2.24319863F , - 0.346392751F , - 2.33949471F , - 0.346392512F , -
2.43579125F , - 0.346391916F , - 2.5320878F , - 0.34639138F , - 2.62838459F ,
- 0.346390963F , - 2.72468114F , - 0.346390724F , - 2.82097793F , -
0.346390605F , - 2.91727448F , - 0.346390545F , 0.160751134F , 0.0528917313F
, 0.270547062F , 0.148170188F , 0.358720332F , 0.233679429F , 0.44132787F ,
0.293433934F , 0.525525212F , 0.328465611F , 0.613440454F , 0.345583826F ,
0.704860926F , 0.351876289F , 0.798797488F , 0.352682471F , 0.894243062F ,
0.351329267F , 0.990446568F , 0.349561423F , 1.08694363F , 0.34810698F ,
1.18349278F , 0.347142935F , 1.27999461F , 0.346604317F , 1.3764261F ,
0.346357256F , 1.47279751F , 0.346278161F , 1.56912804F , 0.346279353F ,
1.66543519F , 0.346308768F , 1.76173127F , 0.346340537F , 1.85802352F ,
0.346364886F , 1.95431566F , 0.346380204F , 2.05060887F , 0.34638837F ,
2.14690328F , 0.346391857F , 2.24319863F , 0.346392751F , 2.33949471F ,
0.346392512F , 2.43579125F , 0.346391916F , 2.5320878F , 0.34639138F ,
2.62838459F , 0.346390963F , 2.72468114F , 0.346390724F , 2.82097793F ,
0.346390605F , 2.91727448F , 0.346390545F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , - 0.0362878889F , - 0.747095704F , - 0.158953026F , - 1.10346496F ,
- 0.359742761F , - 1.22813666F , - 0.615365565F , - 1.23799527F , -
0.903256416F , - 1.2044909F , - 1.20698869F , - 1.16431057F , - 1.51659775F ,
- 1.13222909F , - 1.82701147F , - 1.1113857F , - 2.13621807F , - 1.09996712F
, - 2.44381714F , - 1.09487283F , - 2.75008559F , - 1.09335315F , -
3.05546856F , - 1.09349966F , - 3.36035466F , - 1.0941999F , - 3.66501188F ,
- 1.09491444F , - 3.96959472F , - 1.0954479F , - 4.27417755F , - 1.09577799F
, - 4.57878733F , - 1.09594977F , - 4.88342571F , - 1.09602058F , -
5.18808603F , - 1.09603703F , - 5.49276114F , - 1.09602988F , - 5.79744339F ,
- 1.09601617F , - 6.10212898F , - 1.09600377F , - 6.40681505F , - 1.09599507F
, - 6.71150112F , - 1.09598982F , - 7.01618719F , - 1.09598732F , -
7.32087231F , - 1.09598637F , - 7.62555695F , - 1.09598625F , - 7.93024158F ,
- 1.09598649F , - 8.23492622F , - 1.09598672F , - 8.53961F , - 1.09598684F ,
0.0362878889F , 0.747095704F , 0.158953026F , 1.10346496F , 0.359742761F ,
1.22813666F , 0.615365565F , 1.23799527F , 0.903256416F , 1.2044909F ,
1.20698869F , 1.16431057F , 1.51659775F , 1.13222909F , 1.82701147F ,
1.1113857F , 2.13621807F , 1.09996712F , 2.44381714F , 1.09487283F ,
2.75008559F , 1.09335315F , 3.05546856F , 1.09349966F , 3.36035466F ,
1.0941999F , 3.66501188F , 1.09491444F , 3.96959472F , 1.0954479F ,
4.27417755F , 1.09577799F , 4.57878733F , 1.09594977F , 4.88342571F ,
1.09602058F , 5.18808603F , 1.09603703F , 5.49276114F , 1.09602988F ,
5.79744339F , 1.09601617F , 6.10212898F , 1.09600377F , 6.40681505F ,
1.09599507F , 6.71150112F , 1.09598982F , 7.01618719F , 1.09598732F ,
7.32087231F , 1.09598637F , 7.62555695F , 1.09598625F , 7.93024158F ,
1.09598649F , 8.23492622F , 1.09598672F , 8.53961F , 1.09598684F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F
, - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , -
0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F
, - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , -
2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F
, - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , -
0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F , - 2.0F , - 0.0F
, - 2.0F , - 0.0F , - 2.0F , - 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F
, 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F
, 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F
, 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F
, 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F
, 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 2.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 2.78F , - 10.0F , - 5.56F , - 10.0F ,
- 8.34F , - 10.0F , - 11.12F , - 10.0F , - 13.9F , - 10.0F , - 16.68F , -
10.0F , - 19.46F , - 10.0F , - 22.24F , - 10.0F , - 25.02F , - 10.0F , -
27.8F , - 10.0F , - 30.58F , - 10.0F , - 33.36F , - 10.0F , - 36.14F , -
10.0F , - 38.92F , - 10.0F , - 41.7F , - 10.0F , - 44.48F , - 10.0F , -
47.26F , - 10.0F , - 50.04F , - 10.0F , - 52.82F , - 10.0F , - 55.6F , -
10.0F , - 58.38F , - 10.0F , - 61.16F , - 10.0F , - 63.94F , - 10.0F , -
66.72F , - 10.0F , - 69.5F , - 10.0F , - 72.28F , - 10.0F , - 75.06F , -
10.0F , - 77.84F , - 10.0F , - 80.62F , - 10.0F , - 83.4F , - 10.0F , 2.78F ,
10.0F , 5.56F , 10.0F , 8.34F , 10.0F , 11.12F , 10.0F , 13.9F , 10.0F ,
16.68F , 10.0F , 19.46F , 10.0F , 22.24F , 10.0F , 25.02F , 10.0F , 27.8F ,
10.0F , 30.58F , 10.0F , 33.36F , 10.0F , 36.14F , 10.0F , 38.92F , 10.0F ,
41.7F , 10.0F , 44.48F , 10.0F , 47.26F , 10.0F , 50.04F , 10.0F , 52.82F ,
10.0F , 55.6F , 10.0F , 58.38F , 10.0F , 61.16F , 10.0F , 63.94F , 10.0F ,
66.72F , 10.0F , 69.5F , 10.0F , 72.28F , 10.0F , 75.06F , 10.0F , 77.84F ,
10.0F , 80.62F , 10.0F , 83.4F , 10.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F
, - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , -
0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F
, - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , -
1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F
, - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , -
0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F , - 1.0F , - 0.0F
, - 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F ,
1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F ,
0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F ,
1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F ,
0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F ,
1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F } ; static const real32_T s [ 126 ] = { - 0.226396441F , -
0.702190518F , - 0.896725774F , - 2.45115852F , - 2.06062078F , - 4.78707409F
, - 3.79357576F , - 7.39359856F , - 6.1606F , - 10.0878134F , - 9.20603752F ,
- 12.7818756F , - 12.9553299F , - 15.4446115F , - 17.420578F , - 18.0731106F
, - 22.6059837F , - 20.6752605F , - 28.5118504F , - 23.2607288F , -
35.1370201F , - 25.8373013F , - 42.4801064F , - 28.4100571F , - 50.54002F , -
30.9818F , - 59.3160439F , - 33.5537872F , - 68.8077927F , - 36.1264076F , -
79.0150909F , - 38.6996231F , - 89.9378891F , - 41.2732773F , - 101.576187F ,
- 43.8471947F , - 113.930023F , - 46.4212418F , - 126.999405F , - 48.9953423F
, - 140.784363F , - 51.5694504F , - 155.284912F , - 54.1435547F , -
170.501038F , - 56.7176437F , - 186.43277F , - 59.2917252F , - 203.080078F ,
- 61.8658F , - 220.443F , - 64.4398651F , - 238.521484F , - 67.0139313F , -
257.315582F , - 69.588F , - 276.825256F , - 72.1620636F , - 297.050537F , -
74.7361298F , 0.226396441F , 0.702190518F , 0.896725774F , 2.45115852F ,
2.06062078F , 4.78707409F , 3.79357576F , 7.39359856F , 6.1606F , 10.0878134F
, 9.20603752F , 12.7818756F , 12.9553299F , 15.4446115F , 17.420578F ,
18.0731106F , 22.6059837F , 20.6752605F , 28.5118504F , 23.2607288F ,
35.1370201F , 25.8373013F , 42.4801064F , 28.4100571F , 50.54002F , 30.9818F
, 59.3160439F , 33.5537872F , 68.8077927F , 36.1264076F , 79.0150909F ,
38.6996231F , 89.9378891F , 41.2732773F , 101.576187F , 43.8471947F ,
113.930023F , 46.4212418F , 126.999405F , 48.9953423F , 140.784363F ,
51.5694504F , 155.284912F , 54.1435547F , 170.501038F , 56.7176437F ,
186.43277F , 59.2917252F , 203.080078F , 61.8658F , 220.443F , 64.4398651F ,
238.521484F , 67.0139313F , 257.315582F , 69.588F , 276.825256F , 72.1620636F
, 297.050537F , 74.7361298F , - 1.0F , - 1.0F , - 1.0F , 1.0F , 1.0F , 1.0F }
; static const real32_T t_p [ 7812 ] = { 0.00139F , 0.01F , 0.00417F , 0.01F
, 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F ,
0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F ,
0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F , 0.03753F , 0.01F ,
0.04031F , 0.01F , 0.04309F , 0.01F , 0.04587F , 0.01F , 0.04865F , 0.01F ,
0.05143F , 0.01F , 0.05421F , 0.01F , 0.05699F , 0.01F , 0.05977F , 0.01F ,
0.06255F , 0.01F , 0.06533F , 0.01F , 0.06811F , 0.01F , 0.07089F , 0.01F ,
0.07367F , 0.01F , 0.07645F , 0.01F , 0.07923F , 0.01F , 0.08201F , 0.01F , -
0.00139F , - 0.01F , - 0.00417F , - 0.01F , - 0.00695F , - 0.01F , - 0.00973F
, - 0.01F , - 0.01251F , - 0.01F , - 0.01529F , - 0.01F , - 0.01807F , -
0.01F , - 0.02085F , - 0.01F , - 0.02363F , - 0.01F , - 0.02641F , - 0.01F ,
- 0.02919F , - 0.01F , - 0.03197F , - 0.01F , - 0.03475F , - 0.01F , -
0.03753F , - 0.01F , - 0.04031F , - 0.01F , - 0.04309F , - 0.01F , - 0.04587F
, - 0.01F , - 0.04865F , - 0.01F , - 0.05143F , - 0.01F , - 0.05421F , -
0.01F , - 0.05699F , - 0.01F , - 0.05977F , - 0.01F , - 0.06255F , - 0.01F ,
- 0.06533F , - 0.01F , - 0.06811F , - 0.01F , - 0.07089F , - 0.01F , -
0.07367F , - 0.01F , - 0.07645F , - 0.01F , - 0.07923F , - 0.01F , - 0.08201F
, - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , -
0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F ,
0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F ,
0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F ,
0.01F , 0.03475F , 0.01F , 0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F ,
0.01F , 0.04587F , 0.01F , 0.04865F , 0.01F , 0.05143F , 0.01F , 0.05421F ,
0.01F , 0.05699F , 0.01F , 0.05977F , 0.01F , 0.06255F , 0.01F , 0.06533F ,
0.01F , 0.06811F , 0.01F , 0.07089F , 0.01F , 0.07367F , 0.01F , 0.07645F ,
0.01F , 0.07923F , 0.01F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F ,
- 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F
, - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , - 0.01F , -
0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F , - 0.01F , - 0.03197F
, - 0.01F , - 0.03475F , - 0.01F , - 0.03753F , - 0.01F , - 0.04031F , -
0.01F , - 0.04309F , - 0.01F , - 0.04587F , - 0.01F , - 0.04865F , - 0.01F ,
- 0.05143F , - 0.01F , - 0.05421F , - 0.01F , - 0.05699F , - 0.01F , -
0.05977F , - 0.01F , - 0.06255F , - 0.01F , - 0.06533F , - 0.01F , - 0.06811F
, - 0.01F , - 0.07089F , - 0.01F , - 0.07367F , - 0.01F , - 0.07645F , -
0.01F , - 0.07923F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F ,
0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F ,
0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F ,
0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F , 0.03753F , 0.01F ,
0.04031F , 0.01F , 0.04309F , 0.01F , 0.04587F , 0.01F , 0.04865F , 0.01F ,
0.05143F , 0.01F , 0.05421F , 0.01F , 0.05699F , 0.01F , 0.05977F , 0.01F ,
0.06255F , 0.01F , 0.06533F , 0.01F , 0.06811F , 0.01F , 0.07089F , 0.01F ,
0.07367F , 0.01F , 0.07645F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F
, - 0.01F , - 0.00417F , - 0.01F , - 0.00695F , - 0.01F , - 0.00973F , -
0.01F , - 0.01251F , - 0.01F , - 0.01529F , - 0.01F , - 0.01807F , - 0.01F ,
- 0.02085F , - 0.01F , - 0.02363F , - 0.01F , - 0.02641F , - 0.01F , -
0.02919F , - 0.01F , - 0.03197F , - 0.01F , - 0.03475F , - 0.01F , - 0.03753F
, - 0.01F , - 0.04031F , - 0.01F , - 0.04309F , - 0.01F , - 0.04587F , -
0.01F , - 0.04865F , - 0.01F , - 0.05143F , - 0.01F , - 0.05421F , - 0.01F ,
- 0.05699F , - 0.01F , - 0.05977F , - 0.01F , - 0.06255F , - 0.01F , -
0.06533F , - 0.01F , - 0.06811F , - 0.01F , - 0.07089F , - 0.01F , - 0.07367F
, - 0.01F , - 0.07645F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F
, 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F ,
0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F ,
0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F ,
0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F , 0.01F , 0.04587F , 0.01F ,
0.04865F , 0.01F , 0.05143F , 0.01F , 0.05421F , 0.01F , 0.05699F , 0.01F ,
0.05977F , 0.01F , 0.06255F , 0.01F , 0.06533F , 0.01F , 0.06811F , 0.01F ,
0.07089F , 0.01F , 0.07367F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , - 0.00695F , - 0.01F , -
0.00973F , - 0.01F , - 0.01251F , - 0.01F , - 0.01529F , - 0.01F , - 0.01807F
, - 0.01F , - 0.02085F , - 0.01F , - 0.02363F , - 0.01F , - 0.02641F , -
0.01F , - 0.02919F , - 0.01F , - 0.03197F , - 0.01F , - 0.03475F , - 0.01F ,
- 0.03753F , - 0.01F , - 0.04031F , - 0.01F , - 0.04309F , - 0.01F , -
0.04587F , - 0.01F , - 0.04865F , - 0.01F , - 0.05143F , - 0.01F , - 0.05421F
, - 0.01F , - 0.05699F , - 0.01F , - 0.05977F , - 0.01F , - 0.06255F , -
0.01F , - 0.06533F , - 0.01F , - 0.06811F , - 0.01F , - 0.07089F , - 0.01F ,
- 0.07367F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F ,
0.01F , 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F ,
0.01F , 0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F ,
0.01F , 0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F ,
0.01F , 0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F , 0.01F , 0.04587F ,
0.01F , 0.04865F , 0.01F , 0.05143F , 0.01F , 0.05421F , 0.01F , 0.05699F ,
0.01F , 0.05977F , 0.01F , 0.06255F , 0.01F , 0.06533F , 0.01F , 0.06811F ,
0.01F , 0.07089F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , - 0.00695F , - 0.01F , -
0.00973F , - 0.01F , - 0.01251F , - 0.01F , - 0.01529F , - 0.01F , - 0.01807F
, - 0.01F , - 0.02085F , - 0.01F , - 0.02363F , - 0.01F , - 0.02641F , -
0.01F , - 0.02919F , - 0.01F , - 0.03197F , - 0.01F , - 0.03475F , - 0.01F ,
- 0.03753F , - 0.01F , - 0.04031F , - 0.01F , - 0.04309F , - 0.01F , -
0.04587F , - 0.01F , - 0.04865F , - 0.01F , - 0.05143F , - 0.01F , - 0.05421F
, - 0.01F , - 0.05699F , - 0.01F , - 0.05977F , - 0.01F , - 0.06255F , -
0.01F , - 0.06533F , - 0.01F , - 0.06811F , - 0.01F , - 0.07089F , - 0.01F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F
, 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F ,
0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F ,
0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F ,
0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F , 0.01F , 0.04587F , 0.01F ,
0.04865F , 0.01F , 0.05143F , 0.01F , 0.05421F , 0.01F , 0.05699F , 0.01F ,
0.05977F , 0.01F , 0.06255F , 0.01F , 0.06533F , 0.01F , 0.06811F , 0.01F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , -
0.00139F , - 0.01F , - 0.00417F , - 0.01F , - 0.00695F , - 0.01F , - 0.00973F
, - 0.01F , - 0.01251F , - 0.01F , - 0.01529F , - 0.01F , - 0.01807F , -
0.01F , - 0.02085F , - 0.01F , - 0.02363F , - 0.01F , - 0.02641F , - 0.01F ,
- 0.02919F , - 0.01F , - 0.03197F , - 0.01F , - 0.03475F , - 0.01F , -
0.03753F , - 0.01F , - 0.04031F , - 0.01F , - 0.04309F , - 0.01F , - 0.04587F
, - 0.01F , - 0.04865F , - 0.01F , - 0.05143F , - 0.01F , - 0.05421F , -
0.01F , - 0.05699F , - 0.01F , - 0.05977F , - 0.01F , - 0.06255F , - 0.01F ,
- 0.06533F , - 0.01F , - 0.06811F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F ,
0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F ,
0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F ,
0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F ,
0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F , 0.01F , 0.04587F , 0.01F ,
0.04865F , 0.01F , 0.05143F , 0.01F , 0.05421F , 0.01F , 0.05699F , 0.01F ,
0.05977F , 0.01F , 0.06255F , 0.01F , 0.06533F , 0.01F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , -
0.01F , - 0.00417F , - 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F ,
- 0.01251F , - 0.01F , - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , -
0.02085F , - 0.01F , - 0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F
, - 0.01F , - 0.03197F , - 0.01F , - 0.03475F , - 0.01F , - 0.03753F , -
0.01F , - 0.04031F , - 0.01F , - 0.04309F , - 0.01F , - 0.04587F , - 0.01F ,
- 0.04865F , - 0.01F , - 0.05143F , - 0.01F , - 0.05421F , - 0.01F , -
0.05699F , - 0.01F , - 0.05977F , - 0.01F , - 0.06255F , - 0.01F , - 0.06533F
, - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F ,
0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F ,
0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F ,
0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F , 0.03753F , 0.01F ,
0.04031F , 0.01F , 0.04309F , 0.01F , 0.04587F , 0.01F , 0.04865F , 0.01F ,
0.05143F , 0.01F , 0.05421F , 0.01F , 0.05699F , 0.01F , 0.05977F , 0.01F ,
0.06255F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F ,
- 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F
, - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , - 0.01F , -
0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F , - 0.01F , - 0.03197F
, - 0.01F , - 0.03475F , - 0.01F , - 0.03753F , - 0.01F , - 0.04031F , -
0.01F , - 0.04309F , - 0.01F , - 0.04587F , - 0.01F , - 0.04865F , - 0.01F ,
- 0.05143F , - 0.01F , - 0.05421F , - 0.01F , - 0.05699F , - 0.01F , -
0.05977F , - 0.01F , - 0.06255F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F ,
0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F ,
0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F ,
0.01F , 0.03475F , 0.01F , 0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F ,
0.01F , 0.04587F , 0.01F , 0.04865F , 0.01F , 0.05143F , 0.01F , 0.05421F ,
0.01F , 0.05699F , 0.01F , 0.05977F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , - 0.00695F , - 0.01F , -
0.00973F , - 0.01F , - 0.01251F , - 0.01F , - 0.01529F , - 0.01F , - 0.01807F
, - 0.01F , - 0.02085F , - 0.01F , - 0.02363F , - 0.01F , - 0.02641F , -
0.01F , - 0.02919F , - 0.01F , - 0.03197F , - 0.01F , - 0.03475F , - 0.01F ,
- 0.03753F , - 0.01F , - 0.04031F , - 0.01F , - 0.04309F , - 0.01F , -
0.04587F , - 0.01F , - 0.04865F , - 0.01F , - 0.05143F , - 0.01F , - 0.05421F
, - 0.01F , - 0.05699F , - 0.01F , - 0.05977F , - 0.01F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F ,
0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F ,
0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F ,
0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F , 0.03753F , 0.01F ,
0.04031F , 0.01F , 0.04309F , 0.01F , 0.04587F , 0.01F , 0.04865F , 0.01F ,
0.05143F , 0.01F , 0.05421F , 0.01F , 0.05699F , 0.01F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , -
0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F , - 0.01529F
, - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , - 0.01F , - 0.02363F , -
0.01F , - 0.02641F , - 0.01F , - 0.02919F , - 0.01F , - 0.03197F , - 0.01F ,
- 0.03475F , - 0.01F , - 0.03753F , - 0.01F , - 0.04031F , - 0.01F , -
0.04309F , - 0.01F , - 0.04587F , - 0.01F , - 0.04865F , - 0.01F , - 0.05143F
, - 0.01F , - 0.05421F , - 0.01F , - 0.05699F , - 0.01F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F ,
0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F ,
0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F ,
0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F ,
0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F , 0.01F , 0.04587F , 0.01F ,
0.04865F , 0.01F , 0.05143F , 0.01F , 0.05421F , 0.01F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F ,
- 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F
, - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , - 0.01F , -
0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F , - 0.01F , - 0.03197F
, - 0.01F , - 0.03475F , - 0.01F , - 0.03753F , - 0.01F , - 0.04031F , -
0.01F , - 0.04309F , - 0.01F , - 0.04587F , - 0.01F , - 0.04865F , - 0.01F ,
- 0.05143F , - 0.01F , - 0.05421F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F ,
0.01F , 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F ,
0.01F , 0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F ,
0.01F , 0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F ,
0.01F , 0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F , 0.01F , 0.04587F ,
0.01F , 0.04865F , 0.01F , 0.05143F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , -
0.00417F , - 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F
, - 0.01F , - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , -
0.01F , - 0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F , - 0.01F ,
- 0.03197F , - 0.01F , - 0.03475F , - 0.01F , - 0.03753F , - 0.01F , -
0.04031F , - 0.01F , - 0.04309F , - 0.01F , - 0.04587F , - 0.01F , - 0.04865F
, - 0.01F , - 0.05143F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F ,
0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F ,
0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F ,
0.02363F , 0.01F , 0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F , 0.01F ,
0.03475F , 0.01F , 0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F , 0.01F ,
0.04587F , 0.01F , 0.04865F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , -
0.00417F , - 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F
, - 0.01F , - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , -
0.01F , - 0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F , - 0.01F ,
- 0.03197F , - 0.01F , - 0.03475F , - 0.01F , - 0.03753F , - 0.01F , -
0.04031F , - 0.01F , - 0.04309F , - 0.01F , - 0.04587F , - 0.01F , - 0.04865F
, - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F ,
0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F ,
0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F ,
0.02363F , 0.01F , 0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F , 0.01F ,
0.03475F , 0.01F , 0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F , 0.01F ,
0.04587F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , -
0.00417F , - 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F
, - 0.01F , - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , -
0.01F , - 0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F , - 0.01F ,
- 0.03197F , - 0.01F , - 0.03475F , - 0.01F , - 0.03753F , - 0.01F , -
0.04031F , - 0.01F , - 0.04309F , - 0.01F , - 0.04587F , - 0.01F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F
, 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F ,
0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F ,
0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F ,
0.03753F , 0.01F , 0.04031F , 0.01F , 0.04309F , 0.01F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , - 0.00695F
, - 0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F , - 0.01529F , -
0.01F , - 0.01807F , - 0.01F , - 0.02085F , - 0.01F , - 0.02363F , - 0.01F ,
- 0.02641F , - 0.01F , - 0.02919F , - 0.01F , - 0.03197F , - 0.01F , -
0.03475F , - 0.01F , - 0.03753F , - 0.01F , - 0.04031F , - 0.01F , - 0.04309F
, - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F ,
0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F ,
0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F , 0.02919F ,
0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F , 0.03753F , 0.01F , 0.04031F ,
0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , -
0.01F , - 0.00417F , - 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F ,
- 0.01251F , - 0.01F , - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , -
0.02085F , - 0.01F , - 0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F
, - 0.01F , - 0.03197F , - 0.01F , - 0.03475F , - 0.01F , - 0.03753F , -
0.01F , - 0.04031F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F
, 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F ,
0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F ,
0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F , 0.01F , 0.03475F , 0.01F ,
0.03753F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , - 0.00695F , -
0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F , - 0.01529F , - 0.01F ,
- 0.01807F , - 0.01F , - 0.02085F , - 0.01F , - 0.02363F , - 0.01F , -
0.02641F , - 0.01F , - 0.02919F , - 0.01F , - 0.03197F , - 0.01F , - 0.03475F
, - 0.01F , - 0.03753F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F ,
0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F ,
0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F , 0.02919F , 0.01F , 0.03197F ,
0.01F , 0.03475F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F , -
0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F ,
- 0.01529F , - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , - 0.01F , -
0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F , - 0.01F , - 0.03197F
, - 0.01F , - 0.03475F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F ,
0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F ,
0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F , 0.02919F ,
0.01F , 0.03197F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , -
0.00417F , - 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F
, - 0.01F , - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , -
0.01F , - 0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F , - 0.01F ,
- 0.03197F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F ,
0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F ,
0.01F , 0.02085F , 0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F , 0.02919F ,
0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F ,
- 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F
, - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , - 0.01F , -
0.02363F , - 0.01F , - 0.02641F , - 0.01F , - 0.02919F , - 0.01F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F , 0.01F ,
0.00973F , 0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F , 0.01F ,
0.02085F , 0.01F , 0.02363F , 0.01F , 0.02641F , 0.01F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , -
0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F , - 0.01529F
, - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , - 0.01F , - 0.02363F , -
0.01F , - 0.02641F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F ,
0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F ,
0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F ,
0.02363F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , - 0.00695F , - 0.01F , -
0.00973F , - 0.01F , - 0.01251F , - 0.01F , - 0.01529F , - 0.01F , - 0.01807F
, - 0.01F , - 0.02085F , - 0.01F , - 0.02363F , - 0.01F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F , 0.00417F ,
0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F , 0.01529F ,
0.01F , 0.01807F , 0.01F , 0.02085F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , -
0.00417F , - 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F
, - 0.01F , - 0.01529F , - 0.01F , - 0.01807F , - 0.01F , - 0.02085F , -
0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F
, 0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F , 0.01807F , 0.01F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , - 0.00695F , - 0.01F , -
0.00973F , - 0.01F , - 0.01251F , - 0.01F , - 0.01529F , - 0.01F , - 0.01807F
, - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F ,
0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F , 0.01529F , 0.01F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , -
0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F , - 0.01529F
, - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F ,
0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.01251F , 0.01F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F ,
- 0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , - 0.01251F , - 0.01F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F ,
0.00417F , 0.01F , 0.00695F , 0.01F , 0.00973F , 0.01F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F , -
0.01F , - 0.00695F , - 0.01F , - 0.00973F , - 0.01F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F ,
0.00417F , 0.01F , 0.00695F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , -
0.00695F , - 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.00139F , 0.01F , 0.00417F , 0.01F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , - 0.00139F , - 0.01F , - 0.00417F , - 0.01F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , 0.00139F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.00139F , - 0.01F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , - 0.0F , - 0.0F , - 0.0F ,
- 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , -
0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F
, - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F } ; static const
real32_T w [ 16 ] = { 53143.1172F , 48726.6484F , 44516.6406F , 0.0F ,
48726.6484F , 44699.0156F , 40857.2969F , 0.0F , 44516.6406F , 40857.2969F ,
37365.293F , 0.0F , 0.0F , 0.0F , 0.0F , 100000.0F } ; static const real32_T
y [ 504 ] = { - 0.226396441F , - 0.702190518F , - 0.896725774F , -
2.45115852F , - 2.06062078F , - 4.78707409F , - 3.79357576F , - 7.39359856F ,
- 6.1606F , - 10.0878134F , - 9.20603752F , - 12.7818756F , - 12.9553299F , -
15.4446115F , - 17.420578F , - 18.0731106F , - 22.6059837F , - 20.6752605F ,
- 28.5118504F , - 23.2607288F , - 35.1370201F , - 25.8373013F , - 42.4801064F
, - 28.4100571F , - 50.54002F , - 30.9818F , - 59.3160439F , - 33.5537872F ,
- 68.8077927F , - 36.1264076F , - 79.0150909F , - 38.6996231F , - 89.9378891F
, - 41.2732773F , - 101.576187F , - 43.8471947F , - 113.930023F , -
46.4212418F , - 126.999405F , - 48.9953423F , - 140.784363F , - 51.5694504F ,
- 155.284912F , - 54.1435547F , - 170.501038F , - 56.7176437F , - 186.43277F
, - 59.2917252F , - 203.080078F , - 61.8658F , - 220.443F , - 64.4398651F , -
238.521484F , - 67.0139313F , - 257.315582F , - 69.588F , - 276.825256F , -
72.1620636F , - 297.050537F , - 74.7361298F , 0.226396441F , 0.702190518F ,
0.896725774F , 2.45115852F , 2.06062078F , 4.78707409F , 3.79357576F ,
7.39359856F , 6.1606F , 10.0878134F , 9.20603752F , 12.7818756F , 12.9553299F
, 15.4446115F , 17.420578F , 18.0731106F , 22.6059837F , 20.6752605F ,
28.5118504F , 23.2607288F , 35.1370201F , 25.8373013F , 42.4801064F ,
28.4100571F , 50.54002F , 30.9818F , 59.3160439F , 33.5537872F , 68.8077927F
, 36.1264076F , 79.0150909F , 38.6996231F , 89.9378891F , 41.2732773F ,
101.576187F , 43.8471947F , 113.930023F , 46.4212418F , 126.999405F ,
48.9953423F , 140.784363F , 51.5694504F , 155.284912F , 54.1435547F ,
170.501038F , 56.7176437F , 186.43277F , 59.2917252F , 203.080078F , 61.8658F
, 220.443F , 64.4398651F , 238.521484F , 67.0139313F , 257.315582F , 69.588F
, 276.825256F , 72.1620636F , 297.050537F , 74.7361298F , - 1.0F , - 1.0F , -
1.0F , 1.0F , 1.0F , 1.0F , - 0.0F , - 0.0F , - 0.226396441F , - 0.702190518F
, - 0.896725774F , - 2.45115852F , - 2.06062078F , - 4.78707409F , -
3.79357576F , - 7.39359856F , - 6.1606F , - 10.0878134F , - 9.20603752F , -
12.7818756F , - 12.9553299F , - 15.4446115F , - 17.420578F , - 18.0731106F ,
- 22.6059837F , - 20.6752605F , - 28.5118504F , - 23.2607288F , - 35.1370201F
, - 25.8373013F , - 42.4801064F , - 28.4100571F , - 50.54002F , - 30.9818F ,
- 59.3160439F , - 33.5537872F , - 68.8077927F , - 36.1264076F , - 79.0150909F
, - 38.6996231F , - 89.9378891F , - 41.2732773F , - 101.576187F , -
43.8471947F , - 113.930023F , - 46.4212418F , - 126.999405F , - 48.9953423F ,
- 140.784363F , - 51.5694504F , - 155.284912F , - 54.1435547F , - 170.501038F
, - 56.7176437F , - 186.43277F , - 59.2917252F , - 203.080078F , - 61.8658F ,
- 220.443F , - 64.4398651F , - 238.521484F , - 67.0139313F , - 257.315582F ,
- 69.588F , - 276.825256F , - 72.1620636F , 0.0F , 0.0F , 0.226396441F ,
0.702190518F , 0.896725774F , 2.45115852F , 2.06062078F , 4.78707409F ,
3.79357576F , 7.39359856F , 6.1606F , 10.0878134F , 9.20603752F , 12.7818756F
, 12.9553299F , 15.4446115F , 17.420578F , 18.0731106F , 22.6059837F ,
20.6752605F , 28.5118504F , 23.2607288F , 35.1370201F , 25.8373013F ,
42.4801064F , 28.4100571F , 50.54002F , 30.9818F , 59.3160439F , 33.5537872F
, 68.8077927F , 36.1264076F , 79.0150909F , 38.6996231F , 89.9378891F ,
41.2732773F , 101.576187F , 43.8471947F , 113.930023F , 46.4212418F ,
126.999405F , 48.9953423F , 140.784363F , 51.5694504F , 155.284912F ,
54.1435547F , 170.501038F , 56.7176437F , 186.43277F , 59.2917252F ,
203.080078F , 61.8658F , 220.443F , 64.4398651F , 238.521484F , 67.0139313F ,
257.315582F , 69.588F , 276.825256F , 72.1620636F , - 0.0F , - 1.0F , - 1.0F
, 0.0F , 1.0F , 1.0F , - 0.0F , - 0.0F , - 0.0F , - 0.0F , - 0.226396441F , -
0.702190518F , - 0.896725774F , - 2.45115852F , - 2.06062078F , - 4.78707409F
, - 3.79357576F , - 7.39359856F , - 6.1606F , - 10.0878134F , - 9.20603752F ,
- 12.7818756F , - 12.9553299F , - 15.4446115F , - 17.420578F , - 18.0731106F
, - 22.6059837F , - 20.6752605F , - 28.5118504F , - 23.2607288F , -
35.1370201F , - 25.8373013F , - 42.4801064F , - 28.4100571F , - 50.54002F , -
30.9818F , - 59.3160439F , - 33.5537872F , - 68.8077927F , - 36.1264076F , -
79.0150909F , - 38.6996231F , - 89.9378891F , - 41.2732773F , - 101.576187F ,
- 43.8471947F , - 113.930023F , - 46.4212418F , - 126.999405F , - 48.9953423F
, - 140.784363F , - 51.5694504F , - 155.284912F , - 54.1435547F , -
170.501038F , - 56.7176437F , - 186.43277F , - 59.2917252F , - 203.080078F ,
- 61.8658F , - 220.443F , - 64.4398651F , - 238.521484F , - 67.0139313F , -
257.315582F , - 69.588F , 0.0F , 0.0F , 0.0F , 0.0F , 0.226396441F ,
0.702190518F , 0.896725774F , 2.45115852F , 2.06062078F , 4.78707409F ,
3.79357576F , 7.39359856F , 6.1606F , 10.0878134F , 9.20603752F , 12.7818756F
, 12.9553299F , 15.4446115F , 17.420578F , 18.0731106F , 22.6059837F ,
20.6752605F , 28.5118504F , 23.2607288F , 35.1370201F , 25.8373013F ,
42.4801064F , 28.4100571F , 50.54002F , 30.9818F , 59.3160439F , 33.5537872F
, 68.8077927F , 36.1264076F , 79.0150909F , 38.6996231F , 89.9378891F ,
41.2732773F , 101.576187F , 43.8471947F , 113.930023F , 46.4212418F ,
126.999405F , 48.9953423F , 140.784363F , 51.5694504F , 155.284912F ,
54.1435547F , 170.501038F , 56.7176437F , 186.43277F , 59.2917252F ,
203.080078F , 61.8658F , 220.443F , 64.4398651F , 238.521484F , 67.0139313F ,
257.315582F , 69.588F , - 0.0F , - 0.0F , - 1.0F , 0.0F , 0.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F
, 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 1.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F } ; static const real32_T ab [ 2 ] = {
0.0956352502F , 0.000956352509F } ; static const real32_T bb [ 90 ] = { 1.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F , 0.0F
, 0.0F } ; real32_T oufhr3etum [ 4 ] ; real32_T jf50vicfwe [ 30 ] ; real32_T
ok5qdalvvh ; real32_T grweq2psvh [ 16 ] ; static const int8_T tmp [ 8 ] = { 0
, 0 , 0 , 0 , 1 , 0 , 0 , 1 } ; real32_T tmp_p [ 2 ] ; real32_T xk_p [ 5 ] ;
real32_T r_p [ 630 ] ; real32_T s_p [ 126 ] ; real32_T y_p [ 504 ] ; real32_T
tmp_e [ 30 ] ; real32_T lqk3zojcut_p [ 31 ] ; real32_T tmp_i [ 2 ] ; real32_T
y_e [ 8 ] ; real32_T e_p [ 30 ] ; real32_T g_p [ 12 ] ; real32_T tmp_m [ 2 ]
; real32_T Af_p [ 16 ] ; real32_T tmp_g [ 6 ] ; real32_T d_e [ 4 ] ; int32_T
i_e ; real32_T tmp_j [ 8 ] ; real32_T y_i [ 8 ] ; real32_T b_A_p [ 25 ] ;
real32_T Cm_p [ 2 ] ; real32_T Dvm_p [ 2 ] ; real32_T tmp_f [ 2 ] ; real32_T
tmp_c [ 2 ] ; real32_T tmp_k [ 10 ] ; real32_T b_A_e [ 25 ] ; real32_T b_A_i
[ 25 ] ; real32_T b_A_m [ 25 ] ; int32_T i_i ; int32_T i_m ; int32_T d_tmp ;
int32_T b_A_tmp ; if ( ( a0xrpmr0lc -> Left . Strength > 0.0F ) && (
a0xrpmr0lc -> Right . Strength > 0.0F ) ) { localB -> mmcgmfp2o3 = (
a0xrpmr0lc -> Left . Curvature + a0xrpmr0lc -> Right . Curvature ) *
ajghr3ctyr . P_6 ; localB -> hbjo123h1b = ( a0xrpmr0lc -> Left .
CurvatureDerivative + a0xrpmr0lc -> Right . CurvatureDerivative ) *
ajghr3ctyr . P_7 ; localB -> nfr45zfsgr = ( a0xrpmr0lc -> Left . HeadingAngle
+ a0xrpmr0lc -> Right . HeadingAngle ) * ajghr3ctyr . P_8 ; localB ->
iae25d40vx = ( a0xrpmr0lc -> Left . LateralOffset + a0xrpmr0lc -> Right .
LateralOffset ) * ajghr3ctyr . P_9 ; localDW -> hwadutcumr = 4 ; } else if (
a0xrpmr0lc -> Left . Strength > 0.0F ) { ok5qdalvvh = ajghr3ctyr . P_10 -
a0xrpmr0lc -> Left . Curvature * ajghr3ctyr . P_11 ; localB -> mmcgmfp2o3 =
a0xrpmr0lc -> Left . Curvature / ok5qdalvvh ; localB -> hbjo123h1b =
a0xrpmr0lc -> Left . CurvatureDerivative / ( ok5qdalvvh * ok5qdalvvh ) ;
localB -> iae25d40vx = a0xrpmr0lc -> Left . LateralOffset - ajghr3ctyr . P_12
; localB -> nfr45zfsgr = a0xrpmr0lc -> Left . HeadingAngle ; localDW ->
hiiwcrboab = 4 ; } else if ( a0xrpmr0lc -> Right . Strength > 0.0F ) {
ok5qdalvvh = a0xrpmr0lc -> Right . Curvature * ajghr3ctyr . P_14 + ajghr3ctyr
. P_13 ; localB -> mmcgmfp2o3 = a0xrpmr0lc -> Right . Curvature / ok5qdalvvh
; localB -> hbjo123h1b = a0xrpmr0lc -> Right . CurvatureDerivative / (
ok5qdalvvh * ok5qdalvvh ) ; localB -> iae25d40vx = a0xrpmr0lc -> Right .
LateralOffset + ajghr3ctyr . P_15 ; localB -> nfr45zfsgr = a0xrpmr0lc ->
Right . HeadingAngle ; localDW -> lrava23ncm = 4 ; } else { localB ->
mmcgmfp2o3 = localDW -> ayeaqphirh ; localB -> hbjo123h1b = localDW ->
idw3weirf3 ; localB -> nfr45zfsgr = localDW -> hryujm23gv ; localB ->
iae25d40vx = localDW -> c20jlygsay ; localDW -> jeftpncfv5 = 4 ; } if ( -
localB -> iae25d40vx > ajghr3ctyr . P_21 ) { cjpq4sbzb4 = ajghr3ctyr . P_21 ;
} else if ( - localB -> iae25d40vx < ajghr3ctyr . P_22 ) { cjpq4sbzb4 =
ajghr3ctyr . P_22 ; } else { cjpq4sbzb4 = - localB -> iae25d40vx ; } if ( -
localB -> nfr45zfsgr > ajghr3ctyr . P_24 ) { haabair13z = ajghr3ctyr . P_24 ;
} else if ( - localB -> nfr45zfsgr < ajghr3ctyr . P_25 ) { haabair13z =
ajghr3ctyr . P_25 ; } else { haabair13z = - localB -> nfr45zfsgr ; } if (
localB -> mmcgmfp2o3 > ajghr3ctyr . P_30 ) { ok5qdalvvh = ajghr3ctyr . P_30 ;
} else if ( localB -> mmcgmfp2o3 < ajghr3ctyr . P_31 ) { ok5qdalvvh =
ajghr3ctyr . P_31 ; } else { ok5qdalvvh = localB -> mmcgmfp2o3 ; } for ( i =
0 ; i < 31 ; i ++ ) { t [ i ] = ( ( 1.0 + ( real_T ) i ) - 1.0 ) * lh4i401auv
; } if ( localB -> hbjo123h1b > ajghr3ctyr . P_33 ) { a = ajghr3ctyr . P_33 ;
} else if ( localB -> hbjo123h1b < ajghr3ctyr . P_34 ) { a = ajghr3ctyr .
P_34 ; } else { a = localB -> hbjo123h1b ; } a *= * j5ofsry4is ; oufhr3etum [
0 ] = localB -> d1uo5hrcw0 / ajghr3ctyr . P_65 / * j5ofsry4is ; h = localB ->
pfdh1l3ror / * j5ofsry4is ; oufhr3etum [ 1 ] = h / ajghr3ctyr . P_69 ;
oufhr3etum [ 2 ] = h / ajghr3ctyr . P_65 - * j5ofsry4is ; oufhr3etum [ 3 ] =
localB -> lv4o50mg5y / * j5ofsry4is / ajghr3ctyr . P_69 ; tmp_g [ 0 ] =
ajghr3ctyr . P_73 [ 0 ] ; tmp_g [ 1 ] = ajghr3ctyr . P_73 [ 1 ] ; tmp_g [ 2 ]
= 0.0F ; tmp_g [ 3 ] = ajghr3ctyr . P_73 [ 2 ] ; tmp_g [ 4 ] = ajghr3ctyr .
P_73 [ 3 ] ; tmp_g [ 5 ] = 0.0F ; i_i = 0 ; i_m = 0 ; for ( i = 0 ; i < 2 ; i
++ ) { Coef = 0 ; b_A_tmp = 0 ; for ( i_e = 0 ; i_e < 2 ; i_e ++ ) { d_tmp =
Coef + i ; d_e [ d_tmp ] = 0.0F ; d_e [ d_tmp ] += tmp_g [ b_A_tmp ] * (
real32_T ) d [ i ] ; d_e [ d_tmp ] = tmp_g [ b_A_tmp + 1 ] * ( real32_T ) d [
i + 2 ] + d_e [ Coef + i ] ; d_e [ d_tmp ] = tmp_g [ b_A_tmp + 2 ] * (
real32_T ) d [ i + 4 ] + d_e [ Coef + i ] ; d_tmp = i_e + i_i ; Af [ d_tmp ]
= oufhr3etum [ i_e + i_m ] ; Af [ d_tmp + 8 ] = 0.0F ; Coef += 2 ; b_A_tmp +=
3 ; } i_i += 4 ; i_m += 2 ; } Af [ 10 ] = 0.0F ; Af [ 14 ] = * j5ofsry4is ;
Af [ 2 ] = d_e [ 0 ] ; Af [ 3 ] = d_e [ 1 ] ; Af [ 11 ] = 0.0F ; Af [ 6 ] =
d_e [ 2 ] ; Af [ 7 ] = d_e [ 3 ] ; Af [ 15 ] = 0.0F ; for ( i_i = 0 ; i_i <
16 ; i_i ++ ) { Af_p [ i_i ] = Af [ i_i ] * ajghr3ctyr . P_61 ; }
expm_cf1QcFJp ( Af_p , grweq2psvh ) ; h = ajghr3ctyr . P_61 / 4.0F ; for (
i_i = 0 ; i_i < 16 ; i_i ++ ) { I [ i_i ] = 0 ; } I [ 0 ] = 1 ; I [ 5 ] = 1 ;
I [ 10 ] = 1 ; I [ 15 ] = 1 ; for ( i_i = 0 ; i_i < 16 ; i_i ++ ) { Ai [ i_i
] = ( real32_T ) I [ i_i ] + grweq2psvh [ i_i ] ; } Coef = 2 ; for ( i = 0 ;
i < 3 ; i ++ ) { if ( Coef == 2 ) { Coef = 4 ; } else { Coef = 2 ; } i_i = 1
+ i ; for ( i_m = 0 ; i_m < 16 ; i_m ++ ) { Af_p [ i_m ] = Af [ i_m ] * (
real32_T ) i_i * h ; } expm_cf1QcFJp ( Af_p , b ) ; for ( i_i = 0 ; i_i < 16
; i_i ++ ) { Ai [ i_i ] += ( real32_T ) Coef * b [ i_i ] ; } } h /= 3.0F ;
for ( i_i = 0 ; i_i < 155 ; i_i ++ ) { Bu [ i_i ] = 0.0F ; } for ( i_i = 0 ;
i_i < 310 ; i_i ++ ) { Bv [ i_i ] = 0.0F ; } for ( i_i = 0 ; i_i < 124 ; i_i
++ ) { Dv [ i_i ] = 0.0F ; Dvm [ i_i ] = 0.0F ; } for ( i_i = 0 ; i_i < 310 ;
i_i ++ ) { Cm [ i_i ] = 0.0F ; } memcpy ( & b_A [ 0 ] , & d_p [ 0 ] , 25U *
sizeof ( real32_T ) ) ; for ( i_i = 0 ; i_i < 10 ; i_i ++ ) { b_C [ i_i ] = f
[ i_i ] ; } tmp_j [ 0 ] = localB -> ach0dqbfpm ; tmp_j [ 1 ] = localB ->
i0l5pfyvd3 ; tmp_j [ 4 ] = 0.0F ; tmp_j [ 5 ] = 0.0F ; tmp_j [ 2 ] = 0.0F ;
tmp_j [ 3 ] = 0.0F ; tmp_j [ 6 ] = 0.0F ; tmp_j [ 7 ] = - 1.0F ; i_i = 0 ;
for ( i_m = 0 ; i_m < 2 ; i_m ++ ) { for ( i = 0 ; i < 4 ; i ++ ) { Coef = i
+ i_i ; y_i [ Coef ] = 0.0F ; y_i [ Coef ] += h * Ai [ i ] * tmp_j [ i_i ] ;
y_i [ Coef ] = Ai [ i + 4 ] * h * tmp_j [ i_i + 1 ] + y_i [ i + i_i ] ; y_i [
Coef ] = Ai [ i + 8 ] * h * 0.0F + y_i [ i + i_i ] ; y_i [ Coef ] = Ai [ i +
12 ] * h * tmp_j [ i_i + 3 ] + y_i [ i + i_i ] ; } i_i += 4 ; } for ( i_i = 0
; i_i < 8 ; i_i ++ ) { y_e [ i_i ] = y_i [ i_i ] ; tmp_j [ i_i ] = tmp [ i_i
] ; } d_e [ 0 ] = 0.0F ; d_e [ 1 ] = 0.0F ; d_e [ 2 ] = 0.0F ; d_e [ 3 ] =
0.0F ; tmp_m [ 0 ] = 1.0F ; tmp_m [ 1 ] = 2.0F ; memcpy ( & e_p [ 0 ] , & e [
0 ] , 30U * sizeof ( real32_T ) ) ; for ( i_i = 0 ; i_i < 12 ; i_i ++ ) { g_p
[ i_i ] = g [ i_i ] ; } mpc_plantupdate_aUusw0Me ( grweq2psvh , y_e , tmp_j ,
d_e , b_A , e_p , b_C , g_p , tmp_m , h_p , i_p , & Bu [ 0 ] , L , b_p ,
oufhr3etum , Kinv , Qk , Rk , Nk ) ; i_i = 0 ; for ( i_m = 0 ; i_m < 2 ; i_m
++ ) { for ( i = 0 ; i < 5 ; i ++ ) { Coef = i + i_i ; Bv [ Coef ] = L [ Coef
] ; } i_i += 5 ; } i_i = 0 ; for ( i_m = 0 ; i_m < 5 ; i_m ++ ) { Cm [ i_i ]
= b_p [ i_i ] ; Cm [ i_i + 1 ] = b_p [ i_i + 1 ] ; i_i += 2 ; } Dv [ 0 ] =
oufhr3etum [ 0 ] ; Dvm [ 0 ] = Kinv [ 0 ] ; Dv [ 1 ] = oufhr3etum [ 1 ] ; Dvm
[ 1 ] = Kinv [ 1 ] ; Dv [ 2 ] = oufhr3etum [ 2 ] ; Dvm [ 2 ] = Kinv [ 2 ] ;
Dv [ 3 ] = oufhr3etum [ 3 ] ; Dvm [ 3 ] = Kinv [ 3 ] ; memcpy ( & b_Mlim [ 0
] , & j [ 0 ] , 126U * sizeof ( real32_T ) ) ; for ( i = 0 ; i < 30 ; i ++ )
{ e_p [ i ] = 0.0F ; } for ( i = 0 ; i < 5 ; i ++ ) { b_xoff [ i ] = 0.0F ; }
tmp_m [ 0 ] = 0.0F ; tmp_i [ 0 ] = 1.0F ; tmp_m [ 1 ] = 0.0F ; tmp_i [ 1 ] =
2.0F ; j3f42jwfjx ( b_Mlim , k , ajghr3ctyr . P_74 , h_p , e_p , ajghr3ctyr .
P_75 , i_p , tmp_m , tmp_i , ajghr3ctyr . P_76 , b_xoff , ajghr3ctyr . P_77 ,
Bv , & h , & b_voff , b_yoff , y_innov ) ; for ( i_i = 0 ; i_i < 31 ; i_i ++
) { lqk3zojcut_p [ i_i ] = ( a * ( real32_T ) t [ i_i ] + ok5qdalvvh ) * *
j5ofsry4is ; } tmp_m [ 0 ] = 2.0F ; tmp_m [ 1 ] = 10.0F ; igprtpl1k4 (
ajghr3ctyr . P_28 , lqk3zojcut_p , b_yoff , b_voff , tmp_m , gvcozy12gk ,
rseq , vseq , v ) ; eye_1T7g1wOb ( d_e ) ; for ( i_i = 0 ; i_i < 2 ; i_i ++ )
{ for ( i_m = 0 ; i_m < 5 ; i_m ++ ) { b_p [ i_i + ( i_m << 1 ) ] = 0.0F ;
for ( i = 0 ; i < 5 ; i ++ ) { b_p [ i_i + ( i_m << 1 ) ] += Cm [ ( i << 1 )
+ i_i ] * localDW -> fowmhxaqij [ 5 * i_m + i ] ; } } for ( i_m = 0 ; i_m < 2
; i_m ++ ) { a = 0.0F ; for ( i = 0 ; i < 5 ; i ++ ) { a += b_p [ ( i << 1 )
+ i_i ] * Cm [ ( i << 1 ) + i_m ] ; } oufhr3etum [ i_i + ( i_m << 1 ) ] = Rk
[ ( i_m << 1 ) + i_i ] + a ; } } mrdivide_fJHemlFH ( d_e , oufhr3etum , Kinv
) ; for ( i_i = 0 ; i_i < 5 ; i_i ++ ) { for ( i_m = 0 ; i_m < 5 ; i_m ++ ) {
Coef = i_i + 5 * i_m ; b_A_p [ Coef ] = 0.0F ; for ( i = 0 ; i < 5 ; i ++ ) {
b_A_p [ Coef ] = b_A [ 5 * i + i_i ] * localDW -> fowmhxaqij [ 5 * i_m + i ]
+ b_A_p [ 5 * i_m + i_i ] ; } } for ( i_m = 0 ; i_m < 2 ; i_m ++ ) { a = 0.0F
; for ( i = 0 ; i < 5 ; i ++ ) { a += b_A_p [ 5 * i + i_i ] * Cm [ ( i << 1 )
+ i_m ] ; } b_p [ i_i + 5 * i_m ] = Nk [ 5 * i_m + i_i ] + a ; } L [ i_i ] =
0.0F ; L [ i_i ] += b_p [ i_i ] * Kinv [ 0 ] ; L [ i_i ] += b_p [ i_i + 5 ] *
Kinv [ 1 ] ; L [ i_i + 5 ] = 0.0F ; L [ i_i + 5 ] += b_p [ i_i ] * Kinv [ 2 ]
; L [ i_i + 5 ] += b_p [ i_i + 5 ] * Kinv [ 3 ] ; xk [ i_i ] = ( localDW ->
cf5jrvxca5 [ i_i ] - b_xoff [ i_i ] ) + Bu [ i_i ] * 0.0F ; } tmp_m [ 0 ] =
cjpq4sbzb4 ; tmp_m [ 1 ] = haabair13z ; tmp_f [ 0 ] = ajghr3ctyr . P_37 ;
tmp_f [ 1 ] = ajghr3ctyr . P_38 ; tmp_c [ 0 ] = ajghr3ctyr . P_40 ; tmp_c [ 1
] = ajghr3ctyr . P_41 ; for ( i_i = 0 ; i_i < 2 ; i_i ++ ) { Cm_p [ i_i ] =
0.0F ; i_m = 0 ; for ( i = 0 ; i < 5 ; i ++ ) { Cm_p [ i_i ] += Cm [ i_m +
i_i ] * xk [ i ] ; i_m += 2 ; } Dvm_p [ i_i ] = 0.0F ; Dvm_p [ i_i ] += Dvm [
i_i ] * v [ 0 ] ; Dvm_p [ i_i ] += Dvm [ i_i + 2 ] * v [ 1 ] ; tmp_i [ i_i ]
= ajghr3ctyr . P_39 [ i_i ] * tmp_f [ i_i ] ; tmp_p [ i_i ] = ajghr3ctyr .
P_42 [ i_i ] * tmp_c [ i_i ] ; y_innov [ i_i ] = ( ( 8.0F * ( real32_T ) i_i
+ 2.0F ) * tmp_m [ i_i ] - y_innov [ i_i ] ) - ( Cm_p [ i_i ] + Dvm_p [ i_i ]
) ; } for ( i_i = 0 ; i_i < 5 ; i_i ++ ) { i_m = 0 ; for ( i = 0 ; i < 2 ; i
++ ) { Coef = i_m + i_i ; b_p [ Coef ] = 0.0F ; b_A_tmp = 0 ; i_e = 0 ; for (
d_tmp = 0 ; d_tmp < 5 ; d_tmp ++ ) { b_p [ Coef ] += localDW -> fowmhxaqij [
b_A_tmp + i_i ] * Cm [ i_e + i ] ; b_A_tmp += 5 ; i_e += 2 ; } i_m += 5 ; }
tmp_k [ i_i ] = 0.0F ; tmp_k [ i_i ] += b_p [ i_i ] * Kinv [ 0 ] ; tmp_k [
i_i ] += b_p [ i_i + 5 ] * Kinv [ 1 ] ; a = tmp_k [ i_i ] * y_innov [ 0 ] ;
tmp_k [ i_i + 5 ] = 0.0F ; tmp_k [ i_i + 5 ] += b_p [ i_i ] * Kinv [ 2 ] ;
tmp_k [ i_i + 5 ] += b_p [ i_i + 5 ] * Kinv [ 3 ] ; a += tmp_k [ i_i + 5 ] *
y_innov [ 1 ] ; xk_p [ i_i ] = xk [ i_i ] + a ; } for ( i_i = 0 ; i_i < 30 ;
i_i ++ ) { tmp_e [ i_i ] = 1.0F ; } memcpy ( & r_p [ 0 ] , & r [ 0 ] , 630U *
sizeof ( real32_T ) ) ; memcpy ( & s_p [ 0 ] , & s [ 0 ] , 126U * sizeof (
real32_T ) ) ; memcpy ( & localB -> pa2ccbhiyz [ 0 ] , & t_p [ 0 ] , 7812U *
sizeof ( real32_T ) ) ; memcpy ( & Af [ 0 ] , & w [ 0 ] , sizeof ( real32_T )
<< 4U ) ; memcpy ( & y_p [ 0 ] , & y [ 0 ] , 504U * sizeof ( real32_T ) ) ;
lwcdcfsdhw ( rseq , vseq , ajghr3ctyr . P_35 * localB -> kril0wyeg3 ,
ajghr3ctyr . P_36 * localB -> fbs4tfm210 , tmp_i , tmp_p , localB ->
odjgtv4pzb , xk_p , localDW -> kxvvsjr51z - h , localDW -> enqs1wotqd ,
b_Mlim , r_p , s_p , localB -> pa2ccbhiyz , e_p , h , b_yoff , bauenncvm4 ,
Af , y_p , ab , bb , tmp_e , b_A , Bu , Bv , b_C , Dv , k , & localB ->
pv0cqe5xzb , jf50vicfwe , & ok5qdalvvh , localB -> o5pj2sk15l , localB ) ;
ok5qdalvvh = localB -> pv0cqe5xzb - h ; for ( i_i = 0 ; i_i < 5 ; i_i ++ ) {
for ( i_m = 0 ; i_m < 5 ; i_m ++ ) { Coef = i_i + 5 * i_m ; b_A_p [ Coef ] =
0.0F ; b_A_e [ Coef ] = 0.0F ; for ( i = 0 ; i < 5 ; i ++ ) { b_A_tmp = 5 *
i_m + i_i ; a = b_A [ 5 * i + i_i ] * localDW -> fowmhxaqij [ 5 * i_m + i ] ;
b_A_p [ Coef ] = a + b_A_p [ b_A_tmp ] ; b_A_e [ Coef ] = a + b_A_e [ b_A_tmp
] ; } } for ( i_m = 0 ; i_m < 2 ; i_m ++ ) { a = 0.0F ; for ( i = 0 ; i < 5 ;
i ++ ) { a += b_A_e [ 5 * i + i_i ] * Cm [ ( i << 1 ) + i_m ] ; } b_p [ i_i +
5 * i_m ] = Nk [ 5 * i_m + i_i ] + a ; } for ( i_m = 0 ; i_m < 5 ; i_m ++ ) {
Coef = i_i + 5 * i_m ; b_A_i [ Coef ] = 0.0F ; for ( i = 0 ; i < 5 ; i ++ ) {
b_A_i [ Coef ] = b_A_p [ 5 * i + i_i ] * b_A [ 5 * i + i_m ] + b_A_i [ 5 *
i_m + i_i ] ; } b_A_m [ Coef ] = 0.0F ; b_A_m [ Coef ] = b_A_m [ 5 * i_m +
i_i ] + b_p [ i_i ] * L [ i_m ] ; b_A_m [ Coef ] = b_A_m [ 5 * i_m + i_i ] +
b_p [ i_i + 5 ] * L [ i_m + 5 ] ; } } i_i = 0 ; for ( i_m = 0 ; i_m < 5 ; i_m
++ ) { a = 0.0F ; i = 0 ; for ( Coef = 0 ; Coef < 5 ; Coef ++ ) { b_A_tmp =
Coef + i_i ; b_A_p [ b_A_tmp ] = ( b_A_i [ b_A_tmp ] - b_A_m [ b_A_tmp ] ) +
Qk [ b_A_tmp ] ; a += b_A [ i + i_m ] * xk [ Coef ] ; i += 5 ; } xk_p [ i_m ]
= 0.0F ; xk_p [ i_m ] += Bv [ i_m ] * v [ 0 ] ; xk_p [ i_m ] += Bv [ i_m + 5
] * v [ 1 ] ; localB -> loumcs1pnk [ i_m ] = ( ( ( Bu [ i_m ] * ok5qdalvvh +
a ) + xk_p [ i_m ] ) + ( L [ i_m + 5 ] * y_innov [ 1 ] + L [ i_m ] * y_innov
[ 0 ] ) ) + b_xoff [ i_m ] ; i_i += 5 ; } a = - 0.0F ; i_i = 0 ; for ( i_m =
0 ; i_m < 5 ; i_m ++ ) { i = 0 ; for ( Coef = 0 ; Coef < 5 ; Coef ++ ) {
b_A_tmp = Coef + i_i ; localB -> a2usnvldsr [ b_A_tmp ] = ( b_A_p [ b_A_tmp ]
+ b_A_p [ i + i_m ] ) * 0.5F ; i += 5 ; } a += localDW -> jx11wd5i0n [ i_m ]
; i_i += 5 ; } ezxxoe0g3z = a0xrpmr0lc -> Left . LateralOffset ; bth5edrrpr =
a0xrpmr0lc -> Right . LateralOffset ; o4ugtpgvyj = ajghr3ctyr . P_79 * *
ggzreh1sbs ; nadxvhdukv = ( ( ezxxoe0g3z <= * ggzreh1sbs ) || ( bth5edrrpr >=
o4ugtpgvyj ) ) ; localB -> bgyuap3dxu = ( nadxvhdukv || ( ( ! ( a >=
ajghr3ctyr . P_3 ) ) && localDW -> mbmtbdjeqm ) ) ; * gsarxirkom = ( ( *
dl2h23j0yb ) && localB -> bgyuap3dxu ) ; dtl4ybo5ws = ajghr3ctyr . P_80 *
localB -> pv0cqe5xzb ; if ( * gsarxirkom ) { * h0jeecywei = dtl4ybo5ws ; }
else { * h0jeecywei = * gy14yybqge ; } { if ( ( localDW -> d0ox53zfja .
AQHandles || localDW -> d0ox53zfja . SlioLTF ) && ssGetLogOutput ( iu2zxy1bg0
-> _mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal ( localDW -> d0ox53zfja .
AQHandles , localDW -> d0ox53zfja . SlioLTF , 0 , rtmGetTaskTime ( iu2zxy1bg0
, 0 ) , ( void * ) & dtl4ybo5ws ) ; } } localB -> ks4nioygh5 = ( real32_T ) (
muSingleScalarAbs ( dtl4ybo5ws - * gy14yybqge ) <= ajghr3ctyr . P_5 ) ; { if
( ( localDW -> dpmuujlupa . AQHandles || localDW -> dpmuujlupa . SlioLTF ) &&
ssGetLogOutput ( iu2zxy1bg0 -> _mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal (
localDW -> dpmuujlupa . AQHandles , localDW -> dpmuujlupa . SlioLTF , 0 ,
rtmGetTaskTime ( iu2zxy1bg0 , 0 ) , ( void * ) & nadxvhdukv ) ; } } { if ( (
localDW -> igap1wnipb . AQHandles || localDW -> igap1wnipb . SlioLTF ) &&
ssGetLogOutput ( iu2zxy1bg0 -> _mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal (
localDW -> igap1wnipb . AQHandles , localDW -> igap1wnipb . SlioLTF , 0 ,
rtmGetTaskTime ( iu2zxy1bg0 , 0 ) , ( void * ) & o4ugtpgvyj ) ; } } { if ( (
localDW -> dfhhcydsof . AQHandles || localDW -> dfhhcydsof . SlioLTF ) &&
ssGetLogOutput ( iu2zxy1bg0 -> _mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal (
localDW -> dfhhcydsof . AQHandles , localDW -> dfhhcydsof . SlioLTF , 0 ,
rtmGetTaskTime ( iu2zxy1bg0 , 0 ) , ( void * ) & bth5edrrpr ) ; } } { if ( (
localDW -> jtkkjdqprf . AQHandles || localDW -> jtkkjdqprf . SlioLTF ) &&
ssGetLogOutput ( iu2zxy1bg0 -> _mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal (
localDW -> jtkkjdqprf . AQHandles , localDW -> jtkkjdqprf . SlioLTF , 0 ,
rtmGetTaskTime ( iu2zxy1bg0 , 0 ) , ( void * ) & ezxxoe0g3z ) ; } } { if ( (
localDW -> fgtuicwhwc . AQHandles || localDW -> fgtuicwhwc . SlioLTF ) &&
ssGetLogOutput ( iu2zxy1bg0 -> _mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal (
localDW -> fgtuicwhwc . AQHandles , localDW -> fgtuicwhwc . SlioLTF , 0 ,
rtmGetTaskTime ( iu2zxy1bg0 , 0 ) , ( void * ) & haabair13z ) ; } } { if ( (
localDW -> kpzmvqvw4f . AQHandles || localDW -> kpzmvqvw4f . SlioLTF ) &&
ssGetLogOutput ( iu2zxy1bg0 -> _mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal (
localDW -> kpzmvqvw4f . AQHandles , localDW -> kpzmvqvw4f . SlioLTF , 0 ,
rtmGetTaskTime ( iu2zxy1bg0 , 0 ) , ( void * ) & cjpq4sbzb4 ) ; } } utAssert
( ajghr3ctyr . P_2 < * j5ofsry4is ) ; { if ( ( localDW -> ln45a3lme1 .
AQHandles || localDW -> ln45a3lme1 . SlioLTF ) && ssGetLogOutput ( iu2zxy1bg0
-> _mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal ( localDW -> ln45a3lme1 .
AQHandles , localDW -> ln45a3lme1 . SlioLTF , 0 , rtmGetTaskTime ( iu2zxy1bg0
, 0 ) , ( void * ) ggzreh1sbs ) ; } } } void LKARefMdlTID1 ( llf3xg3ir0 *
localB ) { localB -> kril0wyeg3 = ( real32_T ) ajghr3ctyr . P_1 ; localB ->
fbs4tfm210 = ( real32_T ) ajghr3ctyr . P_0 ; if ( ajghr3ctyr . P_51 != 0.0F )
{ localB -> odjgtv4pzb = ajghr3ctyr . P_50 ; } else { localB -> odjgtv4pzb =
ajghr3ctyr . P_52 ; } localB -> d1uo5hrcw0 = ( ajghr3ctyr . P_62 + ajghr3ctyr
. P_63 ) * ajghr3ctyr . P_64 ; localB -> pfdh1l3ror = ( ajghr3ctyr . P_67 *
ajghr3ctyr . P_63 - ajghr3ctyr . P_66 * ajghr3ctyr . P_62 ) * ajghr3ctyr .
P_68 ; localB -> lv4o50mg5y = ( ajghr3ctyr . P_66 * ajghr3ctyr . P_66 *
ajghr3ctyr . P_62 + ajghr3ctyr . P_67 * ajghr3ctyr . P_67 * ajghr3ctyr . P_63
) * ajghr3ctyr . P_70 ; localB -> ach0dqbfpm = ajghr3ctyr . P_63 / ajghr3ctyr
. P_65 * ajghr3ctyr . P_71 ; localB -> i0l5pfyvd3 = ajghr3ctyr . P_63 *
ajghr3ctyr . P_67 / ajghr3ctyr . P_69 * ajghr3ctyr . P_72 ; } void i30xuqpc24
( llf3xg3ir0 * localB , j4ytv2gj5l * localDW ) { int32_T i ; memcpy ( &
localDW -> enqs1wotqd [ 0 ] , & localB -> o5pj2sk15l [ 0 ] , 126U * sizeof (
boolean_T ) ) ; localDW -> c20jlygsay = localB -> iae25d40vx ; localDW ->
hryujm23gv = localB -> nfr45zfsgr ; localDW -> idw3weirf3 = localB ->
hbjo123h1b ; localDW -> ayeaqphirh = localB -> mmcgmfp2o3 ; for ( i = 0 ; i <
5 ; i ++ ) { localDW -> cf5jrvxca5 [ i ] = localB -> loumcs1pnk [ i ] ; }
localDW -> kxvvsjr51z = localB -> pv0cqe5xzb ; memcpy ( & localDW ->
fowmhxaqij [ 0 ] , & localB -> a2usnvldsr [ 0 ] , 25U * sizeof ( real32_T ) )
; localDW -> jx11wd5i0n [ 0 ] = localDW -> jx11wd5i0n [ 1 ] ; localDW ->
jx11wd5i0n [ 1 ] = localDW -> jx11wd5i0n [ 2 ] ; localDW -> jx11wd5i0n [ 2 ]
= localDW -> jx11wd5i0n [ 3 ] ; localDW -> jx11wd5i0n [ 3 ] = localDW ->
jx11wd5i0n [ 4 ] ; localDW -> jx11wd5i0n [ 4 ] = localB -> ks4nioygh5 ;
localDW -> mbmtbdjeqm = localB -> bgyuap3dxu ; } void i30xuqpc24TID1 ( void )
{ } void cpebt4uidm ( a0qef2fbcm * const iu2zxy1bg0 , j4ytv2gj5l * localDW )
{ if ( ( ssGetSimMode ( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL )
&& ( ( iu2zxy1bg0 -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if ( localDW -> d0ox53zfja .
AQHandles ) { sdiTerminateStreaming ( & localDW -> d0ox53zfja . AQHandles ) ;
} if ( localDW -> d0ox53zfja . SlioLTF ) { rtwDestructAccessorPointer (
localDW -> d0ox53zfja . SlioLTF ) ; } } if ( ( ssGetSimMode ( iu2zxy1bg0 ->
_mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( iu2zxy1bg0 -> _mdlRefSfcnS )
-> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if (
localDW -> dpmuujlupa . AQHandles ) { sdiTerminateStreaming ( & localDW ->
dpmuujlupa . AQHandles ) ; } if ( localDW -> dpmuujlupa . SlioLTF ) {
rtwDestructAccessorPointer ( localDW -> dpmuujlupa . SlioLTF ) ; } } if ( (
ssGetSimMode ( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
iu2zxy1bg0 -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if ( localDW -> igap1wnipb .
AQHandles ) { sdiTerminateStreaming ( & localDW -> igap1wnipb . AQHandles ) ;
} if ( localDW -> igap1wnipb . SlioLTF ) { rtwDestructAccessorPointer (
localDW -> igap1wnipb . SlioLTF ) ; } } if ( ( ssGetSimMode ( iu2zxy1bg0 ->
_mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( iu2zxy1bg0 -> _mdlRefSfcnS )
-> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if (
localDW -> dfhhcydsof . AQHandles ) { sdiTerminateStreaming ( & localDW ->
dfhhcydsof . AQHandles ) ; } if ( localDW -> dfhhcydsof . SlioLTF ) {
rtwDestructAccessorPointer ( localDW -> dfhhcydsof . SlioLTF ) ; } } if ( (
ssGetSimMode ( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
iu2zxy1bg0 -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if ( localDW -> jtkkjdqprf .
AQHandles ) { sdiTerminateStreaming ( & localDW -> jtkkjdqprf . AQHandles ) ;
} if ( localDW -> jtkkjdqprf . SlioLTF ) { rtwDestructAccessorPointer (
localDW -> jtkkjdqprf . SlioLTF ) ; } } if ( ( ssGetSimMode ( iu2zxy1bg0 ->
_mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( iu2zxy1bg0 -> _mdlRefSfcnS )
-> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if (
localDW -> fgtuicwhwc . AQHandles ) { sdiTerminateStreaming ( & localDW ->
fgtuicwhwc . AQHandles ) ; } if ( localDW -> fgtuicwhwc . SlioLTF ) {
rtwDestructAccessorPointer ( localDW -> fgtuicwhwc . SlioLTF ) ; } } if ( (
ssGetSimMode ( iu2zxy1bg0 -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
iu2zxy1bg0 -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if ( localDW -> kpzmvqvw4f .
AQHandles ) { sdiTerminateStreaming ( & localDW -> kpzmvqvw4f . AQHandles ) ;
} if ( localDW -> kpzmvqvw4f . SlioLTF ) { rtwDestructAccessorPointer (
localDW -> kpzmvqvw4f . SlioLTF ) ; } } if ( ( ssGetSimMode ( iu2zxy1bg0 ->
_mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( iu2zxy1bg0 -> _mdlRefSfcnS )
-> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if (
localDW -> ln45a3lme1 . AQHandles ) { sdiTerminateStreaming ( & localDW ->
ln45a3lme1 . AQHandles ) ; } if ( localDW -> ln45a3lme1 . SlioLTF ) {
rtwDestructAccessorPointer ( localDW -> ln45a3lme1 . SlioLTF ) ; } } if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( iu2zxy1bg0 ->
_mdlRefSfcnS , "LKARefMdl" , "SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ;
} } void c1o4boxk4f ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , a0qef2fbcm * const iu2zxy1bg0 , llf3xg3ir0 * localB ,
j4ytv2gj5l * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T )
) ; ( void ) memset ( ( void * ) iu2zxy1bg0 , 0 , sizeof ( a0qef2fbcm ) ) ;
iu2zxy1bg0 -> Timing . mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; iu2zxy1bg0 ->
Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; iu2zxy1bg0 -> _mdlRefSfcnS =
( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( iu2zxy1bg0 -> _mdlRefSfcnS , "LKARefMdl" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } ( void ) memset ( ( ( void *
) localB ) , 0 , sizeof ( llf3xg3ir0 ) ) ; { int32_T i ; for ( i = 0 ; i < 5
; i ++ ) { localB -> loumcs1pnk [ i ] = 0.0F ; } for ( i = 0 ; i < 25 ; i ++
) { localB -> a2usnvldsr [ i ] = 0.0F ; } localB -> iae25d40vx = 0.0F ;
localB -> nfr45zfsgr = 0.0F ; localB -> mmcgmfp2o3 = 0.0F ; localB ->
hbjo123h1b = 0.0F ; localB -> kril0wyeg3 = 0.0F ; localB -> fbs4tfm210 = 0.0F
; localB -> odjgtv4pzb = 0.0F ; localB -> d1uo5hrcw0 = 0.0F ; localB ->
pfdh1l3ror = 0.0F ; localB -> lv4o50mg5y = 0.0F ; localB -> ach0dqbfpm = 0.0F
; localB -> i0l5pfyvd3 = 0.0F ; localB -> ks4nioygh5 = 0.0F ; localB ->
pv0cqe5xzb = 0.0F ; } ( void ) memset ( ( void * ) localDW , 0 , sizeof (
j4ytv2gj5l ) ) ; localDW -> c20jlygsay = 0.0F ; localDW -> hryujm23gv = 0.0F
; localDW -> idw3weirf3 = 0.0F ; localDW -> ayeaqphirh = 0.0F ; localDW ->
kxvvsjr51z = 0.0F ; { int32_T i ; for ( i = 0 ; i < 5 ; i ++ ) { localDW ->
jx11wd5i0n [ i ] = 0.0F ; } } { int32_T i ; for ( i = 0 ; i < 5 ; i ++ ) {
localDW -> cf5jrvxca5 [ i ] = 0.0F ; } } { int32_T i ; for ( i = 0 ; i < 25 ;
i ++ ) { localDW -> fowmhxaqij [ i ] = 0.0F ; } }
LKARefMdl_InitializeDataMapInfo ( iu2zxy1bg0 , localDW , sysRanPtr ,
contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL
) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & (
iu2zxy1bg0 -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( iu2zxy1bg0 ->
DataMapInfo . mmi , rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex (
iu2zxy1bg0 -> DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_LKARefMdl_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo = false ;
ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if (
regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS
, modelName , rtMdlInfo_LKARefMdl , 49 ) ; * retVal = 1 ; } static void
mr_LKARefMdl_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) ; static void
mr_LKARefMdl_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_LKARefMdl_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_LKARefMdl_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_LKARefMdl_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_LKARefMdl_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j
, uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_LKARefMdl_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) ; static uint_T
mr_LKARefMdl_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_LKARefMdl_cacheDataToMxArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_LKARefMdl_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_LKARefMdl_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_LKARefMdl_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_LKARefMdl_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_LKARefMdl_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_LKARefMdl_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_LKARefMdl_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) { const
uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber (
srcArray , i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u
) ; } mxArray * mr_LKARefMdl_GetDWork ( const c5e02tcafze * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" ,
} ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_LKARefMdl_cacheDataAsMxArray ( ssDW , 0 , 0 , & ( mdlrefDW -> rtb ) ,
sizeof ( mdlrefDW -> rtb ) ) ; { static const char * rtdwDataFieldNames [ 14
] = { "mdlrefDW->rtdw.c20jlygsay" , "mdlrefDW->rtdw.hryujm23gv" ,
"mdlrefDW->rtdw.idw3weirf3" , "mdlrefDW->rtdw.ayeaqphirh" ,
"mdlrefDW->rtdw.kxvvsjr51z" , "mdlrefDW->rtdw.jx11wd5i0n" ,
"mdlrefDW->rtdw.cf5jrvxca5" , "mdlrefDW->rtdw.fowmhxaqij" ,
"mdlrefDW->rtdw.mbmtbdjeqm" , "mdlrefDW->rtdw.jeftpncfv5" ,
"mdlrefDW->rtdw.lrava23ncm" , "mdlrefDW->rtdw.hiiwcrboab" ,
"mdlrefDW->rtdw.hwadutcumr" , "mdlrefDW->rtdw.enqs1wotqd" , } ; mxArray *
rtdwData = mxCreateStructMatrix ( 1 , 1 , 14 , rtdwDataFieldNames ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 0 , & ( mdlrefDW -> rtdw .
c20jlygsay ) , sizeof ( mdlrefDW -> rtdw . c20jlygsay ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 1 , & ( mdlrefDW -> rtdw .
hryujm23gv ) , sizeof ( mdlrefDW -> rtdw . hryujm23gv ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 2 , & ( mdlrefDW -> rtdw .
idw3weirf3 ) , sizeof ( mdlrefDW -> rtdw . idw3weirf3 ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 3 , & ( mdlrefDW -> rtdw .
ayeaqphirh ) , sizeof ( mdlrefDW -> rtdw . ayeaqphirh ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 4 , & ( mdlrefDW -> rtdw .
kxvvsjr51z ) , sizeof ( mdlrefDW -> rtdw . kxvvsjr51z ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 5 , & ( mdlrefDW -> rtdw .
jx11wd5i0n ) , sizeof ( mdlrefDW -> rtdw . jx11wd5i0n ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 6 , & ( mdlrefDW -> rtdw .
cf5jrvxca5 ) , sizeof ( mdlrefDW -> rtdw . cf5jrvxca5 ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 7 , & ( mdlrefDW -> rtdw .
fowmhxaqij ) , sizeof ( mdlrefDW -> rtdw . fowmhxaqij ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 8 , & ( mdlrefDW -> rtdw .
mbmtbdjeqm ) , sizeof ( mdlrefDW -> rtdw . mbmtbdjeqm ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 9 , & ( mdlrefDW -> rtdw .
jeftpncfv5 ) , sizeof ( mdlrefDW -> rtdw . jeftpncfv5 ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 10 , & ( mdlrefDW -> rtdw .
lrava23ncm ) , sizeof ( mdlrefDW -> rtdw . lrava23ncm ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 11 , & ( mdlrefDW -> rtdw .
hiiwcrboab ) , sizeof ( mdlrefDW -> rtdw . hiiwcrboab ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 12 , & ( mdlrefDW -> rtdw .
hwadutcumr ) , sizeof ( mdlrefDW -> rtdw . hwadutcumr ) ) ;
mr_LKARefMdl_cacheDataAsMxArray ( rtdwData , 0 , 13 , & ( mdlrefDW -> rtdw .
enqs1wotqd ) , sizeof ( mdlrefDW -> rtdw . enqs1wotqd ) ) ;
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_LKARefMdl_SetDWork ( c5e02tcafze * mdlrefDW , const mxArray * ssDW ) {
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtb ) , ssDW , 0 , 0 ,
sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ; mr_LKARefMdl_restoreDataFromMxArray ( &
( mdlrefDW -> rtdw . c20jlygsay ) , rtdwData , 0 , 0 , sizeof ( mdlrefDW ->
rtdw . c20jlygsay ) ) ; mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW ->
rtdw . hryujm23gv ) , rtdwData , 0 , 1 , sizeof ( mdlrefDW -> rtdw .
hryujm23gv ) ) ; mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
idw3weirf3 ) , rtdwData , 0 , 2 , sizeof ( mdlrefDW -> rtdw . idw3weirf3 ) )
; mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ayeaqphirh ) ,
rtdwData , 0 , 3 , sizeof ( mdlrefDW -> rtdw . ayeaqphirh ) ) ;
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . kxvvsjr51z ) ,
rtdwData , 0 , 4 , sizeof ( mdlrefDW -> rtdw . kxvvsjr51z ) ) ;
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . jx11wd5i0n ) ,
rtdwData , 0 , 5 , sizeof ( mdlrefDW -> rtdw . jx11wd5i0n ) ) ;
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . cf5jrvxca5 ) ,
rtdwData , 0 , 6 , sizeof ( mdlrefDW -> rtdw . cf5jrvxca5 ) ) ;
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . fowmhxaqij ) ,
rtdwData , 0 , 7 , sizeof ( mdlrefDW -> rtdw . fowmhxaqij ) ) ;
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . mbmtbdjeqm ) ,
rtdwData , 0 , 8 , sizeof ( mdlrefDW -> rtdw . mbmtbdjeqm ) ) ;
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . jeftpncfv5 ) ,
rtdwData , 0 , 9 , sizeof ( mdlrefDW -> rtdw . jeftpncfv5 ) ) ;
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . lrava23ncm ) ,
rtdwData , 0 , 10 , sizeof ( mdlrefDW -> rtdw . lrava23ncm ) ) ;
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . hiiwcrboab ) ,
rtdwData , 0 , 11 , sizeof ( mdlrefDW -> rtdw . hiiwcrboab ) ) ;
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . hwadutcumr ) ,
rtdwData , 0 , 12 , sizeof ( mdlrefDW -> rtdw . hwadutcumr ) ) ;
mr_LKARefMdl_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . enqs1wotqd ) ,
rtdwData , 0 , 13 , sizeof ( mdlrefDW -> rtdw . enqs1wotqd ) ) ; } } void
mr_LKARefMdl_RegisterSimStateChecksum ( SimStruct * S ) { const uint32_T
chksum [ 4 ] = { 1284009828U , 2908807798U , 1661408964U , 3914369116U , } ;
slmrModelRefRegisterSimStateChecksum ( S , "LKARefMdl" , & chksum [ 0 ] ) ; }
mxArray * mr_LKARefMdl_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 1 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 1 ] = { "Assertion" , } ; static const char * blockPath [
1 ] = {
 "LKARefMdl/Lane Keeping Controller/Longitudinal velocity must be positive/Assertion"
, } ; static const int reason [ 1 ] = { 0 , } ; for ( subs [ 0 ] = 0 ; subs [
0 ] < 1 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateString ( blockType [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateString ( blockPath [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 2 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateDoubleScalar ( ( double ) reason [ subs [ 0 ] ] ) ) ; } } return data
; }
