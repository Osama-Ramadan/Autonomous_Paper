#include "rtwtypes.h"
#include "multiword_types.h"
#include "kron_Ttkz0gFO.h"

void kron_Ttkz0gFO(const real32_T b_A[900], real32_T b_B, real32_T K[900])
{
  int32_T kidx;
  int32_T b_j1;
  int32_T i1;
  kidx = -1;
  for (b_j1 = 0; b_j1 < 30; b_j1++) {
    for (i1 = 0; i1 < 30; i1++) {
      kidx++;
      K[kidx] = b_A[30 * b_j1 + i1] * b_B;
    }
  }
}
