#ifndef SHARE_mpc_calculatehessian_9zqei9Pk
#define SHARE_mpc_calculatehessian_9zqei9Pk
#include "rtwtypes.h"
#include "multiword_types.h"

extern void mpc_calculatehessian_9zqei9Pk(const real32_T b_Wy[2], real32_T b_Wu,
  real32_T b_Wdu, const real32_T b_SuJm[180], const real32_T I2Jm[90], const
  real32_T b_Jm[90], const real32_T b_I1[30], const real32_T b_Su1[60], const
  real32_T b_Sx[300], const real32_T b_Hv[3720], real32_T b_H[9], real32_T
  b_Ku1[3], real32_T b_Kut[90], real32_T b_Kx[15], real32_T b_Kv[186], real32_T
  b_Kr[180]);

#endif
