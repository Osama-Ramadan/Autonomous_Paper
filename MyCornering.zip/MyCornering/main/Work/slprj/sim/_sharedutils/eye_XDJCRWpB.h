#ifndef SHARE_eye_XDJCRWpB
#define SHARE_eye_XDJCRWpB
#include "rtwtypes.h"
#include "multiword_types.h"

extern void eye_XDJCRWpB(real32_T I[16]);

#endif
