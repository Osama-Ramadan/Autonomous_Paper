

        /*
      * C:\Users\am2114\MATLAB\Projects\MyCornering\main\Work\slprj\sim\_sharedutils\look2_binlcapw.h
      * 
        * Academic License - for use in teaching, academic research, and meeting
* course requirements at degree granting institutions only.  Not for
* government, commercial, or other organizational use. 
  * 
  * Code generation for model "ISReferenceApplication_acc".
  *
  * Model version              : 1.155
  * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
  * C source code generated on : Tue Feb  5 20:41:23 2019
      * Created for block: ISReferenceApplication_acc
      */


    

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

        #ifndef SHARE_look2_binlcapw
      #define SHARE_look2_binlcapw

     
      #include "rtwtypes.h"
        #include "multiword_types.h"
      
            extern real_T look2_binlcapw(real_T u0, real_T u1, const real_T bp0[], const real_T bp1[], const real_T table[], const uint32_T maxIndex[], uint32_T stride);

            
      #endif


  

  

  

  
