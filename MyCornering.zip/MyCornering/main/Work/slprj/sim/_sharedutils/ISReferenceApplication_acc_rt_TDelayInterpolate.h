

        /*
      * C:\Users\am2114\MATLAB\Projects\MyCornering\main\Work\slprj\sim\_sharedutils\ISReferenceApplication_acc_rt_TDelayInterpolate.h
      * 
        * Academic License - for use in teaching, academic research, and meeting
* course requirements at degree granting institutions only.  Not for
* government, commercial, or other organizational use. 
  * 
  * Code generation for model "ISReferenceApplication_acc".
  *
  * Model version              : 1.155
  * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
  * C source code generated on : Tue Feb  5 20:41:23 2019
      * Created for block: <Root>/B_10_0
      */


    

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

        #ifndef SHARE_ISReferenceApplication_acc_rt_TDelayInterpolate
      #define SHARE_ISReferenceApplication_acc_rt_TDelayInterpolate

     
      #include "rtwtypes.h"
        #include "multiword_types.h"
      
                    real_T ISReferenceApplication_acc_rt_TDelayInterpolate(
      real_T     tMinusDelay,           /* tMinusDelay = currentSimTime - delay */
      real_T     tStart,
      real_T     *tBuf,
      real_T     *uBuf,
      int_T      bufSz,
      int_T      *lastIdx,
      int_T      oldestIdx,
      int_T      newIdx,
      real_T     initOutput,
      boolean_T  discrete,
      boolean_T  minorStepAndTAtLastMajorOutput)
;

            
      #endif


  

  

  

  
