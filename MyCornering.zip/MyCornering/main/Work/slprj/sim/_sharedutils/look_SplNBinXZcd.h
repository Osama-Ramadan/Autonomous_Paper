#ifndef SHARE_look_SplNBinXZcd
#define SHARE_look_SplNBinXZcd
#include "rtwtypes.h"
#include "multiword_types.h"
#include "rtsplntypes.h"

real_T look_SplNBinXZcd(uint32_T numDims, const real_T* u, const
  rt_LUTSplineWork * const SWork);

#endif
