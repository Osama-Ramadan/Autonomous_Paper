#ifndef SHARE_mpc_solveQP_tAv4OttS
#define SHARE_mpc_solveQP_tAv4OttS
#include "rtwtypes.h"
#include "multiword_types.h"

extern void mpc_solveQP_tAv4OttS(const real32_T xQP[5], const real32_T b_Kx[15],
  const real32_T b_Kr[180], const real32_T rseq[60], const real32_T b_Ku1[3],
  real32_T old_u, const real32_T b_Kv[186], const real32_T vseq[62], const
  real32_T b_Kut[90], const real32_T b_utarget[30], const real32_T b_Linv[16],
  const real32_T b_Hinv[16], const real32_T b_Ac[504], const real32_T Bc[126],
  boolean_T iA[126], real32_T zopt[4], real32_T f[4], real32_T *status);

#endif
