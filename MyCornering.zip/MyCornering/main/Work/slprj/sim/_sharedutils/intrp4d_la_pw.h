#ifndef SHARE_intrp4d_la_pw
#define SHARE_intrp4d_la_pw
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T intrp4d_la_pw(const uint32_T bpIndex[], const real_T frac[], const
  real_T table[], const uint32_T stride[], const uint32_T maxIndex[]);

#endif
