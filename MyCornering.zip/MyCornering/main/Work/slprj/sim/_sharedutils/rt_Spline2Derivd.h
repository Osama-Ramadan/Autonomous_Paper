#ifndef SHARE_rt_Spline2Derivd
#define SHARE_rt_Spline2Derivd
#include "rtwtypes.h"
#include "multiword_types.h"
#include "rtsplntypes.h"

void rt_Spline2Derivd(const real_T *x, const real_T *y, uint32_T n, real_T *u,
                      real_T *y2);

#endif
