#include "rtwtypes.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "abs_fYOsikuQ.h"

void abs_fYOsikuQ(const real32_T x[4], real32_T y[4])
{
  y[0] = muSingleScalarAbs(x[0]);
  y[1] = muSingleScalarAbs(x[1]);
  y[2] = muSingleScalarAbs(x[2]);
  y[3] = muSingleScalarAbs(x[3]);
}
