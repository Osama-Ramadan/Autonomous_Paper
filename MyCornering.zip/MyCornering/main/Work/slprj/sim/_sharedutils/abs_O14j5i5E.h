#ifndef SHARE_abs_O14j5i5E
#define SHARE_abs_O14j5i5E
#include "rtwtypes.h"
#include "multiword_types.h"

extern void abs_O14j5i5E(const real32_T x[126], real32_T y[126]);

#endif
