#include "rtwtypes.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "mrdivide_fJHemlFH.h"

void mrdivide_fJHemlFH(const real32_T b_A[4], const real32_T b_B[4], real32_T y
  [4])
{
  int32_T r1;
  int32_T r2;
  real32_T a21;
  real32_T a22;
  if (muSingleScalarAbs(b_B[1]) > muSingleScalarAbs(b_B[0])) {
    r1 = 1;
    r2 = 0;
  } else {
    r1 = 0;
    r2 = 1;
  }

  a21 = b_B[r2] / b_B[r1];
  a22 = b_B[2 + r2] - b_B[2 + r1] * a21;
  y[r1 << 1] = b_A[0] / b_B[r1];
  y[r2 << 1] = (b_A[2] - y[r1 << 1] * b_B[2 + r1]) / a22;
  y[r1 << 1] -= y[r2 << 1] * a21;
  y[1 + (r1 << 1)] = b_A[1] / b_B[r1];
  y[1 + (r2 << 1)] = (b_A[3] - y[(r1 << 1) + 1] * b_B[2 + r1]) / a22;
  y[1 + (r1 << 1)] -= y[(r2 << 1) + 1] * a21;
}
