#include "rtwtypes.h"
#include "multiword_types.h"
#include "Unconstrained_FkjPfzZn.h"

void Unconstrained_FkjPfzZn(const real32_T b_Hinv[16], const real32_T f[4],
  real32_T x[4], int16_T n)
{
  int16_T i;
  int32_T tmp;
  for (i = 1; i <= n; i++) {
    tmp = i - 1;
    x[tmp] = ((-b_Hinv[tmp] * f[0] + -b_Hinv[i + 3] * f[1]) + -b_Hinv[i + 7] *
              f[2]) + -b_Hinv[i + 11] * f[3];
  }
}
