#include "rtwtypes.h"
#include "multiword_types.h"
#include "linsolve_EyNVDqi8.h"

void linsolve_EyNVDqi8(const real32_T b_A[16], const real32_T b_B[16], real32_T
  b_C[16])
{
  int32_T jBcol;
  int32_T b_i;
  int32_T j;
  j = 0;
  for (jBcol = 0; jBcol < 4; jBcol++) {
    b_C[j] = b_B[j];
    b_C[j + 1] = b_B[j + 1];
    b_C[j + 2] = b_B[j + 2];
    b_C[j + 3] = b_B[j + 3];
    j += 4;
  }

  for (j = 0; j < 4; j++) {
    jBcol = j << 2;
    if (b_C[jBcol] != 0.0F) {
      b_C[jBcol] /= b_A[0];
      for (b_i = 1; b_i + 1 < 5; b_i++) {
        b_C[b_i + jBcol] -= b_C[jBcol] * b_A[b_i];
      }
    }

    if (b_C[1 + jBcol] != 0.0F) {
      b_C[1 + jBcol] /= b_A[5];
      for (b_i = 2; b_i + 1 < 5; b_i++) {
        b_C[b_i + jBcol] -= b_C[1 + jBcol] * b_A[b_i + 4];
      }
    }

    if (b_C[2 + jBcol] != 0.0F) {
      b_C[2 + jBcol] /= b_A[10];
      for (b_i = 3; b_i + 1 < 5; b_i++) {
        b_C[b_i + jBcol] -= b_C[2 + jBcol] * b_A[b_i + 8];
      }
    }

    if (b_C[3 + jBcol] != 0.0F) {
      b_C[3 + jBcol] /= b_A[15];
    }
  }
}
