#include "rtwtypes.h"
#include "multiword_types.h"
#include "DropConstraint_o4UFUics.h"

void DropConstraint_o4UFUics(int16_T kDrop, int16_T iA[126], int16_T *nA,
  int16_T iC[126])
{
  int16_T i;
  int32_T tmp;
  iA[iC[kDrop - 1] - 1] = 0;
  if (kDrop < *nA) {
    tmp = *nA - 1;
    if (tmp < -32768) {
      tmp = -32768;
    }

    for (i = kDrop; i <= (int16_T)tmp; i++) {
      iC[i - 1] = iC[i];
    }
  }

  iC[*nA - 1] = 0;
  tmp = *nA - 1;
  if (tmp < -32768) {
    tmp = -32768;
  }

  *nA = (int16_T)tmp;
}
