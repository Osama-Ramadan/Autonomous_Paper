#ifndef SHARE_look1_binlxpw
#define SHARE_look1_binlxpw
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T look1_binlxpw(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);

#endif
