#ifndef SHARE_plook_binca
#define SHARE_plook_binca
#include "rtwtypes.h"
#include "multiword_types.h"

extern uint32_T plook_binca(real_T u, const real_T bp[], uint32_T maxIndex,
  real_T *fraction);

#endif
