#include "rtwtypes.h"
#include "multiword_types.h"
#include "WtMult_gmFjAWwm.h"

void WtMult_gmFjAWwm(real32_T W, const real32_T M[90], real32_T WM[90])
{
  int32_T i;
  int32_T i_p;
  int32_T tmp;
  int32_T WM_tmp;
  tmp = 0;
  for (i_p = 0; i_p < 3; i_p++) {
    for (i = 0; i < 30; i++) {
      WM_tmp = i + tmp;
      WM[WM_tmp] = M[WM_tmp] * W;
    }

    tmp += 30;
  }
}
