#include "rtwtypes.h"
#include "multiword_types.h"
#include <string.h>
#include "mwmathutil.h"
#include "xgemv_DYPMFhqP.h"
#include "xger_GB2Nboiy.h"
#include "xnrm2_TkIx4GfZ.h"
#include "qr_RqJKUjob.h"

void qr_RqJKUjob(const real32_T b_A[16], real32_T Q[16], real32_T R[16])
{
  real32_T c_A[16];
  real32_T work[4];
  real32_T atmp;
  real32_T xnorm;
  int32_T knt;
  int32_T lastc;
  int32_T coltop;
  int32_T b_coltop;
  real32_T tau_idx_0;
  real32_T tau_idx_1;
  real32_T tau_idx_2;
  int32_T exitg1;
  boolean_T exitg2;
  memcpy(&c_A[0], &b_A[0], sizeof(real32_T) << 4U);
  work[0] = 0.0F;
  work[1] = 0.0F;
  work[2] = 0.0F;
  work[3] = 0.0F;
  atmp = c_A[0];
  tau_idx_0 = 0.0F;
  xnorm = xnrm2_TkIx4GfZ(3, c_A, 2);
  if (xnorm != 0.0F) {
    xnorm = muSingleScalarHypot(c_A[0], xnorm);
    if (c_A[0] >= 0.0F) {
      xnorm = -xnorm;
    }

    if (muSingleScalarAbs(xnorm) < 9.86076132E-32F) {
      knt = 0;
      do {
        knt++;
        for (lastc = 1; lastc < 4; lastc++) {
          c_A[lastc] *= 1.01412048E+31F;
        }

        xnorm *= 1.01412048E+31F;
        atmp *= 1.01412048E+31F;
      } while (!(muSingleScalarAbs(xnorm) >= 9.86076132E-32F));

      xnorm = muSingleScalarHypot(atmp, xnrm2_TkIx4GfZ(3, c_A, 2));
      if (atmp >= 0.0F) {
        xnorm = -xnorm;
      }

      tau_idx_0 = (xnorm - atmp) / xnorm;
      atmp = 1.0F / (atmp - xnorm);
      for (lastc = 1; lastc < 4; lastc++) {
        c_A[lastc] *= atmp;
      }

      for (lastc = 1; lastc <= knt; lastc++) {
        xnorm *= 9.86076132E-32F;
      }

      atmp = xnorm;
    } else {
      tau_idx_0 = (xnorm - c_A[0]) / xnorm;
      atmp = 1.0F / (c_A[0] - xnorm);
      for (knt = 1; knt < 4; knt++) {
        c_A[knt] *= atmp;
      }

      atmp = xnorm;
    }
  }

  c_A[0] = 1.0F;
  if (tau_idx_0 != 0.0F) {
    knt = 4;
    lastc = 3;
    while ((knt > 0) && (c_A[lastc] == 0.0F)) {
      knt--;
      lastc--;
    }

    lastc = 3;
    exitg2 = false;
    while ((!exitg2) && (lastc > 0)) {
      coltop = ((lastc - 1) << 2) + 5;
      b_coltop = coltop;
      do {
        exitg1 = 0;
        if (b_coltop <= (coltop + knt) - 1) {
          if (c_A[b_coltop - 1] != 0.0F) {
            exitg1 = 1;
          } else {
            b_coltop++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_DYPMFhqP(knt, lastc, c_A, 5, c_A, 1, work);
    xger_GB2Nboiy(knt, lastc, -tau_idx_0, 1, work, c_A, 5);
  }

  c_A[0] = atmp;
  atmp = c_A[5];
  tau_idx_1 = 0.0F;
  xnorm = xnrm2_TkIx4GfZ(2, c_A, 7);
  if (xnorm != 0.0F) {
    xnorm = muSingleScalarHypot(c_A[5], xnorm);
    if (c_A[5] >= 0.0F) {
      xnorm = -xnorm;
    }

    if (muSingleScalarAbs(xnorm) < 9.86076132E-32F) {
      knt = 0;
      do {
        knt++;
        for (lastc = 6; lastc < 8; lastc++) {
          c_A[lastc] *= 1.01412048E+31F;
        }

        xnorm *= 1.01412048E+31F;
        atmp *= 1.01412048E+31F;
      } while (!(muSingleScalarAbs(xnorm) >= 9.86076132E-32F));

      xnorm = muSingleScalarHypot(atmp, xnrm2_TkIx4GfZ(2, c_A, 7));
      if (atmp >= 0.0F) {
        xnorm = -xnorm;
      }

      tau_idx_1 = (xnorm - atmp) / xnorm;
      atmp = 1.0F / (atmp - xnorm);
      for (lastc = 6; lastc < 8; lastc++) {
        c_A[lastc] *= atmp;
      }

      for (lastc = 1; lastc <= knt; lastc++) {
        xnorm *= 9.86076132E-32F;
      }

      atmp = xnorm;
    } else {
      tau_idx_1 = (xnorm - c_A[5]) / xnorm;
      atmp = 1.0F / (c_A[5] - xnorm);
      for (knt = 6; knt < 8; knt++) {
        c_A[knt] *= atmp;
      }

      atmp = xnorm;
    }
  }

  c_A[5] = 1.0F;
  if (tau_idx_1 != 0.0F) {
    knt = 3;
    lastc = 7;
    while ((knt > 0) && (c_A[lastc] == 0.0F)) {
      knt--;
      lastc--;
    }

    lastc = 2;
    exitg2 = false;
    while ((!exitg2) && (lastc > 0)) {
      coltop = ((lastc - 1) << 2) + 10;
      b_coltop = coltop;
      do {
        exitg1 = 0;
        if (b_coltop <= (coltop + knt) - 1) {
          if (c_A[b_coltop - 1] != 0.0F) {
            exitg1 = 1;
          } else {
            b_coltop++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_DYPMFhqP(knt, lastc, c_A, 10, c_A, 6, work);
    xger_GB2Nboiy(knt, lastc, -tau_idx_1, 6, work, c_A, 10);
  }

  c_A[5] = atmp;
  atmp = c_A[10];
  tau_idx_2 = 0.0F;
  xnorm = xnrm2_TkIx4GfZ(1, c_A, 12);
  if (xnorm != 0.0F) {
    xnorm = muSingleScalarHypot(c_A[10], xnorm);
    if (c_A[10] >= 0.0F) {
      xnorm = -xnorm;
    }

    if (muSingleScalarAbs(xnorm) < 9.86076132E-32F) {
      knt = 0;
      do {
        knt++;
        for (lastc = 11; lastc < 12; lastc++) {
          c_A[lastc] *= 1.01412048E+31F;
        }

        xnorm *= 1.01412048E+31F;
        atmp *= 1.01412048E+31F;
      } while (!(muSingleScalarAbs(xnorm) >= 9.86076132E-32F));

      xnorm = muSingleScalarHypot(atmp, xnrm2_TkIx4GfZ(1, c_A, 12));
      if (atmp >= 0.0F) {
        xnorm = -xnorm;
      }

      tau_idx_2 = (xnorm - atmp) / xnorm;
      atmp = 1.0F / (atmp - xnorm);
      for (lastc = 11; lastc < 12; lastc++) {
        c_A[lastc] *= atmp;
      }

      for (lastc = 1; lastc <= knt; lastc++) {
        xnorm *= 9.86076132E-32F;
      }

      atmp = xnorm;
    } else {
      tau_idx_2 = (xnorm - c_A[10]) / xnorm;
      atmp = 1.0F / (c_A[10] - xnorm);
      for (knt = 11; knt < 12; knt++) {
        c_A[knt] *= atmp;
      }

      atmp = xnorm;
    }
  }

  c_A[10] = 1.0F;
  if (tau_idx_2 != 0.0F) {
    knt = 2;
    lastc = 11;
    while ((knt > 0) && (c_A[lastc] == 0.0F)) {
      knt--;
      lastc--;
    }

    lastc = 1;
    b_coltop = 15;
    do {
      exitg1 = 0;
      if (b_coltop <= knt + 14) {
        if (c_A[b_coltop - 1] != 0.0F) {
          exitg1 = 1;
        } else {
          b_coltop++;
        }
      } else {
        lastc = 0;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_DYPMFhqP(knt, lastc, c_A, 15, c_A, 11, work);
    xger_GB2Nboiy(knt, lastc, -tau_idx_2, 11, work, c_A, 15);
  }

  c_A[10] = atmp;
  for (knt = 0; knt < 1; knt++) {
    R[knt] = c_A[knt];
  }

  for (knt = 1; knt + 1 < 5; knt++) {
    R[knt] = 0.0F;
  }

  work[0] = 0.0F;
  for (knt = 0; knt < 2; knt++) {
    R[knt + 4] = c_A[knt + 4];
  }

  for (knt = 2; knt + 1 < 5; knt++) {
    R[knt + 4] = 0.0F;
  }

  work[1] = 0.0F;
  for (knt = 0; knt < 3; knt++) {
    R[knt + 8] = c_A[knt + 8];
  }

  for (knt = 3; knt + 1 < 5; knt++) {
    R[knt + 8] = 0.0F;
  }

  work[2] = 0.0F;
  for (knt = 0; knt < 4; knt++) {
    R[knt + 12] = c_A[knt + 12];
  }

  work[3] = 0.0F;
  c_A[15] = 1.0F;
  for (knt = 1; knt < 4; knt++) {
    c_A[15 - knt] = 0.0F;
  }

  c_A[10] = 1.0F;
  if (tau_idx_2 != 0.0F) {
    knt = 2;
    lastc = 11;
    while ((knt > 0) && (c_A[lastc] == 0.0F)) {
      knt--;
      lastc--;
    }

    lastc = 1;
    coltop = 11;
    do {
      exitg1 = 0;
      if (coltop + 4 <= knt + 14) {
        if (c_A[coltop + 3] != 0.0F) {
          exitg1 = 1;
        } else {
          coltop++;
        }
      } else {
        lastc = 0;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_DYPMFhqP(knt, lastc, c_A, 15, c_A, 11, work);
    xger_GB2Nboiy(knt, lastc, -tau_idx_2, 11, work, c_A, 15);
  }

  for (knt = 11; knt < 12; knt++) {
    c_A[knt] *= -tau_idx_2;
  }

  c_A[10] = 1.0F - tau_idx_2;
  for (knt = 1; knt < 3; knt++) {
    c_A[10 - knt] = 0.0F;
  }

  c_A[5] = 1.0F;
  if (tau_idx_1 != 0.0F) {
    knt = 3;
    lastc = 7;
    while ((knt > 0) && (c_A[lastc] == 0.0F)) {
      knt--;
      lastc--;
    }

    lastc = 2;
    exitg2 = false;
    while ((!exitg2) && (lastc > 0)) {
      b_coltop = ((lastc - 1) << 2) + 6;
      coltop = b_coltop;
      do {
        exitg1 = 0;
        if (coltop + 4 <= (b_coltop + knt) + 3) {
          if (c_A[coltop + 3] != 0.0F) {
            exitg1 = 1;
          } else {
            coltop++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_DYPMFhqP(knt, lastc, c_A, 10, c_A, 6, work);
    xger_GB2Nboiy(knt, lastc, -tau_idx_1, 6, work, c_A, 10);
  }

  for (knt = 6; knt < 8; knt++) {
    c_A[knt] *= -tau_idx_1;
  }

  c_A[5] = 1.0F - tau_idx_1;
  c_A[4] = 0.0F;
  c_A[0] = 1.0F;
  if (tau_idx_0 != 0.0F) {
    knt = 4;
    lastc = 3;
    while ((knt > 0) && (c_A[lastc] == 0.0F)) {
      knt--;
      lastc--;
    }

    lastc = 3;
    exitg2 = false;
    while ((!exitg2) && (lastc > 0)) {
      b_coltop = ((lastc - 1) << 2) + 1;
      coltop = b_coltop;
      do {
        exitg1 = 0;
        if (coltop + 4 <= (b_coltop + knt) + 3) {
          if (c_A[coltop + 3] != 0.0F) {
            exitg1 = 1;
          } else {
            coltop++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_DYPMFhqP(knt, lastc, c_A, 5, c_A, 1, work);
    xger_GB2Nboiy(knt, lastc, -tau_idx_0, 1, work, c_A, 5);
  }

  for (knt = 1; knt < 4; knt++) {
    c_A[knt] *= -tau_idx_0;
  }

  c_A[0] = 1.0F - tau_idx_0;
  knt = 0;
  for (lastc = 0; lastc < 4; lastc++) {
    Q[knt] = c_A[knt];
    Q[knt + 1] = c_A[knt + 1];
    Q[knt + 2] = c_A[knt + 2];
    Q[knt + 3] = c_A[knt + 3];
    knt += 4;
  }
}
