#ifndef SHARE_mpc_checkhessian_TWQ9ptm9
#define SHARE_mpc_checkhessian_TWQ9ptm9
#include "rtwtypes.h"
#include "multiword_types.h"

extern void mpc_checkhessian_TWQ9ptm9(real32_T b_H[16], real32_T L[16], real32_T
  *BadH);

#endif
