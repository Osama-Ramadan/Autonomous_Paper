#ifndef SHARE_xnrm2_TkIx4GfZ
#define SHARE_xnrm2_TkIx4GfZ
#include "rtwtypes.h"
#include "multiword_types.h"

extern real32_T xnrm2_TkIx4GfZ(int32_T n, const real32_T x[16], int32_T ix0);

#endif
