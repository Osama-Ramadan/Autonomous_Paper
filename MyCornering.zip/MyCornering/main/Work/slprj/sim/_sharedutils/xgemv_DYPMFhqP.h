#ifndef SHARE_xgemv_DYPMFhqP
#define SHARE_xgemv_DYPMFhqP
#include "rtwtypes.h"
#include "multiword_types.h"

extern void xgemv_DYPMFhqP(int32_T m, int32_T n, const real32_T b_A[16], int32_T
  ia0, const real32_T x[16], int32_T ix0, real32_T y[4]);

#endif
