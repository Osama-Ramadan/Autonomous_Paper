#include "rtwtypes.h"
#include "multiword_types.h"
#include "WtMult_gmFjAWwm.h"
#include "mpc_calculatehessian_9zqei9Pk.h"

void mpc_calculatehessian_9zqei9Pk(const real32_T b_Wy[2], real32_T b_Wu,
  real32_T b_Wdu, const real32_T b_SuJm[180], const real32_T I2Jm[90], const
  real32_T b_Jm[90], const real32_T b_I1[30], const real32_T b_Su1[60], const
  real32_T b_Sx[300], const real32_T b_Hv[3720], real32_T b_H[9], real32_T
  b_Ku1[3], real32_T b_Kut[90], real32_T b_Kx[15], real32_T b_Kv[186], real32_T
  b_Kr[180])
{
  int16_T ixw;
  int32_T i;
  real32_T tmp[90];
  real32_T b_SuJm_p[9];
  real32_T b_Jm_p[9];
  int32_T i_p;
  int32_T i_e;
  real32_T tmp_p;
  real32_T b_Su1_p[3];
  real32_T b_I1_p[3];
  int32_T b_SuJm_tmp;
  int32_T tmp_e;
  int32_T i_i;
  int32_T b_Kx_tmp;
  ixw = 1;
  for (i = 0; i < 60; i++) {
    b_Kr[i] = b_Wy[ixw - 1] * b_SuJm[i];
    b_Kr[i + 60] = b_Wy[ixw - 1] * b_SuJm[i + 60];
    b_Kr[i + 120] = b_Wy[ixw - 1] * b_SuJm[i + 120];
    ixw++;
    if (ixw > 2) {
      ixw = 1;
    }
  }

  WtMult_gmFjAWwm(b_Wu, I2Jm, b_Kut);
  WtMult_gmFjAWwm(b_Wdu, b_Jm, tmp);
  for (i = 0; i < 3; i++) {
    for (i_p = 0; i_p < 3; i_p++) {
      b_SuJm_tmp = i + 3 * i_p;
      b_SuJm_p[b_SuJm_tmp] = 0.0F;
      for (i_e = 0; i_e < 60; i_e++) {
        b_SuJm_p[b_SuJm_tmp] = b_SuJm[60 * i + i_e] * b_Kr[60 * i_p + i_e] +
          b_SuJm_p[3 * i_p + i];
      }

      b_Jm_p[b_SuJm_tmp] = 0.0F;
      tmp_p = 0.0F;
      for (i_e = 0; i_e < 30; i_e++) {
        tmp_e = 30 * i + i_e;
        i_i = 30 * i_p + i_e;
        tmp_p += I2Jm[tmp_e] * b_Kut[i_i];
        b_Jm_p[b_SuJm_tmp] = b_Jm[tmp_e] * tmp[i_i] + b_Jm_p[3 * i_p + i];
      }

      b_H[b_SuJm_tmp] = (b_SuJm_p[3 * i_p + i] + b_Jm_p[3 * i_p + i]) + tmp_p;
    }

    b_Su1_p[i] = 0.0F;
    for (i_p = 0; i_p < 60; i_p++) {
      b_Su1_p[i] += b_Kr[60 * i + i_p] * b_Su1[i_p];
    }

    b_I1_p[i] = 0.0F;
    for (i_p = 0; i_p < 30; i_p++) {
      b_I1_p[i] += b_Kut[30 * i + i_p] * b_I1[i_p];
    }

    b_Ku1[i] = b_Su1_p[i] + b_I1_p[i];
  }

  for (i = 0; i < 90; i++) {
    b_Kut[i] = -b_Kut[i];
  }

  i = 0;
  for (i_p = 0; i_p < 5; i_p++) {
    i_e = 0;
    tmp_e = 0;
    for (i_i = 0; i_i < 3; i_i++) {
      b_Kx_tmp = i_e + i_p;
      b_Kx[b_Kx_tmp] = 0.0F;
      for (b_SuJm_tmp = 0; b_SuJm_tmp < 60; b_SuJm_tmp++) {
        b_Kx[b_Kx_tmp] += b_Sx[b_SuJm_tmp + i] * b_Kr[b_SuJm_tmp + tmp_e];
      }

      i_e += 5;
      tmp_e += 60;
    }

    i += 60;
  }

  i = 0;
  for (i_p = 0; i_p < 62; i_p++) {
    i_e = 0;
    tmp_e = 0;
    for (i_i = 0; i_i < 3; i_i++) {
      b_Kx_tmp = i_e + i_p;
      b_Kv[b_Kx_tmp] = 0.0F;
      for (b_SuJm_tmp = 0; b_SuJm_tmp < 60; b_SuJm_tmp++) {
        b_Kv[b_Kx_tmp] += b_Hv[b_SuJm_tmp + i] * b_Kr[b_SuJm_tmp + tmp_e];
      }

      i_e += 62;
      tmp_e += 60;
    }

    i += 60;
  }

  for (i = 0; i < 180; i++) {
    b_Kr[i] = -b_Kr[i];
  }
}
