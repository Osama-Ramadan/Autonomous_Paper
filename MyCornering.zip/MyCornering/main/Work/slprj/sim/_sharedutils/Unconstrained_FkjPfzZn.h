#ifndef SHARE_Unconstrained_FkjPfzZn
#define SHARE_Unconstrained_FkjPfzZn
#include "rtwtypes.h"
#include "multiword_types.h"

extern void Unconstrained_FkjPfzZn(const real32_T b_Hinv[16], const real32_T f[4],
  real32_T x[4], int16_T n);

#endif
