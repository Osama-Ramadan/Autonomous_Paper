#ifndef SHARE_interp2_rm8DQnLL
#define SHARE_interp2_rm8DQnLL
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T interp2_rm8DQnLL(const real_T varargin_1[3], const real_T
  varargin_2[3], const real_T varargin_3[9], real_T varargin_4, real_T
  varargin_5);

#endif
