#ifndef SHARE_mrdivide_fJHemlFH
#define SHARE_mrdivide_fJHemlFH
#include "rtwtypes.h"
#include "multiword_types.h"

extern void mrdivide_fJHemlFH(const real32_T b_A[4], const real32_T b_B[4],
  real32_T y[4]);

#endif
