#ifndef SHARE_mpc_plantupdate_aUusw0Me
#define SHARE_mpc_plantupdate_aUusw0Me
#include "rtwtypes.h"
#include "multiword_types.h"

extern void mpc_plantupdate_aUusw0Me(const real32_T a[16], real32_T b[8],
  real32_T c[8], const real32_T d[4], real32_T b_A[25], real32_T b_B[30],
  real32_T b_C[10], real32_T b_D[12], const real32_T b_myindex[2], const
  real32_T b_Uscale[2], const real32_T b_Yscale[2], real32_T Bu[5], real32_T Bv
  [10], real32_T Cm[10], real32_T Dv[4], real32_T Dvm[4], real32_T QQ[25],
  real32_T RR[4], real32_T NN[10]);

#endif
