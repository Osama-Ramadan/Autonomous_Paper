#include "rtwtypes.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "xpotrf_VLyRItuj.h"

int32_T xpotrf_VLyRItuj(real32_T b_A[16])
{
  int32_T info;
  int32_T jj;
  real32_T ajj;
  int32_T j;
  int32_T ix;
  int32_T iy;
  int32_T k;
  real32_T c;
  int32_T b_iy;
  int32_T e;
  int32_T ia;
  boolean_T exitg1;
  info = 0;
  j = 0;
  exitg1 = false;
  while ((!exitg1) && (j + 1 < 5)) {
    jj = (j << 2) + j;
    ajj = 0.0F;
    if (!(j < 1)) {
      ix = j;
      iy = j;
      for (k = 1; k <= j; k++) {
        ajj += b_A[ix] * b_A[iy];
        ix += 4;
        iy += 4;
      }
    }

    ajj = b_A[jj] - ajj;
    if (ajj > 0.0F) {
      ajj = muSingleScalarSqrt(ajj);
      b_A[jj] = ajj;
      if (j + 1 < 4) {
        if (j != 0) {
          ix = j;
          iy = (((j - 1) << 2) + j) + 2;
          for (k = j + 2; k <= iy; k += 4) {
            c = -b_A[ix];
            b_iy = jj + 1;
            e = (k - j) + 2;
            for (ia = k; ia <= e; ia++) {
              b_A[b_iy] += b_A[ia - 1] * c;
              b_iy++;
            }

            ix += 4;
          }
        }

        ajj = 1.0F / ajj;
        ix = (jj - j) + 4;
        for (jj++; jj < ix; jj++) {
          b_A[jj] *= ajj;
        }
      }

      j++;
    } else {
      b_A[jj] = ajj;
      info = j + 1;
      exitg1 = true;
    }
  }

  return info;
}
