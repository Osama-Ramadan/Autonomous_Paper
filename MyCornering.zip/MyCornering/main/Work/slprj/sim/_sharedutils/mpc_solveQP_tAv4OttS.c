#include "rtwtypes.h"
#include "multiword_types.h"
#include "qpkwik_mja0KEZV.h"
#include "mpc_solveQP_tAv4OttS.h"

void mpc_solveQP_tAv4OttS(const real32_T xQP[5], const real32_T b_Kx[15], const
  real32_T b_Kr[180], const real32_T rseq[60], const real32_T b_Ku1[3], real32_T
  old_u, const real32_T b_Kv[186], const real32_T vseq[62], const real32_T
  b_Kut[90], const real32_T b_utarget[30], const real32_T b_Linv[16], const
  real32_T b_Hinv[16], const real32_T b_Ac[504], const real32_T Bc[126],
  boolean_T iA[126], real32_T zopt[4], real32_T f[4], real32_T *status)
{
  real32_T unusedU0[126];
  int16_T iAnew[126];
  int32_T i;
  real32_T tmp;
  int32_T i_p;
  real32_T tmp_p;
  real32_T tmp_e;
  real32_T tmp_i;
  f[0] = 0.0F;
  f[1] = 0.0F;
  f[2] = 0.0F;
  f[3] = 0.0F;
  for (i = 0; i < 3; i++) {
    tmp = 0.0F;
    for (i_p = 0; i_p < 5; i_p++) {
      tmp += b_Kx[5 * i + i_p] * xQP[i_p];
    }

    tmp_p = 0.0F;
    for (i_p = 0; i_p < 60; i_p++) {
      tmp_p += b_Kr[60 * i + i_p] * rseq[i_p];
    }

    tmp_e = 0.0F;
    for (i_p = 0; i_p < 62; i_p++) {
      tmp_e += b_Kv[62 * i + i_p] * vseq[i_p];
    }

    tmp_i = 0.0F;
    for (i_p = 0; i_p < 30; i_p++) {
      tmp_i += b_Kut[30 * i + i_p] * b_utarget[i_p];
    }

    f[i] = (((tmp + tmp_p) + b_Ku1[i] * old_u) + tmp_e) + tmp_i;
  }

  for (i = 0; i < 126; i++) {
    iAnew[i] = iA[i];
  }

  qpkwik_mja0KEZV(b_Linv, b_Hinv, f, b_Ac, Bc, iAnew, 520, 1.0E-6F, zopt,
                  unusedU0, status);
  for (i = 0; i < 126; i++) {
    iA[i] = (iAnew[i] != 0);
  }

  if ((*status < 0.0F) || (*status == 0.0F)) {
    zopt[0] = 0.0F;
    zopt[1] = 0.0F;
    zopt[2] = 0.0F;
    zopt[3] = 0.0F;
  }
}
