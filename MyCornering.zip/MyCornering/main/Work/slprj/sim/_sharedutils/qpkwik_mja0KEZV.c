#include "rtwtypes.h"
#include "multiword_types.h"
#include <string.h>
#include "DropConstraint_o4UFUics.h"
#include "KWIKfactor_7KQqqHb5.h"
#include "Unconstrained_FkjPfzZn.h"
#include "abs_O14j5i5E.h"
#include "abs_fYOsikuQ.h"
#include "mwmathutil.h"
#include "norm_DQueG6aD.h"
#include "qpkwik_mja0KEZV.h"

void qpkwik_mja0KEZV(const real32_T b_Linv[16], const real32_T b_Hinv[16], const
                     real32_T f[4], const real32_T b_Ac[504], const real32_T b
                     [126], int16_T iA[126], int16_T b_maxiter, real32_T FeasTol,
                     real32_T x[4], real32_T lambda[126], real32_T *status)
{
  real32_T r[4];
  real32_T rMin;
  real32_T RLinv[16];
  real32_T b_D[16];
  real32_T b_H[16];
  real32_T U[16];
  real32_T cTol[126];
  boolean_T cTolComputed;
  int16_T iC[126];
  int16_T nA;
  real32_T Opt[8];
  real32_T Rhs[8];
  boolean_T DualFeasible;
  boolean_T ColdReset;
  int16_T kDrop;
  real32_T Xnorm0;
  real32_T cMin;
  int16_T kNext;
  real32_T cVal;
  real32_T AcRow[4];
  real32_T t;
  int16_T iSave;
  uint16_T q;
  uint16_T b_x;
  real32_T varargin_1[126];
  int32_T e_k;
  int32_T i;
  real32_T b_Ac_p[4];
  int32_T tmp;
  int32_T tmp_p;
  int32_T exitg1;
  int32_T exitg2;
  int32_T exitg3;
  boolean_T exitg4;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  *status = 1.0F;
  x[0] = 0.0F;
  r[0] = 0.0F;
  x[1] = 0.0F;
  r[1] = 0.0F;
  x[2] = 0.0F;
  r[2] = 0.0F;
  x[3] = 0.0F;
  r[3] = 0.0F;
  rMin = 0.0F;
  cTolComputed = false;
  for (i = 0; i < 126; i++) {
    lambda[i] = 0.0F;
    cTol[i] = 1.0F;
    iC[i] = 0;
  }

  nA = 0;
  for (kNext = 0; kNext < 126; kNext++) {
    if (iA[kNext] == 1) {
      i = nA + 1;
      if (i > 32767) {
        i = 32767;
      }

      nA = (int16_T)i;
      iC[(int16_T)i - 1] = (int16_T)(kNext + 1);
    }
  }

  guard1 = false;
  if (nA > 0) {
    for (i = 0; i < 8; i++) {
      Opt[i] = 0.0F;
    }

    Rhs[0] = f[0];
    Rhs[4] = 0.0F;
    Rhs[1] = f[1];
    Rhs[5] = 0.0F;
    Rhs[2] = f[2];
    Rhs[6] = 0.0F;
    Rhs[3] = f[3];
    Rhs[7] = 0.0F;
    DualFeasible = false;
    i = 3 * nA;
    if (i > 32767) {
      i = 32767;
    }

    kNext = (int16_T)i;
    kNext = muIntScalarMax_sint16(kNext, 50);
    q = (uint16_T)(kNext / 10U);
    b_x = (uint16_T)((uint32_T)kNext - q * 10);
    if ((b_x > 0) && (b_x >= 5)) {
      q++;
    }

    ColdReset = false;
    do {
      exitg3 = 0;
      if ((!DualFeasible) && (nA > 0) && ((int32_T)*status <= b_maxiter)) {
        Xnorm0 = KWIKfactor_7KQqqHb5(b_Ac, iC, nA, b_Linv, RLinv, b_D, b_H, 4);
        if (Xnorm0 < 0.0F) {
          if (ColdReset) {
            *status = -2.0F;
            exitg3 = 2;
          } else {
            nA = 0;
            memset(&iA[0], 0, 126U * sizeof(int16_T));
            memset(&iC[0], 0, 126U * sizeof(int16_T));
            ColdReset = true;
          }
        } else {
          for (kNext = 1; kNext <= nA; kNext++) {
            i = 4 + kNext;
            if (i > 32767) {
              i = 32767;
            }

            Rhs[i - 1] = b[iC[kNext - 1] - 1];
            for (kDrop = kNext; kDrop <= nA; kDrop++) {
              U[(kDrop + ((kNext - 1) << 2)) - 1] = 0.0F;
              for (iSave = 1; iSave <= nA; iSave++) {
                U[(kDrop + ((kNext - 1) << 2)) - 1] += RLinv[(((iSave - 1) << 2)
                  + kDrop) - 1] * RLinv[(((iSave - 1) << 2) + kNext) - 1];
              }

              U[(kNext + ((kDrop - 1) << 2)) - 1] = U[(((kNext - 1) << 2) +
                kDrop) - 1];
            }
          }

          for (kNext = 0; kNext < 4; kNext++) {
            i = kNext + 1;
            Opt[kNext] = ((b_H[i - 1] * Rhs[0] + b_H[i + 3] * Rhs[1]) + b_H[i +
                          7] * Rhs[2]) + b_H[i + 11] * Rhs[3];
            for (kDrop = 1; kDrop <= nA; kDrop++) {
              i = 4 + kDrop;
              if (i > 32767) {
                i = 32767;
              }

              Opt[kNext] += b_D[((kDrop - 1) << 2) + kNext] * Rhs[i - 1];
            }
          }

          for (kNext = 1; kNext <= nA; kNext++) {
            i = 4 + kNext;
            e_k = i;
            if (i > 32767) {
              e_k = 32767;
            }

            Opt[e_k - 1] = ((b_D[((kNext - 1) << 2) + 1] * Rhs[1] + b_D[(kNext -
              1) << 2] * Rhs[0]) + b_D[((kNext - 1) << 2) + 2] * Rhs[2]) + b_D
              [((kNext - 1) << 2) + 3] * Rhs[3];
            for (kDrop = 1; kDrop <= nA; kDrop++) {
              e_k = i;
              if (i > 32767) {
                e_k = 32767;
              }

              tmp = i;
              if (i > 32767) {
                tmp = 32767;
              }

              tmp_p = 4 + kDrop;
              if (tmp_p > 32767) {
                tmp_p = 32767;
              }

              Opt[e_k - 1] = U[(((kDrop - 1) << 2) + kNext) - 1] * Rhs[tmp_p - 1]
                + Opt[tmp - 1];
            }
          }

          Xnorm0 = -1.0E-12F;
          kDrop = 0;
          for (kNext = 1; kNext <= nA; kNext++) {
            i = 4 + kNext;
            e_k = i;
            if (i > 32767) {
              e_k = 32767;
            }

            lambda[iC[kNext - 1] - 1] = Opt[e_k - 1];
            e_k = i;
            if (i > 32767) {
              e_k = 32767;
            }

            if ((Opt[e_k - 1] < Xnorm0) && (kNext <= nA)) {
              kDrop = kNext;
              if (i > 32767) {
                i = 32767;
              }

              Xnorm0 = Opt[i - 1];
            }
          }

          if (kDrop <= 0) {
            DualFeasible = true;
            x[0] = Opt[0];
            x[1] = Opt[1];
            x[2] = Opt[2];
            x[3] = Opt[3];
          } else {
            (*status)++;
            if ((int32_T)*status > q) {
              nA = 0;
              memset(&iA[0], 0, 126U * sizeof(int16_T));
              memset(&iC[0], 0, 126U * sizeof(int16_T));
              ColdReset = true;
            } else {
              lambda[iC[kDrop - 1] - 1] = 0.0F;
              DropConstraint_o4UFUics(kDrop, iA, &nA, iC);
            }
          }
        }
      } else {
        if (nA <= 0) {
          for (i = 0; i < 126; i++) {
            lambda[i] = 0.0F;
          }

          Unconstrained_FkjPfzZn(b_Hinv, f, x, 4);
        }

        exitg3 = 1;
      }
    } while (exitg3 == 0);

    if (exitg3 == 1) {
      guard1 = true;
    }
  } else {
    Unconstrained_FkjPfzZn(b_Hinv, f, x, 4);
    guard1 = true;
  }

  if (guard1) {
    Xnorm0 = norm_DQueG6aD(x);
    do {
      exitg2 = 0;
      if ((int32_T)*status <= b_maxiter) {
        cMin = -FeasTol;
        kNext = 0;
        for (kDrop = 0; kDrop < 126; kDrop++) {
          if (!cTolComputed) {
            i = kDrop + 1;
            b_Ac_p[0] = b_Ac[i - 1] * x[0];
            b_Ac_p[1] = b_Ac[i + 125] * x[1];
            b_Ac_p[2] = b_Ac[i + 251] * x[2];
            b_Ac_p[3] = b_Ac[i + 377] * x[3];
            abs_fYOsikuQ(b_Ac_p, AcRow);
            if (!muSingleScalarIsNaN(AcRow[0])) {
              i = 1;
            } else {
              i = 0;
              e_k = 2;
              exitg4 = false;
              while ((!exitg4) && (e_k < 5)) {
                if (!muSingleScalarIsNaN(AcRow[e_k - 1])) {
                  i = e_k;
                  exitg4 = true;
                } else {
                  e_k++;
                }
              }
            }

            if (i == 0) {
              cVal = AcRow[0];
            } else {
              cVal = AcRow[i - 1];
              while (i + 1 < 5) {
                if (cVal < AcRow[i]) {
                  cVal = AcRow[i];
                }

                i++;
              }
            }

            cTol[kDrop] = muSingleScalarMax(cTol[kDrop], cVal);
          }

          if (iA[kDrop] == 0) {
            i = kDrop + 1;
            cVal = ((((b_Ac[i - 1] * x[0] + b_Ac[i + 125] * x[1]) + b_Ac[i + 251]
                      * x[2]) + b_Ac[i + 377] * x[3]) - b[kDrop]) / cTol[kDrop];
            if (cVal < cMin) {
              cMin = cVal;
              kNext = (int16_T)(kDrop + 1);
            }
          }
        }

        cTolComputed = true;
        if (kNext <= 0) {
          exitg2 = 1;
        } else {
          do {
            exitg1 = 0;
            if ((kNext > 0) && ((int32_T)*status <= b_maxiter)) {
              guard2 = false;
              if (nA == 0) {
                for (i = 0; i < 4; i++) {
                  cMin = b_Hinv[i + 12] * b_Ac[kNext + 377] + (b_Hinv[i + 8] *
                    b_Ac[kNext + 251] + (b_Hinv[i + 4] * b_Ac[kNext + 125] +
                    b_Ac[kNext - 1] * b_Hinv[i]));
                  AcRow[i] = cMin;
                }

                guard2 = true;
              } else {
                cMin = KWIKfactor_7KQqqHb5(b_Ac, iC, nA, b_Linv, RLinv, b_D, b_H,
                  4);
                if (cMin <= 0.0F) {
                  *status = -2.0F;
                  exitg1 = 1;
                } else {
                  i = 0;
                  for (e_k = 0; e_k < 4; e_k++) {
                    U[i] = -b_H[i];
                    U[i + 1] = -b_H[i + 1];
                    U[i + 2] = -b_H[i + 2];
                    U[i + 3] = -b_H[i + 3];
                    i += 4;
                  }

                  for (i = 0; i < 4; i++) {
                    cMin = U[i + 12] * b_Ac[kNext + 377] + (U[i + 8] *
                      b_Ac[kNext + 251] + (U[i + 4] * b_Ac[kNext + 125] +
                      b_Ac[kNext - 1] * U[i]));
                    AcRow[i] = cMin;
                  }

                  for (kDrop = 1; kDrop <= nA; kDrop++) {
                    r[kDrop - 1] = ((b_D[((kDrop - 1) << 2) + 1] * b_Ac[kNext +
                                     125] + b_D[(kDrop - 1) << 2] * b_Ac[kNext -
                                     1]) + b_D[((kDrop - 1) << 2) + 2] *
                                    b_Ac[kNext + 251]) + b_D[((kDrop - 1) << 2)
                      + 3] * b_Ac[kNext + 377];
                  }

                  guard2 = true;
                }
              }

              if (guard2) {
                kDrop = 0;
                cMin = 0.0F;
                DualFeasible = true;
                ColdReset = true;
                if (nA > 0) {
                  iSave = 1;
                  exitg4 = false;
                  while ((!exitg4) && (iSave <= nA)) {
                    if (r[iSave - 1] >= 1.0E-12F) {
                      ColdReset = false;
                      exitg4 = true;
                    } else {
                      iSave++;
                    }
                  }
                }

                if (!((nA == 0) || ColdReset)) {
                  for (iSave = 1; iSave <= nA; iSave++) {
                    i = iSave - 1;
                    if (r[i] > 1.0E-12F) {
                      cVal = lambda[iC[i] - 1] / r[iSave - 1];
                      if ((kDrop == 0) || (cVal < rMin)) {
                        rMin = cVal;
                        kDrop = iSave;
                      }
                    }
                  }

                  if (kDrop > 0) {
                    cMin = rMin;
                    DualFeasible = false;
                  }
                }

                cVal = ((b_Ac[kNext - 1] * AcRow[0] + b_Ac[kNext + 125] * AcRow
                         [1]) + b_Ac[kNext + 251] * AcRow[2]) + b_Ac[kNext + 377]
                  * AcRow[3];
                if (cVal <= 0.0F) {
                  cVal = 0.0F;
                  ColdReset = true;
                } else {
                  cVal = (b[kNext - 1] - (((b_Ac[kNext - 1] * x[0] + b_Ac[kNext
                             + 125] * x[1]) + b_Ac[kNext + 251] * x[2]) +
                           b_Ac[kNext + 377] * x[3])) / cVal;
                  ColdReset = false;
                }

                if (DualFeasible && ColdReset) {
                  *status = -1.0F;
                  exitg1 = 1;
                } else {
                  if (ColdReset) {
                    t = cMin;
                  } else if (DualFeasible) {
                    t = cVal;
                  } else {
                    t = muSingleScalarMin(cMin, cVal);
                  }

                  for (iSave = 1; iSave <= nA; iSave++) {
                    i = iSave - 1;
                    e_k = iC[i] - 1;
                    lambda[e_k] -= r[i] * t;
                    if ((iC[iSave - 1] <= 126) && (lambda[iC[iSave - 1] - 1] <
                         0.0F)) {
                      lambda[e_k] = 0.0F;
                    }
                  }

                  lambda[kNext - 1] += t;
                  if (t == cMin) {
                    DropConstraint_o4UFUics(kDrop, iA, &nA, iC);
                  }

                  if (!ColdReset) {
                    x[0] += t * AcRow[0];
                    x[1] += t * AcRow[1];
                    x[2] += t * AcRow[2];
                    x[3] += t * AcRow[3];
                    if (t == cVal) {
                      if (nA == 4) {
                        *status = -1.0F;
                        exitg1 = 1;
                      } else {
                        i = nA + 1;
                        if (i > 32767) {
                          i = 32767;
                        }

                        nA = (int16_T)i;
                        iC[(int16_T)i - 1] = kNext;
                        kDrop = (int16_T)i;
                        exitg4 = false;
                        while ((!exitg4) && (kDrop > 1)) {
                          i = kDrop - 1;
                          e_k = kDrop - 2;
                          if (iC[i] > iC[e_k]) {
                            exitg4 = true;
                          } else {
                            iSave = iC[kDrop - 1];
                            iC[i] = iC[kDrop - 2];
                            iC[e_k] = iSave;
                            kDrop = (int16_T)i;
                          }
                        }

                        iA[kNext - 1] = 1;
                        kNext = 0;
                        (*status)++;
                      }
                    } else {
                      (*status)++;
                    }
                  } else {
                    (*status)++;
                  }
                }
              }
            } else {
              cMin = norm_DQueG6aD(x);
              if (muSingleScalarAbs(cMin - Xnorm0) > 0.001F) {
                Xnorm0 = cMin;
                abs_O14j5i5E(b, varargin_1);
                for (i = 0; i < 126; i++) {
                  cTol[i] = muSingleScalarMax(varargin_1[i], 1.0F);
                }

                cTolComputed = false;
              }

              exitg1 = 2;
            }
          } while (exitg1 == 0);

          if (exitg1 == 1) {
            exitg2 = 1;
          }
        }
      } else {
        *status = 0.0F;
        exitg2 = 1;
      }
    } while (exitg2 == 0);
  }
}
