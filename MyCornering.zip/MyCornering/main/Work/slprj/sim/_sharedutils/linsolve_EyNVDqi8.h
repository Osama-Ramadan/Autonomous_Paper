#ifndef SHARE_linsolve_EyNVDqi8
#define SHARE_linsolve_EyNVDqi8
#include "rtwtypes.h"
#include "multiword_types.h"

extern void linsolve_EyNVDqi8(const real32_T b_A[16], const real32_T b_B[16],
  real32_T b_C[16]);

#endif
