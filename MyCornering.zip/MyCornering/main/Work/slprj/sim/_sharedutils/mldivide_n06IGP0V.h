#ifndef SHARE_mldivide_n06IGP0V
#define SHARE_mldivide_n06IGP0V
#include "rtwtypes.h"
#include "multiword_types.h"

extern void mldivide_n06IGP0V(const real32_T A[16], real32_T B[16]);

#endif
