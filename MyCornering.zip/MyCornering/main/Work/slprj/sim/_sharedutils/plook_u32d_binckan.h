#ifndef SHARE_plook_u32d_binckan
#define SHARE_plook_u32d_binckan
#include "rtwtypes.h"
#include "multiword_types.h"

extern uint32_T plook_u32d_binckan(real_T u, const real_T bp[], uint32_T
  maxIndex);

#endif
