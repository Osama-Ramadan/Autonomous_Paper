#ifndef SHARE_rt_mrdivide_U1d1x3_U2d3x3_Yd1x3_snf
#define SHARE_rt_mrdivide_U1d1x3_U2d3x3_Yd1x3_snf
#include "rtwtypes.h"
#include "multiword_types.h"

extern void rt_mrdivide_U1d1x3_U2d3x3_Yd1x3_snf(const real_T u0[3], const real_T
  u1[9], real_T y[3]);

#endif
