#ifndef SHARE_binsearch_u32d
#define SHARE_binsearch_u32d
#include "rtwtypes.h"
#include "multiword_types.h"

extern uint32_T binsearch_u32d(real_T u, const real_T bp[], uint32_T startIndex,
  uint32_T maxIndex);

#endif
