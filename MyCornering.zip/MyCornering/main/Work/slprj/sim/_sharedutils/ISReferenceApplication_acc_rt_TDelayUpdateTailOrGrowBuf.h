

        /*
      * C:\Users\am2114\MATLAB\Projects\MyCornering\main\Work\slprj\sim\_sharedutils\ISReferenceApplication_acc_rt_TDelayUpdateTailOrGrowBuf.h
      * 
        * Academic License - for use in teaching, academic research, and meeting
* course requirements at degree granting institutions only.  Not for
* government, commercial, or other organizational use. 
  * 
  * Code generation for model "ISReferenceApplication_acc".
  *
  * Model version              : 1.155
  * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
  * C source code generated on : Tue Feb  5 20:41:23 2019
      * Created for block: <Root>/B_10_0
      */


    

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

        #ifndef SHARE_ISReferenceApplication_acc_rt_TDelayUpdateTailOrGrowBuf
      #define SHARE_ISReferenceApplication_acc_rt_TDelayUpdateTailOrGrowBuf

     
      #include "rtwtypes.h"
        #include "multiword_types.h"
      
                boolean_T  ISReferenceApplication_acc_rt_TDelayUpdateTailOrGrowBuf(
int_T       *bufSzPtr,        /* in/out - circular buffer size                 */
int_T       *tailPtr,         /* in/out - tail of circular buffer              */
int_T       *headPtr,         /* in/out - head of circular buffer              */
int_T       *lastPtr,         /* in/out - same logical 'last' referenced index */
real_T      tMinusDelay,      /* in     - last point we are looking at   */
real_T      **tBufPtr,        /* in/out - larger buffer for time         */
real_T      **uBufPtr,        /* in/out - larger buffer for input        */
real_T      **xBufPtr,        /* in/out - larger buffer for state        */
boolean_T   isfixedbuf,       /* in     - fixed buffer size enable       */
boolean_T istransportdelay,   /* in     - block acts as transport dela y */
int_T     *maxNewBufSzPtr);

            
      #endif


  

  

  

  
