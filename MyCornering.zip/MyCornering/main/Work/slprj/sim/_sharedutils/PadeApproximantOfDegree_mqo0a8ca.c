#include "rtwtypes.h"
#include "multiword_types.h"
#include <string.h>
#include "mldivide_n06IGP0V.h"
#include "PadeApproximantOfDegree_mqo0a8ca.h"

void PadeApproximantOfDegree_mqo0a8ca(const real32_T A[16], uint8_T m, real32_T
  F[16])
{
  real32_T A2[16];
  int32_T d;
  real32_T A3[16];
  real32_T A4[16];
  int32_T i;
  int32_T i_p;
  real32_T A_p[16];
  int32_T A2_tmp;
  d = 0;
  for (i_p = 0; i_p < 4; i_p++) {
    for (i = 0; i < 4; i++) {
      A2_tmp = i + d;
      A2[A2_tmp] = 0.0F;
      A2[A2_tmp] += A[d] * A[i];
      A2[A2_tmp] = A[d + 1] * A[i + 4] + A2[i + d];
      A2[A2_tmp] = A[d + 2] * A[i + 8] + A2[i + d];
      A2[A2_tmp] = A[d + 3] * A[i + 12] + A2[i + d];
    }

    d += 4;
  }

  if (m == 3) {
    memcpy(&F[0], &A2[0], sizeof(real32_T) << 4U);
    F[0] += 60.0F;
    F[5] += 60.0F;
    F[10] += 60.0F;
    F[15] += 60.0F;
    d = 0;
    for (i_p = 0; i_p < 4; i_p++) {
      for (i = 0; i < 4; i++) {
        A2_tmp = i + d;
        A_p[A2_tmp] = 0.0F;
        A_p[A2_tmp] += F[d] * A[i];
        A_p[A2_tmp] = F[d + 1] * A[i + 4] + A_p[i + d];
        A_p[A2_tmp] = F[d + 2] * A[i + 8] + A_p[i + d];
        A_p[A2_tmp] = F[d + 3] * A[i + 12] + A_p[i + d];
      }

      d += 4;
    }

    d = 0;
    for (i_p = 0; i_p < 4; i_p++) {
      F[d] = A_p[d];
      F[d + 1] = A_p[d + 1];
      F[d + 2] = A_p[d + 2];
      F[d + 3] = A_p[d + 3];
      d += 4;
    }

    for (d = 0; d < 16; d++) {
      A4[d] = 12.0F * A2[d];
    }

    d = 120;
  } else {
    d = 0;
    for (i_p = 0; i_p < 4; i_p++) {
      for (i = 0; i < 4; i++) {
        A2_tmp = i + d;
        A3[A2_tmp] = 0.0F;
        A3[A2_tmp] += A2[d] * A2[i];
        A3[A2_tmp] = A2[d + 1] * A2[i + 4] + A3[i + d];
        A3[A2_tmp] = A2[d + 2] * A2[i + 8] + A3[i + d];
        A3[A2_tmp] = A2[d + 3] * A2[i + 12] + A3[i + d];
      }

      d += 4;
    }

    if (m == 5) {
      for (d = 0; d < 16; d++) {
        F[d] = 420.0F * A2[d] + A3[d];
      }

      F[0] += 15120.0F;
      F[5] += 15120.0F;
      F[10] += 15120.0F;
      F[15] += 15120.0F;
      d = 0;
      for (i_p = 0; i_p < 4; i_p++) {
        for (i = 0; i < 4; i++) {
          A2_tmp = i + d;
          A_p[A2_tmp] = 0.0F;
          A_p[A2_tmp] += F[d] * A[i];
          A_p[A2_tmp] = F[d + 1] * A[i + 4] + A_p[i + d];
          A_p[A2_tmp] = F[d + 2] * A[i + 8] + A_p[i + d];
          A_p[A2_tmp] = F[d + 3] * A[i + 12] + A_p[i + d];
        }

        d += 4;
      }

      d = 0;
      for (i_p = 0; i_p < 4; i_p++) {
        F[d] = A_p[d];
        F[d + 1] = A_p[d + 1];
        F[d + 2] = A_p[d + 2];
        F[d + 3] = A_p[d + 3];
        d += 4;
      }

      for (d = 0; d < 16; d++) {
        A4[d] = 30.0F * A3[d] + 3360.0F * A2[d];
      }

      d = 30240;
    } else {
      d = 0;
      for (i_p = 0; i_p < 4; i_p++) {
        for (i = 0; i < 4; i++) {
          A2_tmp = i + d;
          A4[A2_tmp] = 0.0F;
          A4[A2_tmp] += A2[d] * A3[i];
          A4[A2_tmp] = A2[d + 1] * A3[i + 4] + A4[i + d];
          A4[A2_tmp] = A2[d + 2] * A3[i + 8] + A4[i + d];
          A4[A2_tmp] = A2[d + 3] * A3[i + 12] + A4[i + d];
        }

        d += 4;
      }

      for (d = 0; d < 16; d++) {
        F[d] = (1512.0F * A3[d] + A4[d]) + 277200.0F * A2[d];
      }

      F[0] += 8.64864E+6F;
      F[5] += 8.64864E+6F;
      F[10] += 8.64864E+6F;
      F[15] += 8.64864E+6F;
      d = 0;
      for (i_p = 0; i_p < 4; i_p++) {
        for (i = 0; i < 4; i++) {
          A2_tmp = i + d;
          A_p[A2_tmp] = 0.0F;
          A_p[A2_tmp] += F[d] * A[i];
          A_p[A2_tmp] = F[d + 1] * A[i + 4] + A_p[i + d];
          A_p[A2_tmp] = F[d + 2] * A[i + 8] + A_p[i + d];
          A_p[A2_tmp] = F[d + 3] * A[i + 12] + A_p[i + d];
        }

        d += 4;
      }

      d = 0;
      for (i_p = 0; i_p < 4; i_p++) {
        F[d] = A_p[d];
        F[d + 1] = A_p[d + 1];
        F[d + 2] = A_p[d + 2];
        F[d + 3] = A_p[d + 3];
        d += 4;
      }

      for (d = 0; d < 16; d++) {
        A4[d] = (56.0F * A4[d] + 25200.0F * A3[d]) + 1.99584E+6F * A2[d];
      }

      d = 17297280;
    }
  }

  A4[0] += (real32_T)d;
  A4[5] += (real32_T)d;
  A4[10] += (real32_T)d;
  A4[15] += (real32_T)d;
  for (d = 0; d < 16; d++) {
    A4[d] -= F[d];
    F[d] *= 2.0F;
  }

  mldivide_n06IGP0V(A4, F);
  F[0]++;
  F[5]++;
  F[10]++;
  F[15]++;
}
