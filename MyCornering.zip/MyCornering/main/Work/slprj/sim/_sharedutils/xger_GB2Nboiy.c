#include "rtwtypes.h"
#include "multiword_types.h"
#include "xger_GB2Nboiy.h"

void xger_GB2Nboiy(int32_T m, int32_T n, real32_T alpha1, int32_T ix0, const
                   real32_T y[4], real32_T b_A[16], int32_T ia0)
{
  int32_T jA;
  int32_T jy;
  real32_T temp;
  int32_T ix;
  int32_T j;
  int32_T b;
  int32_T ijA;
  if (!(alpha1 == 0.0F)) {
    jA = ia0 - 1;
    jy = 0;
    for (j = 1; j <= n; j++) {
      if (y[jy] != 0.0F) {
        temp = y[jy] * alpha1;
        ix = ix0;
        b = m + jA;
        for (ijA = jA; ijA < b; ijA++) {
          b_A[ijA] += b_A[ix - 1] * temp;
          ix++;
        }
      }

      jy++;
      jA += 4;
    }
  }
}
