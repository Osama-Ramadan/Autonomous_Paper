#include "rtwtypes.h"
#include "multiword_types.h"
#include "eye_XDJCRWpB.h"

void eye_XDJCRWpB(real32_T I[16])
{
  int32_T i;
  for (i = 0; i < 16; i++) {
    I[i] = 0.0F;
  }

  I[0] = 1.0F;
  I[5] = 1.0F;
  I[10] = 1.0F;
  I[15] = 1.0F;
}
