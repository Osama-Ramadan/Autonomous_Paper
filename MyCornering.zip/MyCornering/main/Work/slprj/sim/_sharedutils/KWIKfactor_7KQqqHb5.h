#ifndef SHARE_KWIKfactor_7KQqqHb5
#define SHARE_KWIKfactor_7KQqqHb5
#include "rtwtypes.h"
#include "multiword_types.h"

extern real32_T KWIKfactor_7KQqqHb5(const real32_T b_Ac[504], const int16_T iC
  [126], int16_T nA, const real32_T b_Linv[16], real32_T RLinv[16], real32_T
  b_D[16], real32_T b_H[16], int16_T n);

#endif
