#include "rtwtypes.h"
#include "multiword_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include <math.h>
#include "PadeApproximantOfDegree_mqo0a8ca.h"
#include "mwmathutil.h"
#include "expm_cf1QcFJp.h"

void expm_cf1QcFJp(real32_T A[16], real32_T F[16])
{
  real32_T normA;
  real32_T b_s;
  int32_T b_j;
  int32_T eint;
  static const real32_T theta[3] = { 0.425873F, 1.8801527F, 3.92572474F };

  real32_T F_p[16];
  int32_T i;
  int32_T i_p;
  int32_T F_tmp;
  boolean_T exitg1;
  normA = 0.0F;
  b_j = 0;
  exitg1 = false;
  while ((!exitg1) && (b_j < 4)) {
    b_s = ((muSingleScalarAbs(A[(b_j << 2) + 1]) + muSingleScalarAbs(A[b_j << 2]))
           + muSingleScalarAbs(A[(b_j << 2) + 2])) + muSingleScalarAbs(A[(b_j <<
      2) + 3]);
    if (muSingleScalarIsNaN(b_s)) {
      normA = (rtNaNF);
      exitg1 = true;
    } else {
      if (b_s > normA) {
        normA = b_s;
      }

      b_j++;
    }
  }

  if (normA <= 3.92572474F) {
    b_j = 0;
    exitg1 = false;
    while ((!exitg1) && (b_j < 3)) {
      if (normA <= theta[b_j]) {
        PadeApproximantOfDegree_mqo0a8ca(A, (uint8_T)((b_j << 1) + 3), F);
        exitg1 = true;
      } else {
        b_j++;
      }
    }
  } else {
    b_s = normA / 3.92572474F;
    if ((!muSingleScalarIsInf(b_s)) && (!muSingleScalarIsNaN(b_s))) {
      b_s = (real32_T)frexp(b_s, &eint);
      normA = (real32_T)eint;
    } else {
      normA = 0.0F;
    }

    if (b_s == 0.5F) {
      normA--;
    }

    b_s = muSingleScalarPower(2.0F, normA);
    for (b_j = 0; b_j < 16; b_j++) {
      A[b_j] /= b_s;
    }

    PadeApproximantOfDegree_mqo0a8ca(A, 7, F);
    for (eint = 0; eint < (int32_T)normA; eint++) {
      for (b_j = 0; b_j < 4; b_j++) {
        i_p = 0;
        for (i = 0; i < 4; i++) {
          F_tmp = i_p + b_j;
          F_p[F_tmp] = 0.0F;
          F_p[F_tmp] += F[i_p] * F[b_j];
          F_p[F_tmp] = F[i_p + 1] * F[b_j + 4] + F_p[i_p + b_j];
          F_p[F_tmp] = F[i_p + 2] * F[b_j + 8] + F_p[i_p + b_j];
          F_p[F_tmp] = F[i_p + 3] * F[b_j + 12] + F_p[i_p + b_j];
          i_p += 4;
        }
      }

      b_j = 0;
      for (i_p = 0; i_p < 4; i_p++) {
        F[b_j] = F_p[b_j];
        F[b_j + 1] = F_p[b_j + 1];
        F[b_j + 2] = F_p[b_j + 2];
        F[b_j + 3] = F_p[b_j + 3];
        b_j += 4;
      }
    }
  }
}
