#ifndef SHARE_norm_DQueG6aD
#define SHARE_norm_DQueG6aD
#include "rtwtypes.h"
#include "multiword_types.h"

extern real32_T norm_DQueG6aD(const real32_T x[4]);

#endif
