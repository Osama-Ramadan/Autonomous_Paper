#ifndef SHARE_qpkwik_mja0KEZV
#define SHARE_qpkwik_mja0KEZV
#include "rtwtypes.h"
#include "multiword_types.h"

extern void qpkwik_mja0KEZV(const real32_T b_Linv[16], const real32_T b_Hinv[16],
  const real32_T f[4], const real32_T b_Ac[504], const real32_T b[126], int16_T
  iA[126], int16_T b_maxiter, real32_T FeasTol, real32_T x[4], real32_T lambda
  [126], real32_T *status);

#endif
