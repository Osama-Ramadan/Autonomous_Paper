#ifndef SHARE_WtMult_gmFjAWwm
#define SHARE_WtMult_gmFjAWwm
#include "rtwtypes.h"
#include "multiword_types.h"

extern void WtMult_gmFjAWwm(real32_T W, const real32_T M[90], real32_T WM[90]);

#endif
