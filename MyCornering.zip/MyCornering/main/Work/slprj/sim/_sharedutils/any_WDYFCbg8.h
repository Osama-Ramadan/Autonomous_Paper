#ifndef SHARE_any_WDYFCbg8
#define SHARE_any_WDYFCbg8
#include "rtwtypes.h"
#include "multiword_types.h"

extern boolean_T any_WDYFCbg8(boolean_T x);

#endif
