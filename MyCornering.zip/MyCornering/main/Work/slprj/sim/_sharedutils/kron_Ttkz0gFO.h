#ifndef SHARE_kron_Ttkz0gFO
#define SHARE_kron_Ttkz0gFO
#include "rtwtypes.h"
#include "multiword_types.h"

extern void kron_Ttkz0gFO(const real32_T b_A[900], real32_T b_B, real32_T K[900]);

#endif
