#ifndef SHARE_abs_fYOsikuQ
#define SHARE_abs_fYOsikuQ
#include "rtwtypes.h"
#include "multiword_types.h"

extern void abs_fYOsikuQ(const real32_T x[4], real32_T y[4]);

#endif
