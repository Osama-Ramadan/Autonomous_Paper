#include "rtwtypes.h"
#include "multiword_types.h"
#include <string.h>
#include "mwmathutil.h"
#include "mldivide_n06IGP0V.h"

void mldivide_n06IGP0V(const real32_T A[16], real32_T B[16])
{
  int32_T ip;
  real32_T b_A[16];
  int8_T ipiv[4];
  int32_T j;
  int32_T ix;
  real32_T smax;
  real32_T s;
  int32_T k;
  int32_T b_ix;
  int32_T c_ix;
  int32_T d;
  int32_T ijA;
  memcpy(&b_A[0], &A[0], sizeof(real32_T) << 4U);
  ipiv[0] = 1;
  ipiv[1] = 2;
  ipiv[2] = 3;
  ipiv[3] = 4;
  for (j = 0; j < 3; j++) {
    ip = j * 5;
    b_ix = 0;
    ix = ip;
    smax = muSingleScalarAbs(b_A[ip]);
    for (k = 2; k <= 4 - j; k++) {
      ix++;
      s = muSingleScalarAbs(b_A[ix]);
      if (s > smax) {
        b_ix = k - 1;
        smax = s;
      }
    }

    if (b_A[ip + b_ix] != 0.0F) {
      if (b_ix != 0) {
        ix = j + b_ix;
        ipiv[j] = (int8_T)(ix + 1);
        smax = b_A[j];
        b_A[j] = b_A[ix];
        b_A[ix] = smax;
        b_ix = j + 4;
        ix += 4;
        smax = b_A[b_ix];
        b_A[b_ix] = b_A[ix];
        b_A[ix] = smax;
        b_ix += 4;
        ix += 4;
        smax = b_A[b_ix];
        b_A[b_ix] = b_A[ix];
        b_A[ix] = smax;
        b_ix += 4;
        ix += 4;
        smax = b_A[b_ix];
        b_A[b_ix] = b_A[ix];
        b_A[ix] = smax;
      }

      b_ix = (ip - j) + 4;
      for (ix = ip + 1; ix < b_ix; ix++) {
        b_A[ix] /= b_A[ip];
      }
    }

    b_ix = ip;
    ix = ip + 4;
    for (k = 1; k <= 3 - j; k++) {
      smax = b_A[ix];
      if (b_A[ix] != 0.0F) {
        c_ix = ip + 1;
        d = (b_ix - j) + 8;
        for (ijA = 5 + b_ix; ijA < d; ijA++) {
          b_A[ijA] += b_A[c_ix] * -smax;
          c_ix++;
        }
      }

      ix += 4;
      b_ix += 4;
    }

    if (j + 1 != ipiv[j]) {
      ip = ipiv[j] - 1;
      smax = B[j];
      B[j] = B[ip];
      B[ip] = smax;
      smax = B[j + 4];
      B[j + 4] = B[ip + 4];
      B[ip + 4] = smax;
      smax = B[j + 8];
      B[j + 8] = B[ip + 8];
      B[ip + 8] = smax;
      smax = B[j + 12];
      B[j + 12] = B[ip + 12];
      B[ip + 12] = smax;
    }
  }

  for (j = 0; j < 4; j++) {
    ip = j << 2;
    if (B[ip] != 0.0F) {
      for (b_ix = 1; b_ix + 1 < 5; b_ix++) {
        B[b_ix + ip] -= B[ip] * b_A[b_ix];
      }
    }

    if (B[1 + ip] != 0.0F) {
      for (b_ix = 2; b_ix + 1 < 5; b_ix++) {
        B[b_ix + ip] -= B[1 + ip] * b_A[b_ix + 4];
      }
    }

    if (B[2 + ip] != 0.0F) {
      for (b_ix = 3; b_ix + 1 < 5; b_ix++) {
        B[b_ix + ip] -= B[2 + ip] * b_A[b_ix + 8];
      }
    }
  }

  for (j = 0; j < 4; j++) {
    ip = j << 2;
    if (B[3 + ip] != 0.0F) {
      B[3 + ip] /= b_A[15];
      for (b_ix = 0; b_ix < 3; b_ix++) {
        B[b_ix + ip] -= B[3 + ip] * b_A[b_ix + 12];
      }
    }

    if (B[2 + ip] != 0.0F) {
      B[2 + ip] /= b_A[10];
      for (b_ix = 0; b_ix < 2; b_ix++) {
        B[b_ix + ip] -= B[2 + ip] * b_A[b_ix + 8];
      }
    }

    if (B[1 + ip] != 0.0F) {
      B[1 + ip] /= b_A[5];
      for (b_ix = 0; b_ix < 1; b_ix++) {
        B[b_ix + ip] -= B[1 + ip] * b_A[b_ix + 4];
      }
    }

    if (B[ip] != 0.0F) {
      B[ip] /= b_A[0];
    }
  }
}
