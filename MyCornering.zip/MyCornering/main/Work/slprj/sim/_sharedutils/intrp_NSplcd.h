#ifndef SHARE_intrp_NSplcd
#define SHARE_intrp_NSplcd
#include "rtwtypes.h"
#include "multiword_types.h"
#include "rtsplntypes.h"

real_T intrp_NSplcd(uint32_T numDims, const rt_LUTSplineWork * const splWork,
                    uint32_T extrapMethod);

#endif
