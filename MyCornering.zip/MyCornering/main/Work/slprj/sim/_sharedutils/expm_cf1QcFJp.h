#ifndef SHARE_expm_cf1QcFJp
#define SHARE_expm_cf1QcFJp
#include "rtwtypes.h"
#include "multiword_types.h"

extern void expm_cf1QcFJp(real32_T A[16], real32_T F[16]);

#endif
