#ifndef SHARE_xpotrf_VLyRItuj
#define SHARE_xpotrf_VLyRItuj
#include "rtwtypes.h"
#include "multiword_types.h"

extern int32_T xpotrf_VLyRItuj(real32_T b_A[16]);

#endif
