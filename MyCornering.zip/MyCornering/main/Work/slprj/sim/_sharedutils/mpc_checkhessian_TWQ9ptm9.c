#include "rtwtypes.h"
#include "multiword_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include <string.h>
#include "mwmathutil.h"
#include "xpotrf_VLyRItuj.h"
#include "mpc_checkhessian_TWQ9ptm9.h"

void mpc_checkhessian_TWQ9ptm9(real32_T b_H[16], real32_T L[16], real32_T *BadH)
{
  real32_T normH;
  real32_T d[4];
  int32_T idx;
  real32_T s;
  int8_T I[16];
  int32_T b_idx;
  int32_T f_k;
  boolean_T exitg1;
  boolean_T exitg2;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  *BadH = 0.0F;
  memcpy(&L[0], &b_H[0], sizeof(real32_T) << 4U);
  idx = xpotrf_VLyRItuj(L);
  guard1 = false;
  if (idx == 0) {
    d[0] = L[0];
    d[1] = L[5];
    d[2] = L[10];
    d[3] = L[15];
    if (!muSingleScalarIsNaN(L[0])) {
      idx = 1;
    } else {
      idx = 0;
      b_idx = 2;
      exitg2 = false;
      while ((!exitg2) && (b_idx < 5)) {
        if (!muSingleScalarIsNaN(d[b_idx - 1])) {
          idx = b_idx;
          exitg2 = true;
        } else {
          b_idx++;
        }
      }
    }

    if (idx == 0) {
      normH = L[0];
    } else {
      normH = d[idx - 1];
      while (idx + 1 < 5) {
        if (normH > d[idx]) {
          normH = d[idx];
        }

        idx++;
      }
    }

    if (normH > 1.49011612E-7F) {
    } else {
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    normH = 0.0F;
    idx = 0;
    exitg2 = false;
    while ((!exitg2) && (idx < 4)) {
      s = ((muSingleScalarAbs(b_H[idx + 4]) + muSingleScalarAbs(b_H[idx])) +
           muSingleScalarAbs(b_H[idx + 8])) + muSingleScalarAbs(b_H[idx + 12]);
      if (muSingleScalarIsNaN(s)) {
        normH = (rtNaNF);
        exitg2 = true;
      } else {
        if (s > normH) {
          normH = s;
        }

        idx++;
      }
    }

    if (normH >= 1.0E+10F) {
      *BadH = 2.0F;
    } else {
      idx = 0;
      exitg1 = false;
      while ((!exitg1) && (idx <= 4)) {
        for (b_idx = 0; b_idx < 16; b_idx++) {
          I[b_idx] = 0;
        }

        I[0] = 1;
        I[5] = 1;
        I[10] = 1;
        I[15] = 1;
        normH = muSingleScalarPower(10.0F, (real32_T)idx) * 1.49011612E-7F;
        for (b_idx = 0; b_idx < 16; b_idx++) {
          b_H[b_idx] += normH * (real32_T)I[b_idx];
          L[b_idx] = b_H[b_idx];
        }

        b_idx = xpotrf_VLyRItuj(L);
        guard2 = false;
        if (b_idx == 0) {
          d[0] = L[0];
          d[1] = L[5];
          d[2] = L[10];
          d[3] = L[15];
          if (!muSingleScalarIsNaN(L[0])) {
            b_idx = 1;
          } else {
            b_idx = 0;
            f_k = 2;
            exitg2 = false;
            while ((!exitg2) && (f_k < 5)) {
              if (!muSingleScalarIsNaN(d[f_k - 1])) {
                b_idx = f_k;
                exitg2 = true;
              } else {
                f_k++;
              }
            }
          }

          if (b_idx == 0) {
            normH = L[0];
          } else {
            normH = d[b_idx - 1];
            while (b_idx + 1 < 5) {
              if (normH > d[b_idx]) {
                normH = d[b_idx];
              }

              b_idx++;
            }
          }

          if (normH > 1.49011612E-7F) {
            *BadH = 1.0F;
            exitg1 = true;
          } else {
            guard2 = true;
          }
        } else {
          guard2 = true;
        }

        if (guard2) {
          *BadH = 3.0F;
          idx++;
        }
      }
    }
  }
}
