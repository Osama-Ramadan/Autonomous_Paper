#include "rtwtypes.h"
#include "multiword_types.h"
#include "xgemv_DYPMFhqP.h"

void xgemv_DYPMFhqP(int32_T m, int32_T n, const real32_T b_A[16], int32_T ia0,
                    const real32_T x[16], int32_T ix0, real32_T y[4])
{
  int32_T ix;
  real32_T c;
  int32_T iy;
  int32_T b;
  int32_T iac;
  int32_T d;
  int32_T ia;
  if (!((m == 0) || (n == 0))) {
    for (iy = 1; iy <= n; iy++) {
      y[iy - 1] = 0.0F;
    }

    iy = 0;
    b = ((n - 1) << 2) + ia0;
    for (iac = ia0; iac <= b; iac += 4) {
      ix = ix0;
      c = 0.0F;
      d = (iac + m) - 1;
      for (ia = iac; ia <= d; ia++) {
        c += b_A[ia - 1] * x[ix - 1];
        ix++;
      }

      y[iy] += c;
      iy++;
    }
  }
}
