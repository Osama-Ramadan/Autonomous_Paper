#ifndef SHARE_eye_1T7g1wOb
#define SHARE_eye_1T7g1wOb
#include "rtwtypes.h"
#include "multiword_types.h"

extern void eye_1T7g1wOb(real32_T I[4]);

#endif
