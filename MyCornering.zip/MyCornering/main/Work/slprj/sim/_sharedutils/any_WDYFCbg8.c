#include "rtwtypes.h"
#include "multiword_types.h"
#include "any_WDYFCbg8.h"

boolean_T any_WDYFCbg8(boolean_T x)
{
  return x;
}
