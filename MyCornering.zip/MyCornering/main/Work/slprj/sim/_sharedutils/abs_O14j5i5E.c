#include "rtwtypes.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "abs_O14j5i5E.h"

void abs_O14j5i5E(const real32_T x[126], real32_T y[126])
{
  int32_T k;
  for (k = 0; k < 126; k++) {
    y[k] = muSingleScalarAbs(x[k]);
  }
}
