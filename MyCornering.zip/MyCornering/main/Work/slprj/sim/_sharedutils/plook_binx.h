#ifndef SHARE_plook_binx
#define SHARE_plook_binx
#include "rtwtypes.h"
#include "multiword_types.h"

extern uint32_T plook_binx(real_T u, const real_T bp[], uint32_T maxIndex,
  real_T *fraction);

#endif
