#ifndef SHARE_xger_GB2Nboiy
#define SHARE_xger_GB2Nboiy
#include "rtwtypes.h"
#include "multiword_types.h"

extern void xger_GB2Nboiy(int32_T m, int32_T n, real32_T alpha1, int32_T ix0,
  const real32_T y[4], real32_T b_A[16], int32_T ia0);

#endif
