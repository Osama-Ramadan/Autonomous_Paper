#include "rtwtypes.h"
#include "multiword_types.h"
#include "mpc_plantupdate_aUusw0Me.h"

void mpc_plantupdate_aUusw0Me(const real32_T a[16], real32_T b[8], real32_T c[8],
  const real32_T d[4], real32_T b_A[25], real32_T b_B[30], real32_T b_C[10],
  real32_T b_D[12], const real32_T b_myindex[2], const real32_T b_Uscale[2],
  const real32_T b_Yscale[2], real32_T Bu[5], real32_T Bv[10], real32_T Cm[10],
  real32_T Dv[4], real32_T Dvm[4], real32_T QQ[25], real32_T RR[4], real32_T NN
  [10])
{
  int8_T UnknownIn[5];
  real32_T CovMat[49];
  int32_T i;
  real32_T b_B_p[35];
  real32_T b_B_e[35];
  int32_T i_p;
  int32_T i_e;
  int32_T i_i;
  int32_T i_m;
  int32_T Bv_tmp;
  real32_T b_D_tmp;
  real32_T b_D_tmp_p;
  int32_T CovMat_tmp;
  i_e = 0;
  for (i = 0; i < 2; i++) {
    b[i_e] *= b_Uscale[i];
    b[i_e + 1] *= b_Uscale[i];
    b[i_e + 2] *= b_Uscale[i];
    b[i_e + 3] *= b_Uscale[i];
    i_e += 4;
  }

  i_e = 0;
  i = 0;
  i_i = 0;
  for (Bv_tmp = 0; Bv_tmp < 4; Bv_tmp++) {
    c[i_e] /= b_Yscale[0];
    c[i_e + 1] /= b_Yscale[1];
    b_A[i] = a[i_i];
    b_A[i + 1] = a[i_i + 1];
    b_A[i + 2] = a[i_i + 2];
    b_A[i + 3] = a[i_i + 3];
    b_B[Bv_tmp] = b[Bv_tmp];
    b_C[i_e] = c[i_e];
    b_C[i_e + 1] = c[i_e + 1];
    b_B[Bv_tmp + 5] = b[Bv_tmp + 4];
    i_e += 2;
    i += 5;
    i_i += 4;
  }

  b_D_tmp = d[2] / b_Yscale[0] * b_Uscale[1];
  b_D[2] = b_D_tmp;
  b_D_tmp_p = d[3] / b_Yscale[1] * b_Uscale[1];
  b_D[3] = b_D_tmp_p;
  for (i_e = 0; i_e < 5; i_e++) {
    Bu[i_e] = b_B[i_e];
  }

  i_e = 0;
  for (i = 0; i < 2; i++) {
    for (i_i = 0; i_i < 5; i_i++) {
      Bv_tmp = i_i + i_e;
      Bv[Bv_tmp] = b_B[Bv_tmp + 5];
    }

    i_e += 5;
  }

  Dv[0] = b_D_tmp;
  Dvm[0] = b_D[(int32_T)b_myindex[0] + 1];
  Dv[1] = b_D_tmp_p;
  Dvm[1] = b_D[(int32_T)b_myindex[1] + 1];
  Dv[2] = b_D[4];
  Dvm[2] = b_D[(int32_T)b_myindex[0] + 3];
  Dv[3] = b_D[5];
  Dvm[3] = b_D[(int32_T)b_myindex[1] + 3];
  UnknownIn[0] = 1;
  UnknownIn[1] = 2;
  UnknownIn[2] = 4;
  UnknownIn[3] = 5;
  UnknownIn[4] = 6;
  for (i_e = 0; i_e < 5; i_e++) {
    Cm[i_e << 1] = b_C[((i_e << 1) + (int32_T)b_myindex[0]) - 1];
    Cm[1 + (i_e << 1)] = b_C[((i_e << 1) + (int32_T)b_myindex[1]) - 1];
    for (i = 0; i < 5; i++) {
      b_B_p[i + 7 * i_e] = b_B[(UnknownIn[i_e] - 1) * 5 + i];
      b_B_e[i + 5 * i_e] = b_B[(UnknownIn[i] - 1) * 5 + i_e];
    }

    b_B_p[5 + 7 * i_e] = b_D[(((UnknownIn[i_e] - 1) << 1) + (int32_T)b_myindex[0])
      - 1];
    b_B_p[6 + 7 * i_e] = b_D[(((UnknownIn[i_e] - 1) << 1) + (int32_T)b_myindex[1])
      - 1];
  }

  for (i_e = 0; i_e < 2; i_e++) {
    for (i = 0; i < 5; i++) {
      b_B_e[i + 5 * (i_e + 5)] = b_D[(((UnknownIn[i] - 1) << 1) + (int32_T)
        b_myindex[i_e]) - 1];
    }
  }

  i_e = 0;
  i = 0;
  for (i_i = 0; i_i < 7; i_i++) {
    for (Bv_tmp = 0; Bv_tmp < 7; Bv_tmp++) {
      CovMat_tmp = Bv_tmp + i_e;
      CovMat[CovMat_tmp] = 0.0F;
      i_m = 0;
      for (i_p = 0; i_p < 5; i_p++) {
        CovMat[CovMat_tmp] += b_B_p[i_m + Bv_tmp] * b_B_e[i_p + i];
        i_m += 7;
      }
    }

    i_e += 7;
    i += 5;
  }

  i_e = 0;
  i = 0;
  for (i_i = 0; i_i < 5; i_i++) {
    for (Bv_tmp = 0; Bv_tmp < 5; Bv_tmp++) {
      QQ[Bv_tmp + i_e] = CovMat[Bv_tmp + i];
    }

    i_e += 5;
    i += 7;
  }

  i_e = 0;
  i = 0;
  i_i = 0;
  for (Bv_tmp = 0; Bv_tmp < 2; Bv_tmp++) {
    RR[i_e] = CovMat[i + 40];
    RR[i_e + 1] = CovMat[i + 41];
    for (i_m = 0; i_m < 5; i_m++) {
      NN[i_m + i_i] = CovMat[(i_m + i) + 35];
    }

    i_e += 2;
    i += 7;
    i_i += 5;
  }
}
