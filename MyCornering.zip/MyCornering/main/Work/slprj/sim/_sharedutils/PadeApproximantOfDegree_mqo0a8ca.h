#ifndef SHARE_PadeApproximantOfDegree_mqo0a8ca
#define SHARE_PadeApproximantOfDegree_mqo0a8ca
#include "rtwtypes.h"
#include "multiword_types.h"

extern void PadeApproximantOfDegree_mqo0a8ca(const real32_T A[16], uint8_T m,
  real32_T F[16]);

#endif
