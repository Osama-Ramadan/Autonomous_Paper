#include "rtwtypes.h"
#include "multiword_types.h"
#include "eye_1T7g1wOb.h"

void eye_1T7g1wOb(real32_T I[4])
{
  I[1] = 0.0F;
  I[2] = 0.0F;
  I[0] = 1.0F;
  I[3] = 1.0F;
}
