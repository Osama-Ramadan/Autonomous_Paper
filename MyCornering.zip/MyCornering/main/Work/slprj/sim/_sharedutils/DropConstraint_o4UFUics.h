#ifndef SHARE_DropConstraint_o4UFUics
#define SHARE_DropConstraint_o4UFUics
#include "rtwtypes.h"
#include "multiword_types.h"

extern void DropConstraint_o4UFUics(int16_T kDrop, int16_T iA[126], int16_T *nA,
  int16_T iC[126]);

#endif
