#ifndef SHARE_qr_RqJKUjob
#define SHARE_qr_RqJKUjob
#include "rtwtypes.h"
#include "multiword_types.h"

extern void qr_RqJKUjob(const real32_T b_A[16], real32_T Q[16], real32_T R[16]);

#endif
