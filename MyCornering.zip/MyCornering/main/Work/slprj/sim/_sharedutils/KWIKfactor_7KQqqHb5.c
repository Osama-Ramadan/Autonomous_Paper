#include "rtwtypes.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "qr_RqJKUjob.h"
#include "KWIKfactor_7KQqqHb5.h"

real32_T KWIKfactor_7KQqqHb5(const real32_T b_Ac[504], const int16_T iC[126],
  int16_T nA, const real32_T b_Linv[16], real32_T RLinv[16], real32_T b_D[16],
  real32_T b_H[16], int16_T n)
{
  real32_T Status;
  real32_T TL[16];
  real32_T QQ[16];
  real32_T RR[16];
  int16_T i;
  int16_T f_i;
  int16_T d_k;
  int32_T i_p;
  int32_T iC_p;
  int32_T iC_tmp;
  int32_T exitg1;
  Status = 1.0F;
  for (i_p = 0; i_p < 16; i_p++) {
    RLinv[i_p] = 0.0F;
  }

  for (i = 1; i <= nA; i++) {
    iC_tmp = i - 1;
    iC_p = iC[iC_tmp];
    for (i_p = 0; i_p < 4; i_p++) {
      RLinv[i_p + (iC_tmp << 2)] = 0.0F;
      RLinv[i_p + (iC_tmp << 2)] += b_Ac[iC_p - 1] * b_Linv[i_p];
      RLinv[i_p + (iC_tmp << 2)] += b_Linv[i_p + 4] * b_Ac[iC_p + 125];
      RLinv[i_p + (iC_tmp << 2)] += b_Linv[i_p + 8] * b_Ac[iC_p + 251];
      RLinv[i_p + (iC_tmp << 2)] += b_Linv[i_p + 12] * b_Ac[iC_p + 377];
    }
  }

  qr_RqJKUjob(RLinv, QQ, RR);
  i = 1;
  do {
    exitg1 = 0;
    if (i <= nA) {
      if (muSingleScalarAbs(RR[(((i - 1) << 2) + i) - 1]) < 1.0E-12F) {
        Status = -2.0F;
        exitg1 = 1;
      } else {
        i++;
      }
    } else {
      for (i = 1; i <= n; i++) {
        for (f_i = 1; f_i <= n; f_i++) {
          TL[(i + ((f_i - 1) << 2)) - 1] = ((b_Linv[((i - 1) << 2) + 1] * QQ
            [((f_i - 1) << 2) + 1] + b_Linv[(i - 1) << 2] * QQ[(f_i - 1) << 2])
            + b_Linv[((i - 1) << 2) + 2] * QQ[((f_i - 1) << 2) + 2]) + b_Linv
            [((i - 1) << 2) + 3] * QQ[((f_i - 1) << 2) + 3];
        }
      }

      for (i_p = 0; i_p < 16; i_p++) {
        RLinv[i_p] = 0.0F;
      }

      for (i = nA; i > 0; i--) {
        RLinv[(i + ((i - 1) << 2)) - 1] = 1.0F;
        for (f_i = i; f_i <= nA; f_i++) {
          RLinv[(i + ((f_i - 1) << 2)) - 1] /= RR[(((i - 1) << 2) + i) - 1];
        }

        if (i > 1) {
          for (f_i = 1; f_i < i; f_i++) {
            for (d_k = i; d_k <= nA; d_k++) {
              RLinv[(f_i + ((d_k - 1) << 2)) - 1] -= RR[(((i - 1) << 2) + f_i) -
                1] * RLinv[(((d_k - 1) << 2) + i) - 1];
            }
          }
        }
      }

      for (i = 1; i <= n; i++) {
        for (f_i = i; f_i <= n; f_i++) {
          b_H[(i + ((f_i - 1) << 2)) - 1] = 0.0F;
          for (d_k = (int16_T)(nA + 1); d_k <= n; d_k++) {
            b_H[(i + ((f_i - 1) << 2)) - 1] -= TL[(((d_k - 1) << 2) + i) - 1] *
              TL[(((d_k - 1) << 2) + f_i) - 1];
          }

          b_H[(f_i + ((i - 1) << 2)) - 1] = b_H[(((f_i - 1) << 2) + i) - 1];
        }
      }

      for (i = 1; i <= nA; i++) {
        for (f_i = 1; f_i <= n; f_i++) {
          b_D[(f_i + ((i - 1) << 2)) - 1] = 0.0F;
          for (d_k = i; d_k <= nA; d_k++) {
            b_D[(f_i + ((i - 1) << 2)) - 1] += TL[(((d_k - 1) << 2) + f_i) - 1] *
              RLinv[(((d_k - 1) << 2) + i) - 1];
          }
        }
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return Status;
}
