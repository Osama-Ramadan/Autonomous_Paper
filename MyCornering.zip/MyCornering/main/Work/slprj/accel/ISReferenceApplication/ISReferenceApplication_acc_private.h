#include "__cf_ISReferenceApplication.h"
#ifndef RTW_HEADER_ISReferenceApplication_acc_private_h_
#define RTW_HEADER_ISReferenceApplication_acc_private_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "multiword_types.h"
#include "ISReferenceApplication_acc.h"
#if !defined(ss_VALIDATE_MEMORY)
#define ss_VALIDATE_MEMORY(S, ptr)   if(!(ptr)) {\
  ssSetErrorStatus(S, RT_MEMORY_ALLOCATION_ERROR);\
  }
#endif
#if !defined(rt_FREE)
#if !defined(_WIN32)
#define rt_FREE(ptr)   if((ptr) != (NULL)) {\
  free((ptr));\
  (ptr) = (NULL);\
  }
#else
#define rt_FREE(ptr)   if((ptr) != (NULL)) {\
  free((void *)(ptr));\
  (ptr) = (NULL);\
  }
#endif
#endif
#ifndef __RTW_UTFREE__
extern void * utMalloc ( size_t ) ; extern void utFree ( void * ) ;
#endif
void ISReferenceApplication_calc_up_Init ( SimStruct * S ) ; void
ISReferenceApplication_calc_up_Enable ( SimStruct * S ) ; void
ISReferenceApplication_calc_up_Disable ( SimStruct * S ) ; void
ISReferenceApplication_calc_up ( SimStruct * S ) ; void
ISReferenceApplication_calc_down_Init ( SimStruct * S ) ; void
ISReferenceApplication_calc_down_Enable ( SimStruct * S ) ; void
ISReferenceApplication_calc_down_Disable ( SimStruct * S ) ; void
ISReferenceApplication_calc_down ( SimStruct * S ) ; void
ISReferenceApplication_calc_Init ( SimStruct * S ) ; void
ISReferenceApplication_calc_Enable ( SimStruct * S ) ; void
ISReferenceApplication_calc_Disable ( SimStruct * S ) ; void
ISReferenceApplication_calc ( SimStruct * S ) ; extern boolean_T
ISReferenceApplication_calc_upFNI ( SimStruct * const S , int_T
controlPortIdx , int_T tid ) ; extern boolean_T
ISReferenceApplication_calc_downFNI ( SimStruct * const S , int_T
controlPortIdx , int_T tid ) ; extern boolean_T
ISReferenceApplication_calcFNI ( SimStruct * const S , int_T controlPortIdx ,
int_T tid ) ;
#endif
