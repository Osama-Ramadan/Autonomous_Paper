#include "__cf_ISReferenceApplication.h"
#include <math.h>
#include "ISReferenceApplication_acc.h"
#include "ISReferenceApplication_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "ISReferenceApplication_acc_rt_TDelayUpdateTailOrGrowBuf.h"
#include "ISReferenceApplication_acc_rt_TDelayInterpolate.h"
#include "look2_binlcapw.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
void rt_ssGetBlockPath ( SimStruct * S , int_T sysIdx , int_T blkIdx , char_T
* * path ) { _ssGetBlockPath ( S , sysIdx , blkIdx , path ) ; } void
rt_ssSet_slErrMsg ( SimStruct * S , void * diag ) { if ( !
_ssIsErrorStatusAslErrMsg ( S ) ) { _ssSet_slErrMsg ( S , diag ) ; } } void
rt_ssReportDiagnosticAsWarning ( SimStruct * S , void * diag ) {
_ssReportDiagnosticAsWarning ( S , diag ) ; } void
ISReferenceApplication_calc_up_Init ( SimStruct * S ) {
B_ISReferenceApplication_T * _rtB ; P_ISReferenceApplication_T * _rtP ; _rtP
= ( ( P_ISReferenceApplication_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_ISReferenceApplication_T * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> B_1_0_0 =
_rtP -> P_1 ; } void ISReferenceApplication_calc_up_Enable ( SimStruct * S )
{ DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( (
DW_ISReferenceApplication_T * ) ssGetRootDWork ( S ) ) ; _rtDW ->
calc_up_MODE = true ; } void ISReferenceApplication_calc_up_Disable (
SimStruct * S ) { DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( (
DW_ISReferenceApplication_T * ) ssGetRootDWork ( S ) ) ; _rtDW ->
calc_up_MODE = false ; } void ISReferenceApplication_calc_up ( SimStruct * S
) { B_ISReferenceApplication_T * _rtB ; P_ISReferenceApplication_T * _rtP ;
DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( ( DW_ISReferenceApplication_T
* ) ssGetRootDWork ( S ) ) ; _rtP = ( ( P_ISReferenceApplication_T * )
ssGetModelRtp ( S ) ) ; _rtB = ( ( B_ISReferenceApplication_T * )
_ssGetModelBlockIO ( S ) ) ; _rtB -> B_1_0_0 = look2_binlcapw ( _rtB ->
B_4_0_3 , _rtB -> B_4_0_2 , _rtP -> P_3 , _rtP -> P_4 , _rtP -> P_2 , _rtP ->
P_83 , 4U ) ; _rtDW -> calc_up_SubsysRanBC = 4 ; } boolean_T
ISReferenceApplication_calc_upFNI ( SimStruct * const S , int_T
controlPortIdx , int_T tid ) { ISReferenceApplication_calc_up ( S ) ;
UNUSED_PARAMETER ( controlPortIdx ) ; UNUSED_PARAMETER ( tid ) ; return ( 1 )
; } void ISReferenceApplication_calc_up_Term ( SimStruct * const S ) { } void
ISReferenceApplication_calc_down_Init ( SimStruct * S ) {
B_ISReferenceApplication_T * _rtB ; P_ISReferenceApplication_T * _rtP ; _rtP
= ( ( P_ISReferenceApplication_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_ISReferenceApplication_T * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> B_2_0_0 =
_rtP -> P_5 ; } void ISReferenceApplication_calc_down_Enable ( SimStruct * S
) { DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( (
DW_ISReferenceApplication_T * ) ssGetRootDWork ( S ) ) ; _rtDW ->
calc_down_MODE = true ; } void ISReferenceApplication_calc_down_Disable (
SimStruct * S ) { DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( (
DW_ISReferenceApplication_T * ) ssGetRootDWork ( S ) ) ; _rtDW ->
calc_down_MODE = false ; } void ISReferenceApplication_calc_down ( SimStruct
* S ) { B_ISReferenceApplication_T * _rtB ; P_ISReferenceApplication_T * _rtP
; DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( (
DW_ISReferenceApplication_T * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
P_ISReferenceApplication_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_ISReferenceApplication_T * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> B_2_0_0 =
look2_binlcapw ( _rtB -> B_4_0_5 , _rtB -> B_4_0_4 , _rtP -> P_7 , _rtP ->
P_8 , _rtP -> P_6 , _rtP -> P_84 , 4U ) ; _rtDW -> calc_down_SubsysRanBC = 4
; } boolean_T ISReferenceApplication_calc_downFNI ( SimStruct * const S ,
int_T controlPortIdx , int_T tid ) { ISReferenceApplication_calc_down ( S ) ;
UNUSED_PARAMETER ( controlPortIdx ) ; UNUSED_PARAMETER ( tid ) ; return ( 1 )
; } void ISReferenceApplication_calc_down_Term ( SimStruct * const S ) { }
void ISReferenceApplication_calc_Init ( SimStruct * S ) {
B_ISReferenceApplication_T * _rtB ; P_ISReferenceApplication_T * _rtP ; _rtP
= ( ( P_ISReferenceApplication_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_ISReferenceApplication_T * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> B_3_4_0 =
_rtP -> P_9 ; } void ISReferenceApplication_calc_Enable ( SimStruct * S ) {
DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( ( DW_ISReferenceApplication_T
* ) ssGetRootDWork ( S ) ) ; _rtDW -> calc_MODE = true ; } void
ISReferenceApplication_calc_Disable ( SimStruct * S ) {
DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( ( DW_ISReferenceApplication_T
* ) ssGetRootDWork ( S ) ) ; _rtDW -> calc_MODE = false ; } void
ISReferenceApplication_calc ( SimStruct * S ) { B_ISReferenceApplication_T *
_rtB ; P_ISReferenceApplication_T * _rtP ; DW_ISReferenceApplication_T *
_rtDW ; _rtDW = ( ( DW_ISReferenceApplication_T * ) ssGetRootDWork ( S ) ) ;
_rtP = ( ( P_ISReferenceApplication_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_ISReferenceApplication_T * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> B_3_4_0 =
( look2_binlcapw ( _rtB -> B_4_0_7 , _rtB -> B_4_0_6 , _rtP -> P_11 , _rtP ->
P_12 , _rtP -> P_10 , _rtP -> P_85 , 4U ) - _rtB -> B_4_0_8 ) - ( _rtB ->
B_4_0_8 - look2_binlcapw ( _rtB -> B_4_0_7 , _rtB -> B_4_0_6 , _rtP -> P_14 ,
_rtP -> P_15 , _rtP -> P_13 , _rtP -> P_86 , 4U ) ) ; _rtDW ->
calc_SubsysRanBC = 4 ; } boolean_T ISReferenceApplication_calcFNI ( SimStruct
* const S , int_T controlPortIdx , int_T tid ) { ISReferenceApplication_calc
( S ) ; UNUSED_PARAMETER ( controlPortIdx ) ; UNUSED_PARAMETER ( tid ) ;
return ( 1 ) ; } void ISReferenceApplication_calc_Term ( SimStruct * const S
) { } static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T * lastU ;
real_T rtb_B_9_52_0 ; int32_T isHit ; real_T u0 ; B_ISReferenceApplication_T
* _rtB ; P_ISReferenceApplication_T * _rtP ; X_ISReferenceApplication_T *
_rtX ; DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( (
DW_ISReferenceApplication_T * ) ssGetRootDWork ( S ) ) ; _rtX = ( (
X_ISReferenceApplication_T * ) ssGetContStates ( S ) ) ; _rtP = ( (
P_ISReferenceApplication_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_ISReferenceApplication_T * ) _ssGetModelBlockIO ( S ) ) ; isHit =
ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { rtb_B_9_52_0 =
ssGetTaskTime ( S , 1 ) ; _rtDW -> Step_MODE = ( rtb_B_9_52_0 >= _rtP -> P_31
) ; if ( _rtDW -> Step_MODE == 1 ) { _rtB -> B_9_0_0 = _rtP -> P_33 ; } else
{ _rtB -> B_9_0_0 = _rtP -> P_32 ; } } _rtB -> B_9_6_0 = ( ssGetT ( S ) -
_rtB -> B_9_2_0 ) * _rtB -> B_9_0_0 + _rtB -> B_9_5_0 ; if (
ssIsMajorTimeStep ( S ) != 0 ) { _rtDW -> Saturation_MODE = _rtB -> B_9_6_0
>= _rtP -> P_36 ? 1 : _rtB -> B_9_6_0 > _rtP -> P_37 ? 0 : - 1 ; } _rtB ->
B_9_8_0 = ( _rtDW -> Saturation_MODE == 1 ? _rtP -> P_36 : _rtDW ->
Saturation_MODE == - 1 ? _rtP -> P_37 : _rtB -> B_9_6_0 ) * _rtP -> P_38 ;
ssCallAccelRunBlock ( S , 9 , 9 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock
( S , 9 , 10 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 9 , 30 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ( _rtDW -> TimeStampA >= ssGetT ( S ) ) && (
_rtDW -> TimeStampB >= ssGetT ( S ) ) ) { _rtB -> B_9_31_0 = 0.0 ; } else {
rtb_B_9_52_0 = _rtDW -> TimeStampA ; lastU = & _rtDW -> LastUAtTimeA ; if (
_rtDW -> TimeStampA < _rtDW -> TimeStampB ) { if ( _rtDW -> TimeStampB <
ssGetT ( S ) ) { rtb_B_9_52_0 = _rtDW -> TimeStampB ; lastU = & _rtDW ->
LastUAtTimeB ; } } else { if ( _rtDW -> TimeStampA >= ssGetT ( S ) ) {
rtb_B_9_52_0 = _rtDW -> TimeStampB ; lastU = & _rtDW -> LastUAtTimeB ; } }
_rtB -> B_9_31_0 = ( _rtB -> B_9_30_0 - * lastU ) / ( ssGetT ( S ) -
rtb_B_9_52_0 ) ; } ssCallAccelRunBlock ( S , 9 , 32 , SS_CALL_MDL_OUTPUTS ) ;
{ real_T * * uBuffer = ( real_T * * ) & _rtDW -> TransportDelay1_PWORK .
TUbufferPtrs [ 0 ] ; real_T * * tBuffer = ( real_T * * ) & _rtDW ->
TransportDelay1_PWORK . TUbufferPtrs [ 1 ] ; real_T simTime = ssGetT ( S ) ;
real_T tMinusDelay = simTime - _rtP -> P_48 ; _rtB -> B_9_38_0 =
ISReferenceApplication_acc_rt_TDelayInterpolate ( tMinusDelay , 0.0 , *
tBuffer , * uBuffer , _rtDW -> TransportDelay1_IWORK . CircularBufSize , &
_rtDW -> TransportDelay1_IWORK . Last , _rtDW -> TransportDelay1_IWORK . Tail
, _rtDW -> TransportDelay1_IWORK . Head , _rtP -> P_49 , 0 , ( boolean_T ) (
ssIsMinorTimeStep ( S ) && ( ssGetTimeOfLastOutput ( S ) == ssGetT ( S ) ) )
) ; } _rtB -> B_9_41_0 = _rtX -> Integrator_CSTATE ; _rtB -> B_9_43_0 = ( (
_rtB -> B_9_37_0 - _rtB -> B_9_38_0 ) * _rtP -> P_50 + _rtB -> B_9_41_0 ) +
_rtB -> B_9_36_0 ; ssCallAccelRunBlock ( S , 9 , 44 , SS_CALL_MDL_OUTPUTS ) ;
isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { rtb_B_9_52_0 =
ssGetTaskTime ( S , 1 ) ; _rtDW -> Step_MODE_j = ( rtb_B_9_52_0 >= _rtP ->
P_52 ) ; if ( _rtDW -> Step_MODE_j == 1 ) { _rtB -> B_9_45_0 = _rtP -> P_54 ;
} else { _rtB -> B_9_45_0 = _rtP -> P_53 ; } } _rtB -> B_9_48_0 = ssGetT ( S
) - _rtB -> B_9_47_0 ; _rtB -> B_9_49_0 = _rtB -> B_9_45_0 * _rtB -> B_9_48_0
; _rtB -> B_9_51_0 = _rtB -> B_9_49_0 + _rtB -> B_9_50_0 ; rtb_B_9_52_0 =
0.44704000000000005 * _rtB -> B_9_51_0 ; _rtB -> B_9_53_0 = _rtP -> P_57 *
rtb_B_9_52_0 ; _rtB -> B_9_54_0 = _rtX -> Integrator_CSTATE_h ; _rtB ->
B_9_55_0 = _rtP -> P_59 * _rtB -> B_9_54_0 ; if ( ssIsMajorTimeStep ( S ) !=
0 ) { if ( _rtX -> Integrator1_CSTATE >= _rtP -> P_61 ) { _rtX ->
Integrator1_CSTATE = _rtP -> P_61 ; } else { if ( _rtX -> Integrator1_CSTATE
<= _rtP -> P_62 ) { _rtX -> Integrator1_CSTATE = _rtP -> P_62 ; } } } _rtB ->
B_9_56_0 = _rtX -> Integrator1_CSTATE ; _rtB -> B_9_59_0 = ( ( _rtB ->
B_9_53_0 + _rtB -> B_9_55_0 ) + _rtB -> B_9_56_0 ) + _rtB -> B_9_58_0 ; if (
ssIsMajorTimeStep ( S ) != 0 ) { _rtDW -> uto1_MODE = _rtB -> B_9_59_0 >=
_rtP -> P_65 ? 1 : _rtB -> B_9_59_0 > _rtP -> P_66 ? 0 : - 1 ; } _rtB ->
B_9_60_0 = _rtDW -> uto1_MODE == 1 ? _rtP -> P_65 : _rtDW -> uto1_MODE == - 1
? _rtP -> P_66 : _rtB -> B_9_59_0 ; if ( _rtB -> B_9_60_0 > _rtP -> P_67 ) {
_rtB -> B_9_61_0 = _rtP -> P_67 ; } else if ( _rtB -> B_9_60_0 < _rtP -> P_68
) { _rtB -> B_9_61_0 = _rtP -> P_68 ; } else { _rtB -> B_9_61_0 = _rtB ->
B_9_60_0 ; } isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { { if (
( _rtDW -> HiddenToAsyncQueue_InsertedFor_BusSelector2_at_outport_0_PWORK .
AQHandles || _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusSelector2_at_outport_0_PWORK . SlioLTF ) &&
ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusSelector2_at_outport_0_PWORK . AQHandles ,
_rtDW -> HiddenToAsyncQueue_InsertedFor_BusSelector2_at_outport_0_PWORK .
SlioLTF , 0 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_61_0 ) ; } }
} if ( _rtB -> B_9_60_0 > _rtP -> P_69 ) { _rtB -> B_9_63_0 = _rtP -> P_69 ;
} else if ( _rtB -> B_9_60_0 < _rtP -> P_70 ) { _rtB -> B_9_63_0 = _rtP ->
P_70 ; } else { _rtB -> B_9_63_0 = _rtB -> B_9_60_0 ; } _rtB -> B_9_64_0 = -
_rtB -> B_9_63_0 ; isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) {
{ if ( ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusSelector2_at_outport_1_PWORK . AQHandles ||
_rtDW -> HiddenToAsyncQueue_InsertedFor_BusSelector2_at_outport_1_PWORK .
SlioLTF ) && ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusSelector2_at_outport_1_PWORK . AQHandles ,
_rtDW -> HiddenToAsyncQueue_InsertedFor_BusSelector2_at_outport_1_PWORK .
SlioLTF , 0 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_64_0 ) ; } }
{ if ( ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusSelector_at_outport_1_PWORK . AQHandles ||
_rtDW -> HiddenToAsyncQueue_InsertedFor_BusSelector_at_outport_1_PWORK .
SlioLTF ) && ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusSelector_at_outport_1_PWORK . AQHandles ,
_rtDW -> HiddenToAsyncQueue_InsertedFor_BusSelector_at_outport_1_PWORK .
SlioLTF , 0 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_0 ) ; } }
{ if ( ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusSelector_at_outport_2_PWORK . AQHandles ||
_rtDW -> HiddenToAsyncQueue_InsertedFor_BusSelector_at_outport_2_PWORK .
SlioLTF ) && ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusSelector_at_outport_2_PWORK . AQHandles ,
_rtDW -> HiddenToAsyncQueue_InsertedFor_BusSelector_at_outport_2_PWORK .
SlioLTF , 0 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_8 ) ; } }
} _rtB -> B_9_68_0 = 2.236936292054402 * _rtB -> B_9_30_0 ; isHit =
ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { { if ( ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification1_at_outport_0_PWORK .
AQHandles || _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification1_at_outport_0_PWORK .
SlioLTF ) && ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification1_at_outport_0_PWORK .
AQHandles , _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification1_at_outport_0_PWORK .
SlioLTF , 0 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_68_0 ) ; } }
} _rtB -> B_9_70_0 = 9.5492965855137211 * _rtB -> B_9_10_3 ; isHit =
ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { { if ( ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification3_at_outport_0_PWORK .
AQHandles || _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification3_at_outport_0_PWORK .
SlioLTF ) && ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification3_at_outport_0_PWORK .
AQHandles , _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification3_at_outport_0_PWORK .
SlioLTF , 0 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_70_0 ) ; } }
} _rtB -> B_9_72_0 = 57.295779513082323 * _rtB -> B_9_8_0 ; isHit =
ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { { if ( ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification_at_outport_0_PWORK .
AQHandles || _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification_at_outport_0_PWORK .
SlioLTF ) && ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification_at_outport_0_PWORK .
AQHandles , _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification_at_outport_0_PWORK .
SlioLTF , 0 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_72_0 ) ; } }
} _rtB -> B_9_74_0 = _rtP -> P_71 * _rtB -> B_9_61_0 ; ssCallAccelRunBlock (
S , 9 , 75 , SS_CALL_MDL_OUTPUTS ) ; isHit = ssIsSampleHit ( S , 1 , 0 ) ; if
( isHit != 0 ) { { if ( ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 0 ]
|| _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF ) && ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 0 ]
, _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 0 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_75_0 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 1 ]
, _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 1 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_10_0 [ 0 ] )
; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 2 ]
, _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 2 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_10_1 [ 0 ] )
; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 3 ]
, _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 3 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_10_2 [ 0 ] )
; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 4 ]
, _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 4 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_10_3 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 5 ]
, _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 5 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_10_4 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 6 ]
, _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 6 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_0 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 7 ]
, _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 7 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_1 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 8 ]
, _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 8 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_9 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 9 ]
, _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 9 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_10 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 10
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 10 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_11 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 11
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 11 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_12 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 12
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 12 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_13 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 13
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 13 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_14 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 14
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 14 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_15 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 15
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 15 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_2 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 16
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 16 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_3 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 17
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 17 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_4 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 18
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 18 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_5 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 19
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 19 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_8 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 20
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 20 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_17 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 21
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 21 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_6 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 22
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 22 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_16 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 23
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 23 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_7 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 24
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 24 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_18 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 25
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 25 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_19 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 26
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 26 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_20 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 27
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 27 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_21 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 28
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 28 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_22 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 29
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 29 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_23 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 30
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 30 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_24 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 31
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 31 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_25 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 32
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 32 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_26 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 33
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 33 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_27 [ 0 ]
) ; sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK . AQHandles [ 34
] , _rtDW -> HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK .
SlioLTF , 34 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_28 [ 0 ]
) ; } } } ssCallAccelRunBlock ( S , 9 , 77 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 7 , 0 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock
( S , 9 , 79 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_9_80_0 [ 0 ] = _rtB ->
B_9_30_21 [ 0 ] / _rtB -> B_9_30_28 [ 0 ] ; _rtB -> B_9_80_0 [ 1 ] = _rtB ->
B_9_30_21 [ 1 ] / _rtB -> B_9_30_28 [ 1 ] ; _rtB -> B_9_80_0 [ 2 ] = _rtB ->
B_9_30_21 [ 2 ] / _rtB -> B_9_30_28 [ 2 ] ; _rtB -> B_9_80_0 [ 3 ] = _rtB ->
B_9_30_21 [ 3 ] / _rtB -> B_9_30_28 [ 3 ] ; ssCallAccelRunBlock ( S , 9 , 81
, SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 9 , 82 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_9_85_0 = 2.236936292054402 * _rtB ->
B_9_30_0 ; _rtB -> B_9_86_0 [ 4 ] = _rtB -> B_9_30_8 ; _rtB -> B_9_80_0 [ 0 ]
= 57.295779513082323 * _rtB -> B_9_30_27 [ 0 ] ; _rtB -> B_9_84_0 [ 0 ] =
57.295779513082323 * _rtB -> B_9_30_28 [ 0 ] ; _rtB -> B_9_86_0 [ 0 ] = _rtB
-> B_9_80_0 [ 0 ] ; _rtB -> B_9_86_0 [ 5 ] = _rtB -> B_9_84_0 [ 0 ] ; _rtB ->
B_9_80_0 [ 1 ] = 57.295779513082323 * _rtB -> B_9_30_27 [ 1 ] ; _rtB ->
B_9_84_0 [ 1 ] = 57.295779513082323 * _rtB -> B_9_30_28 [ 1 ] ; _rtB ->
B_9_86_0 [ 1 ] = _rtB -> B_9_80_0 [ 1 ] ; _rtB -> B_9_86_0 [ 6 ] = _rtB ->
B_9_84_0 [ 1 ] ; _rtB -> B_9_80_0 [ 2 ] = 57.295779513082323 * _rtB ->
B_9_30_27 [ 2 ] ; _rtB -> B_9_84_0 [ 2 ] = 57.295779513082323 * _rtB ->
B_9_30_28 [ 2 ] ; _rtB -> B_9_86_0 [ 2 ] = _rtB -> B_9_80_0 [ 2 ] ; _rtB ->
B_9_86_0 [ 7 ] = _rtB -> B_9_84_0 [ 2 ] ; _rtB -> B_9_80_0 [ 3 ] =
57.295779513082323 * _rtB -> B_9_30_27 [ 3 ] ; _rtB -> B_9_84_0 [ 3 ] =
57.295779513082323 * _rtB -> B_9_30_28 [ 3 ] ; _rtB -> B_9_86_0 [ 3 ] = _rtB
-> B_9_80_0 [ 3 ] ; _rtB -> B_9_86_0 [ 8 ] = _rtB -> B_9_84_0 [ 3 ] ; _rtB ->
B_9_86_0 [ 9 ] = _rtB -> B_7_0_1 ; _rtB -> B_9_86_0 [ 10 ] = _rtB -> B_9_85_0
; ssCallAccelRunBlock ( S , 9 , 87 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_9_88_0
[ 0 ] = _rtB -> B_9_8_0 ; _rtB -> B_9_88_0 [ 1 ] = _rtB -> B_9_61_0 ; _rtB ->
B_9_88_0 [ 2 ] = _rtB -> B_9_64_0 ; ssCallAccelRunBlock ( S , 9 , 89 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_9_90_0 [ 0 ] = 9.5492965855137211 * _rtB ->
B_9_30_7 [ 0 ] ; _rtB -> B_9_90_0 [ 1 ] = 9.5492965855137211 * _rtB ->
B_9_30_7 [ 1 ] ; _rtB -> B_9_90_0 [ 2 ] = 9.5492965855137211 * _rtB ->
B_9_30_7 [ 2 ] ; _rtB -> B_9_90_0 [ 3 ] = 9.5492965855137211 * _rtB ->
B_9_30_7 [ 3 ] ; ssCallAccelRunBlock ( S , 9 , 91 , SS_CALL_MDL_OUTPUTS ) ;
isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { isHit =
ssIsSampleHit ( S , 3 , 0 ) ; if ( isHit != 0 ) { _rtB -> B_9_92_0 [ 0 ] =
_rtB -> B_9_30_9 ; _rtB -> B_9_92_0 [ 1 ] = _rtB -> B_9_30_10 ; _rtB ->
B_9_92_0 [ 2 ] = _rtB -> B_9_30_11 ; } isHit = ssIsSampleHit ( S , 3 , 0 ) ;
if ( isHit != 0 ) { _rtB -> B_9_93_0 [ 0 ] = _rtB -> B_9_30_14 ; _rtB ->
B_9_93_0 [ 1 ] = _rtB -> B_9_30_15 ; _rtB -> B_9_93_0 [ 2 ] = _rtB ->
B_9_30_2 ; } } _rtB -> B_9_96_0 [ 0 ] = _rtB -> B_9_30_12 ; _rtB -> B_9_96_0
[ 1 ] = _rtB -> B_9_30_13 ; _rtB -> B_9_96_0 [ 2 ] = 0.0 ; isHit =
ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { isHit = ssIsSampleHit ( S ,
3 , 0 ) ; if ( isHit != 0 ) { _rtB -> B_9_97_0 [ 0 ] = _rtB -> B_9_96_0 [ 0 ]
; _rtB -> B_9_97_0 [ 1 ] = _rtB -> B_9_96_0 [ 1 ] ; _rtB -> B_9_97_0 [ 2 ] =
_rtB -> B_9_96_0 [ 2 ] ; } isHit = ssIsSampleHit ( S , 3 , 0 ) ; if ( isHit
!= 0 ) { _rtB -> B_9_98_0 [ 0 ] = _rtB -> B_9_10_0 [ 0 ] ; _rtB -> B_9_98_0 [
1 ] = _rtB -> B_9_10_0 [ 1 ] ; _rtB -> B_9_98_0 [ 2 ] = _rtB -> B_9_10_0 [ 2
] ; _rtB -> B_9_98_0 [ 3 ] = _rtB -> B_9_10_0 [ 3 ] ; } } isHit =
ssIsSampleHit ( S , 3 , 0 ) ; if ( isHit != 0 ) { ssCallAccelRunBlock ( S , 8
, 0 , SS_CALL_MDL_OUTPUTS ) ; } isHit = ssIsSampleHit ( S , 1 , 0 ) ; if (
isHit != 0 ) { isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0 ) { _rtB
-> B_9_100_0 = _rtDW -> RateTransition3_Buffer0 ; } } if ( ssIsMajorTimeStep
( S ) != 0 ) { if ( _rtX -> Integrator2_CSTATE >= _rtP -> P_73 ) { _rtX ->
Integrator2_CSTATE = _rtP -> P_73 ; } else { if ( _rtX -> Integrator2_CSTATE
<= _rtP -> P_74 ) { _rtX -> Integrator2_CSTATE = _rtP -> P_74 ; } } } _rtB ->
B_9_101_0 = _rtX -> Integrator2_CSTATE ; _rtB -> B_9_106_0 [ 0 ] = _rtB ->
B_9_101_0 ; _rtB -> B_9_106_0 [ 1 ] = _rtB -> B_9_101_0 ; _rtB -> B_9_106_0 [
2 ] = _rtB -> B_9_101_0 ; _rtB -> B_9_106_0 [ 3 ] = _rtB -> B_9_101_0 ; isHit
= ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { { if ( ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusCreator3_at_outport_0_1_PWORK . AQHandles [
0 ] || _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusCreator3_at_outport_0_1_PWORK . SlioLTF )
&& ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusCreator3_at_outport_0_1_PWORK . AQHandles [
0 ] , _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusCreator3_at_outport_0_1_PWORK . SlioLTF , 0
, ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_74_0 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusCreator3_at_outport_0_1_PWORK . AQHandles [
1 ] , _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusCreator3_at_outport_0_1_PWORK . SlioLTF , 1
, ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_100_0 ) ;
sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusCreator3_at_outport_0_1_PWORK . AQHandles [
2 ] , _rtDW ->
HiddenToAsyncQueue_InsertedFor_BusCreator3_at_outport_0_1_PWORK . SlioLTF , 2
, ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_106_0 [ 0 ] ) ; } } } if
( ssIsMajorTimeStep ( S ) != 0 ) { _rtDW -> Switch1_Mode = ( _rtB -> B_9_64_0
> _rtP -> P_76 ) ; } if ( _rtDW -> Switch1_Mode ) { _rtB -> B_0_0_0 = _rtP ->
P_0 * _rtB -> B_9_64_0 ; _rtB -> B_9_110_0 = _rtB -> B_0_0_0 ; } else { _rtB
-> B_9_110_0 = _rtB -> B_9_108_0 ; } _rtB -> B_9_111_0 = 9.5492965855137211 *
_rtB -> B_9_10_3 ; isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) {
{ if ( ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification_at_outport_0_PWORK_j .
AQHandles || _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification_at_outport_0_PWORK_j .
SlioLTF ) && ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification_at_outport_0_PWORK_j .
AQHandles , _rtDW ->
HiddenToAsyncQueue_InsertedFor_SignalSpecification_at_outport_0_PWORK_j .
SlioLTF , 0 , ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_111_0 ) ; }
} isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0 ) { _rtB -> B_9_113_0
= _rtB -> B_9_61_0 ; } isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0
) { _rtB -> B_9_114_0 = _rtB -> B_9_111_0 ; } isHit = ssIsSampleHit ( S , 2 ,
0 ) ; if ( isHit != 0 ) { _rtB -> B_9_115_0 = _rtB -> B_9_10_4 ; } } isHit =
ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0 ) { u0 = _rtP -> P_18 * _rtB ->
B_9_114_0 ; if ( u0 > _rtP -> P_19 ) { u0 = _rtP -> P_19 ; } else { if ( u0 <
_rtP -> P_20 ) { u0 = _rtP -> P_20 ; } } _rtB -> B_5_6_0 = ( ( _rtB ->
B_9_113_0 <= _rtB -> B_5_1_0 ) && ( u0 <= _rtB -> B_5_0_0 ) ) ; _rtB ->
B_5_8_0 = _rtP -> P_21 [ 1 ] * _rtDW -> PropShaftSpeedLPF_states * _rtP ->
P_24 ; ssCallAccelRunBlock ( S , 4 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtDW ->
PropShaftSpeedLPF_states = ( _rtB -> B_9_115_0 - _rtP -> P_22 [ 1 ] * _rtDW
-> PropShaftSpeedLPF_states ) / _rtP -> P_22 [ 0 ] ; _rtDW -> TCM_SubsysRanBC
= 4 ; } ssCallAccelRunBlock ( S , 9 , 118 , SS_CALL_MDL_OUTPUTS ) ; _rtB ->
B_9_119_0 = rtb_B_9_52_0 - _rtB -> B_9_30_0 ; _rtB -> B_9_123_0 = _rtB ->
B_9_119_0 * _rtB -> B_9_119_0 ; isHit = ssIsSampleHit ( S , 2 , 0 ) ; if (
isHit != 0 ) { _rtB -> B_9_124_0 [ 0 ] = _rtDW -> UnitDelay_DSTATE [ 0 ] ;
_rtB -> B_9_124_0 [ 1 ] = _rtDW -> UnitDelay_DSTATE [ 1 ] ; } if ( _rtB ->
B_9_119_0 > _rtB -> B_9_124_0 [ 0 ] ) { _rtB -> B_9_129_0 [ 0 ] = _rtB ->
B_9_119_0 ; } else { _rtB -> B_9_129_0 [ 0 ] = _rtB -> B_9_124_0 [ 0 ] ; } if
( _rtB -> B_9_119_0 < _rtB -> B_9_124_0 [ 1 ] ) { _rtB -> B_9_129_0 [ 1 ] =
_rtB -> B_9_119_0 ; } else { _rtB -> B_9_129_0 [ 1 ] = _rtB -> B_9_124_0 [ 1
] ; } _rtB -> B_9_130_0 = _rtB -> B_9_60_0 - _rtB -> B_9_59_0 ; _rtB ->
B_9_131_0 = _rtP -> P_79 * _rtB -> B_9_130_0 ; _rtB -> B_9_132_0 = _rtP ->
P_80 * _rtB -> B_9_54_0 ; isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit !=
0 ) { _rtB -> B_9_134_0 = 1.0 / _rtP -> P_81 ; } _rtB -> B_9_135_0 = _rtB ->
B_9_119_0 - _rtB -> B_9_54_0 ; _rtB -> B_9_136_0 = _rtB -> B_9_134_0 * _rtB
-> B_9_135_0 ; _rtB -> B_9_137_0 = _rtB -> B_9_132_0 + _rtB -> B_9_131_0 ;
ssCallAccelRunBlock ( S , 6 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_9_139_0 =
_rtB -> B_9_34_0 - _rtB -> B_9_38_0 ; _rtB -> B_9_140_0 = _rtP -> P_82 * _rtB
-> B_9_139_0 ; isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { { if
( ( _rtDW -> HiddenToAsyncQueue_InsertedFor_ay_at_outport_0_PWORK . AQHandles
|| _rtDW -> HiddenToAsyncQueue_InsertedFor_ay_at_outport_0_PWORK . SlioLTF )
&& ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_ay_at_outport_0_PWORK . AQHandles , _rtDW ->
HiddenToAsyncQueue_InsertedFor_ay_at_outport_0_PWORK . SlioLTF , 0 ,
ssGetTaskTime ( S , 1 ) , ( void * ) & _rtB -> B_9_30_8 ) ; } } }
UNUSED_PARAMETER ( tid ) ; } static void mdlOutputsTID4 ( SimStruct * S ,
int_T tid ) { B_ISReferenceApplication_T * _rtB ; P_ISReferenceApplication_T
* _rtP ; DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( (
DW_ISReferenceApplication_T * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
P_ISReferenceApplication_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_ISReferenceApplication_T * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> B_9_2_0 =
_rtP -> P_34 ; _rtB -> B_9_5_0 = _rtP -> P_35 ; _rtB -> B_9_17_0 [ 0 ] = _rtP
-> P_39 ; _rtB -> B_9_17_0 [ 1 ] = _rtP -> P_40 ; _rtB -> B_9_17_0 [ 2 ] =
_rtP -> P_41 ; _rtB -> B_9_23_0 [ 0 ] = _rtP -> P_42 [ 0 ] ; _rtB -> B_9_23_0
[ 1 ] = _rtP -> P_42 [ 1 ] ; _rtB -> B_9_23_0 [ 2 ] = _rtP -> P_42 [ 2 ] ;
_rtB -> B_9_23_0 [ 3 ] = _rtP -> P_42 [ 3 ] ; _rtB -> B_9_29_0 [ 0 ] = _rtP
-> P_43 [ 0 ] ; _rtB -> B_9_29_0 [ 1 ] = _rtP -> P_43 [ 1 ] ; _rtB ->
B_9_29_0 [ 2 ] = _rtP -> P_43 [ 2 ] ; _rtB -> B_9_29_0 [ 3 ] = _rtP -> P_43 [
3 ] ; _rtB -> B_9_34_0 = _rtP -> P_45 ; _rtB -> B_9_36_0 = _rtP -> P_44 /
_rtB -> B_9_34_0 * _rtP -> P_46 ; _rtB -> B_9_37_0 = _rtP -> P_47 * _rtB ->
B_9_34_0 ; _rtB -> B_9_47_0 = _rtP -> P_55 ; _rtB -> B_9_50_0 = _rtP -> P_56
; _rtB -> B_9_58_0 = _rtP -> P_64 * _rtP -> P_63 ; ssCallAccelRunBlock ( S ,
9 , 75 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_9_108_0 = _rtP -> P_75 ; _rtB ->
B_5_0_0 = _rtP -> P_16 ; _rtB -> B_5_1_0 = _rtP -> P_17 ; UNUSED_PARAMETER (
tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { real_T * lastU ;
int32_T isHit ; B_ISReferenceApplication_T * _rtB ;
P_ISReferenceApplication_T * _rtP ; X_ISReferenceApplication_T * _rtX ;
DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( ( DW_ISReferenceApplication_T
* ) ssGetRootDWork ( S ) ) ; _rtX = ( ( X_ISReferenceApplication_T * )
ssGetContStates ( S ) ) ; _rtP = ( ( P_ISReferenceApplication_T * )
ssGetModelRtp ( S ) ) ; _rtB = ( ( B_ISReferenceApplication_T * )
_ssGetModelBlockIO ( S ) ) ; ssCallAccelRunBlock ( S , 9 , 10 ,
SS_CALL_MDL_UPDATE ) ; ssCallAccelRunBlock ( S , 9 , 30 , SS_CALL_MDL_UPDATE
) ; if ( _rtDW -> TimeStampA == ( rtInf ) ) { _rtDW -> TimeStampA = ssGetT (
S ) ; lastU = & _rtDW -> LastUAtTimeA ; } else if ( _rtDW -> TimeStampB == (
rtInf ) ) { _rtDW -> TimeStampB = ssGetT ( S ) ; lastU = & _rtDW ->
LastUAtTimeB ; } else if ( _rtDW -> TimeStampA < _rtDW -> TimeStampB ) {
_rtDW -> TimeStampA = ssGetT ( S ) ; lastU = & _rtDW -> LastUAtTimeA ; } else
{ _rtDW -> TimeStampB = ssGetT ( S ) ; lastU = & _rtDW -> LastUAtTimeB ; } *
lastU = _rtB -> B_9_30_0 ; { real_T * * uBuffer = ( real_T * * ) & _rtDW ->
TransportDelay1_PWORK . TUbufferPtrs [ 0 ] ; real_T * * tBuffer = ( real_T *
* ) & _rtDW -> TransportDelay1_PWORK . TUbufferPtrs [ 1 ] ; real_T simTime =
ssGetT ( S ) ; _rtDW -> TransportDelay1_IWORK . Head = ( ( _rtDW ->
TransportDelay1_IWORK . Head < ( _rtDW -> TransportDelay1_IWORK .
CircularBufSize - 1 ) ) ? ( _rtDW -> TransportDelay1_IWORK . Head + 1 ) : 0 )
; if ( _rtDW -> TransportDelay1_IWORK . Head == _rtDW ->
TransportDelay1_IWORK . Tail ) { if ( !
ISReferenceApplication_acc_rt_TDelayUpdateTailOrGrowBuf ( & _rtDW ->
TransportDelay1_IWORK . CircularBufSize , & _rtDW -> TransportDelay1_IWORK .
Tail , & _rtDW -> TransportDelay1_IWORK . Head , & _rtDW ->
TransportDelay1_IWORK . Last , simTime - _rtP -> P_48 , tBuffer , uBuffer , (
NULL ) , ( boolean_T ) 0 , false , & _rtDW -> TransportDelay1_IWORK .
MaxNewBufSize ) ) { ssSetErrorStatus ( S , "tdelay memory allocation error" )
; return ; } } ( * tBuffer ) [ _rtDW -> TransportDelay1_IWORK . Head ] =
simTime ; ( * uBuffer ) [ _rtDW -> TransportDelay1_IWORK . Head ] = _rtB ->
B_6_0_1 ; } if ( _rtX -> Integrator1_CSTATE == _rtP -> P_61 ) { switch (
_rtDW -> Integrator1_MODE ) { case 3 : if ( _rtB -> B_9_137_0 < 0.0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; _rtDW -> Integrator1_MODE
= 1 ; } break ; case 1 : if ( _rtB -> B_9_137_0 >= 0.0 ) { _rtDW ->
Integrator1_MODE = 3 ; ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; }
break ; default : ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; if (
_rtB -> B_9_137_0 < 0.0 ) { _rtDW -> Integrator1_MODE = 1 ; } else { _rtDW ->
Integrator1_MODE = 3 ; } break ; } } else if ( _rtX -> Integrator1_CSTATE ==
_rtP -> P_62 ) { switch ( _rtDW -> Integrator1_MODE ) { case 4 : if ( _rtB ->
B_9_137_0 > 0.0 ) { ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; _rtDW
-> Integrator1_MODE = 2 ; } break ; case 2 : if ( _rtB -> B_9_137_0 <= 0.0 )
{ _rtDW -> Integrator1_MODE = 4 ; ssSetBlockStateForSolverChangedAtMajorStep
( S ) ; } break ; default : ssSetBlockStateForSolverChangedAtMajorStep ( S )
; if ( _rtB -> B_9_137_0 > 0.0 ) { _rtDW -> Integrator1_MODE = 2 ; } else {
_rtDW -> Integrator1_MODE = 4 ; } break ; } } else { _rtDW ->
Integrator1_MODE = 0 ; } ssCallAccelRunBlock ( S , 9 , 75 ,
SS_CALL_MDL_UPDATE ) ; isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0
) { _rtDW -> RateTransition3_Buffer0 = _rtB -> B_4_0_1 ; } if ( _rtX ->
Integrator2_CSTATE == _rtP -> P_73 ) { switch ( _rtDW -> Integrator2_MODE ) {
case 3 : if ( _rtB -> B_9_110_0 < 0.0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; _rtDW -> Integrator2_MODE
= 1 ; } break ; case 1 : if ( _rtB -> B_9_110_0 >= 0.0 ) { _rtDW ->
Integrator2_MODE = 3 ; ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; }
break ; default : ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; if (
_rtB -> B_9_110_0 < 0.0 ) { _rtDW -> Integrator2_MODE = 1 ; } else { _rtDW ->
Integrator2_MODE = 3 ; } break ; } } else if ( _rtX -> Integrator2_CSTATE ==
_rtP -> P_74 ) { switch ( _rtDW -> Integrator2_MODE ) { case 4 : if ( _rtB ->
B_9_110_0 > 0.0 ) { ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; _rtDW
-> Integrator2_MODE = 2 ; } break ; case 2 : if ( _rtB -> B_9_110_0 <= 0.0 )
{ _rtDW -> Integrator2_MODE = 4 ; ssSetBlockStateForSolverChangedAtMajorStep
( S ) ; } break ; default : ssSetBlockStateForSolverChangedAtMajorStep ( S )
; if ( _rtB -> B_9_110_0 > 0.0 ) { _rtDW -> Integrator2_MODE = 2 ; } else {
_rtDW -> Integrator2_MODE = 4 ; } break ; } } else { _rtDW ->
Integrator2_MODE = 0 ; } isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit !=
0 ) { _rtDW -> UnitDelay_DSTATE [ 0 ] = _rtB -> B_9_129_0 [ 0 ] ; _rtDW ->
UnitDelay_DSTATE [ 1 ] = _rtB -> B_9_129_0 [ 1 ] ; } UNUSED_PARAMETER ( tid )
; }
#define MDL_UPDATE
static void mdlUpdateTID4 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { B_ISReferenceApplication_T *
_rtB ; XDot_ISReferenceApplication_T * _rtXdot ;
XDis_ISReferenceApplication_T * _rtXdis ; DW_ISReferenceApplication_T * _rtDW
; _rtDW = ( ( DW_ISReferenceApplication_T * ) ssGetRootDWork ( S ) ) ;
_rtXdis = ( ( XDis_ISReferenceApplication_T * ) ssGetContStateDisabled ( S )
) ; _rtXdot = ( ( XDot_ISReferenceApplication_T * ) ssGetdX ( S ) ) ; _rtB =
( ( B_ISReferenceApplication_T * ) _ssGetModelBlockIO ( S ) ) ;
ssCallAccelRunBlock ( S , 9 , 10 , SS_CALL_MDL_DERIVATIVES ) ;
ssCallAccelRunBlock ( S , 9 , 30 , SS_CALL_MDL_DERIVATIVES ) ; _rtXdot ->
Integrator_CSTATE = _rtB -> B_9_140_0 ; _rtXdot -> Integrator_CSTATE_h = _rtB
-> B_9_136_0 ; if ( ( _rtDW -> Integrator1_MODE != 3 ) && ( _rtDW ->
Integrator1_MODE != 4 ) ) { _rtXdot -> Integrator1_CSTATE = _rtB -> B_9_137_0
; _rtXdis -> Integrator1_CSTATE = false ; } else { _rtXdot ->
Integrator1_CSTATE = 0.0 ; if ( ( _rtDW -> Integrator1_MODE == 3 ) || ( _rtDW
-> Integrator1_MODE == 4 ) ) { _rtXdis -> Integrator1_CSTATE = true ; } }
ssCallAccelRunBlock ( S , 9 , 75 , SS_CALL_MDL_DERIVATIVES ) ; if ( ( _rtDW
-> Integrator2_MODE != 3 ) && ( _rtDW -> Integrator2_MODE != 4 ) ) { _rtXdot
-> Integrator2_CSTATE = _rtB -> B_9_110_0 ; _rtXdis -> Integrator2_CSTATE =
false ; } else { _rtXdot -> Integrator2_CSTATE = 0.0 ; if ( ( _rtDW ->
Integrator2_MODE == 3 ) || ( _rtDW -> Integrator2_MODE == 4 ) ) { _rtXdis ->
Integrator2_CSTATE = true ; } } _rtXdot -> Integrator2_CSTATE_f = _rtB ->
B_9_123_0 ; }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { boolean_T anyStateSaturated
; B_ISReferenceApplication_T * _rtB ; P_ISReferenceApplication_T * _rtP ;
X_ISReferenceApplication_T * _rtX ; ZCV_ISReferenceApplication_T * _rtZCSV ;
DW_ISReferenceApplication_T * _rtDW ; _rtDW = ( ( DW_ISReferenceApplication_T
* ) ssGetRootDWork ( S ) ) ; _rtZCSV = ( ( ZCV_ISReferenceApplication_T * )
ssGetSolverZcSignalVector ( S ) ) ; _rtX = ( ( X_ISReferenceApplication_T * )
ssGetContStates ( S ) ) ; _rtP = ( ( P_ISReferenceApplication_T * )
ssGetModelRtp ( S ) ) ; _rtB = ( ( B_ISReferenceApplication_T * )
_ssGetModelBlockIO ( S ) ) ; _rtZCSV -> Step_StepTime_ZC = ssGetT ( S ) -
_rtP -> P_31 ; _rtZCSV -> Saturation_UprLim_ZC = _rtB -> B_9_6_0 - _rtP ->
P_36 ; _rtZCSV -> Saturation_LwrLim_ZC = _rtB -> B_9_6_0 - _rtP -> P_37 ;
ssCallAccelRunBlock ( S , 9 , 30 , SS_CALL_MDL_ZERO_CROSSINGS ) ; _rtZCSV ->
Step_StepTime_ZC_f = ssGetT ( S ) - _rtP -> P_52 ; if ( ( _rtDW ->
Integrator1_MODE == 1 ) && ( _rtX -> Integrator1_CSTATE >= _rtP -> P_61 ) ) {
_rtZCSV -> Integrator1_IntgUpLimit_ZC = 0.0 ; } else { _rtZCSV ->
Integrator1_IntgUpLimit_ZC = _rtX -> Integrator1_CSTATE - _rtP -> P_61 ; } if
( ( _rtDW -> Integrator1_MODE == 2 ) && ( _rtX -> Integrator1_CSTATE <= _rtP
-> P_62 ) ) { _rtZCSV -> Integrator1_IntgLoLimit_ZC = 0.0 ; } else { _rtZCSV
-> Integrator1_IntgLoLimit_ZC = _rtX -> Integrator1_CSTATE - _rtP -> P_62 ; }
anyStateSaturated = false ; if ( ( _rtDW -> Integrator1_MODE == 3 ) || (
_rtDW -> Integrator1_MODE == 4 ) ) { anyStateSaturated = true ; } if (
anyStateSaturated ) { _rtZCSV -> Integrator1_LeaveSaturate_ZC = _rtB ->
B_9_137_0 ; } else { _rtZCSV -> Integrator1_LeaveSaturate_ZC = 0.0 ; }
_rtZCSV -> uto1_UprLim_ZC = _rtB -> B_9_59_0 - _rtP -> P_65 ; _rtZCSV ->
uto1_LwrLim_ZC = _rtB -> B_9_59_0 - _rtP -> P_66 ; if ( ( _rtDW ->
Integrator2_MODE == 1 ) && ( _rtX -> Integrator2_CSTATE >= _rtP -> P_73 ) ) {
_rtZCSV -> Integrator2_IntgUpLimit_ZC = 0.0 ; } else { _rtZCSV ->
Integrator2_IntgUpLimit_ZC = _rtX -> Integrator2_CSTATE - _rtP -> P_73 ; } if
( ( _rtDW -> Integrator2_MODE == 2 ) && ( _rtX -> Integrator2_CSTATE <= _rtP
-> P_74 ) ) { _rtZCSV -> Integrator2_IntgLoLimit_ZC = 0.0 ; } else { _rtZCSV
-> Integrator2_IntgLoLimit_ZC = _rtX -> Integrator2_CSTATE - _rtP -> P_74 ; }
anyStateSaturated = false ; if ( ( _rtDW -> Integrator2_MODE == 3 ) || (
_rtDW -> Integrator2_MODE == 4 ) ) { anyStateSaturated = true ; } if (
anyStateSaturated ) { _rtZCSV -> Integrator2_LeaveSaturate_ZC = _rtB ->
B_9_110_0 ; } else { _rtZCSV -> Integrator2_LeaveSaturate_ZC = 0.0 ; }
_rtZCSV -> Switch1_SwitchCond_ZC = _rtB -> B_9_64_0 - _rtP -> P_76 ; } static
void mdlInitializeSizes ( SimStruct * S ) { ssSetChecksumVal ( S , 0 ,
3208065566U ) ; ssSetChecksumVal ( S , 1 , 2008617226U ) ; ssSetChecksumVal (
S , 2 , 3327122218U ) ; ssSetChecksumVal ( S , 3 , 3979578081U ) ; { mxArray
* slVerStructMat = NULL ; mxArray * slStrMat = mxCreateString ( "simulink" )
; char slVerChar [ 10 ] ; int status = mexCallMATLAB ( 1 , & slVerStructMat ,
1 , & slStrMat , "ver" ) ; if ( status == 0 ) { mxArray * slVerMat =
mxGetField ( slVerStructMat , 0 , "Version" ) ; if ( slVerMat == NULL ) {
status = 1 ; } else { status = mxGetString ( slVerMat , slVerChar , 10 ) ; }
} mxDestroyArray ( slStrMat ) ; mxDestroyArray ( slVerStructMat ) ; if ( (
status == 1 ) || ( strcmp ( slVerChar , "9.1" ) != 0 ) ) { return ; } }
ssSetOptions ( S , SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork (
S ) != sizeof ( DW_ISReferenceApplication_T ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( B_ISReferenceApplication_T ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
P_ISReferenceApplication_T ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & ISReferenceApplication_DefaultP ) ; rt_InitInfAndNaN ( sizeof ( real_T )
) ; } static void mdlInitializeSampleTimes ( SimStruct * S ) { { SimStruct *
childS ; SysOutputFcn * callSysFcns ; childS = ssGetSFunction ( S , 0 ) ;
callSysFcns = ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 9 + 0 ]
= ( SysOutputFcn ) ISReferenceApplication_calc_upFNI ; callSysFcns [ 9 + 1 ]
= ( SysOutputFcn ) ISReferenceApplication_calc_downFNI ; callSysFcns [ 9 + 2
] = ( SysOutputFcn ) ISReferenceApplication_calcFNI ; childS = ssGetSFunction
( S , 1 ) ; callSysFcns = ssGetCallSystemOutputFcnList ( childS ) ;
callSysFcns [ 3 + 0 ] = ( SysOutputFcn ) ( NULL ) ; childS = ssGetSFunction (
S , 2 ) ; callSysFcns = ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns
[ 3 + 0 ] = ( SysOutputFcn ) ( NULL ) ; childS = ssGetSFunction ( S , 3 ) ;
callSysFcns = ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ]
= ( SysOutputFcn ) ( NULL ) ; } slAccRegPrmChangeFcn ( S , mdlOutputsTID4 ) ;
} static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
