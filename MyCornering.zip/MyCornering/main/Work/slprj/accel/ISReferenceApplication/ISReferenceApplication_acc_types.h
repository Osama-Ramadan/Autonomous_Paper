#include "__cf_ISReferenceApplication.h"
#ifndef RTW_HEADER_ISReferenceApplication_acc_types_h_
#define RTW_HEADER_ISReferenceApplication_acc_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "multiword_types.h"
typedef struct P_ISReferenceApplication_T_ P_ISReferenceApplication_T ;
#endif
