#include "__cf_ISReferenceApplication.h"
#ifndef RTW_HEADER_ISReferenceApplication_acc_h_
#define RTW_HEADER_ISReferenceApplication_acc_h_
#include <stddef.h>
#ifndef ISReferenceApplication_acc_COMMON_INCLUDES_
#define ISReferenceApplication_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "ISReferenceApplication_acc_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "SiMappedEngineV.h"
#include "PassVeh14DOF.h"
#include "Driveline.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "rt_defines.h"
typedef struct { real_T B_9_0_0 ; real_T B_9_2_0 ; real_T B_9_5_0 ; real_T
B_9_6_0 ; real_T B_9_8_0 ; real_T B_9_10_0 [ 4 ] ; real_T B_9_10_1 [ 4 ] ;
real_T B_9_10_2 [ 4 ] ; real_T B_9_10_3 ; real_T B_9_10_4 ; real_T B_9_17_0 [
3 ] ; real_T B_9_23_0 [ 4 ] ; real_T B_9_29_0 [ 4 ] ; real_T B_9_30_0 ;
real_T B_9_30_1 ; real_T B_9_30_2 ; real_T B_9_30_3 ; real_T B_9_30_4 ;
real_T B_9_30_5 ; real_T B_9_30_6 [ 4 ] ; real_T B_9_30_7 [ 4 ] ; real_T
B_9_30_8 ; real_T B_9_30_9 ; real_T B_9_30_10 ; real_T B_9_30_11 ; real_T
B_9_30_12 ; real_T B_9_30_13 ; real_T B_9_30_14 ; real_T B_9_30_15 ; real_T
B_9_30_16 [ 4 ] ; real_T B_9_30_17 [ 4 ] ; real_T B_9_30_18 [ 4 ] ; real_T
B_9_30_19 [ 4 ] ; real_T B_9_30_20 [ 4 ] ; real_T B_9_30_21 [ 4 ] ; real_T
B_9_30_22 [ 4 ] ; real_T B_9_30_23 [ 4 ] ; real_T B_9_30_24 [ 4 ] ; real_T
B_9_30_25 [ 4 ] ; real_T B_9_30_26 [ 4 ] ; real_T B_9_30_27 [ 4 ] ; real_T
B_9_30_28 [ 4 ] ; real_T B_9_31_0 ; real_T B_9_34_0 ; real_T B_9_36_0 ;
real_T B_9_37_0 ; real_T B_9_38_0 ; real_T B_9_41_0 ; real_T B_9_43_0 ;
real_T B_9_45_0 ; real_T B_9_47_0 ; real_T B_9_48_0 ; real_T B_9_49_0 ;
real_T B_9_50_0 ; real_T B_9_51_0 ; real_T B_9_53_0 ; real_T B_9_54_0 ;
real_T B_9_55_0 ; real_T B_9_56_0 ; real_T B_9_58_0 ; real_T B_9_59_0 ;
real_T B_9_60_0 ; real_T B_9_61_0 ; real_T B_9_63_0 ; real_T B_9_64_0 ;
real_T B_9_68_0 ; real_T B_9_70_0 ; real_T B_9_72_0 ; real_T B_9_74_0 ;
real_T B_9_75_0 ; real_T B_9_77_0 [ 2000 ] ; real_T B_9_85_0 ; real_T
B_9_92_0 [ 3 ] ; real_T B_9_93_0 [ 3 ] ; real_T B_9_96_0 [ 3 ] ; real_T
B_9_97_0 [ 3 ] ; real_T B_9_98_0 [ 4 ] ; real_T B_9_101_0 ; real_T B_9_106_0
[ 4 ] ; real_T B_9_108_0 ; real_T B_9_110_0 ; real_T B_9_111_0 ; real_T
B_9_113_0 ; real_T B_9_114_0 ; real_T B_9_115_0 ; real_T B_9_118_0 [ 2000 ] ;
real_T B_9_119_0 ; real_T B_9_123_0 ; real_T B_9_124_0 [ 2 ] ; real_T
B_9_129_0 [ 2 ] ; real_T B_9_130_0 ; real_T B_9_131_0 ; real_T B_9_132_0 ;
real_T B_9_134_0 ; real_T B_9_135_0 ; real_T B_9_136_0 ; real_T B_9_137_0 ;
real_T B_9_139_0 ; real_T B_9_140_0 ; real_T B_7_0_1 ; real_T B_6_0_1 ;
real_T B_5_0_0 ; real_T B_5_1_0 ; real_T B_5_8_0 ; real_T B_4_0_2 ; real_T
B_4_0_3 ; real_T B_4_0_4 ; real_T B_4_0_5 ; real_T B_4_0_6 ; real_T B_4_0_7 ;
real_T B_4_0_8 ; real_T B_3_4_0 ; real_T B_2_0_0 ; real_T B_1_0_0 ; real_T
B_0_0_0 ; real_T B_9_84_0 [ 4 ] ; real_T B_9_86_0 [ 11 ] ; real_T B_9_88_0 [
3 ] ; real_T B_9_90_0 [ 4 ] ; real_T B_9_80_0 [ 4 ] ; int8_T B_9_100_0 ;
int8_T B_4_0_1 ; boolean_T B_5_6_0 ; char_T pad_B_5_6_0 [ 5 ] ; }
B_ISReferenceApplication_T ; typedef struct { real_T UnitDelay_DSTATE [ 2 ] ;
real_T PropShaftSpeedLPF_states ; real_T TimeStampA ; real_T LastUAtTimeA ;
real_T TimeStampB ; real_T LastUAtTimeB ; real_T TCM_lastCallTime ; real_T
calc_lastCallTime ; real_T calc_down_lastCallTime ; real_T
calc_up_lastCallTime ; struct { real_T modelTStart ; } TransportDelay1_RWORK
; void * Scope1_PWORK ; void * Scope2_PWORK ; struct { void * TUbufferPtrs [
2 ] ; } TransportDelay1_PWORK ; void * Scope3_PWORK ; struct { void *
AQHandles ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_BusSelector2_at_outport_0_PWORK ; struct {
void * AQHandles ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_BusSelector2_at_outport_1_PWORK ; struct {
void * AQHandles ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_BusSelector_at_outport_1_PWORK ; struct { void
* AQHandles ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_BusSelector_at_outport_2_PWORK ; struct { void
* AQHandles ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_SignalSpecification1_at_outport_0_PWORK ;
struct { void * AQHandles ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_SignalSpecification3_at_outport_0_PWORK ;
struct { void * AQHandles ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_SignalSpecification_at_outport_0_PWORK ;
struct { void * AQHandles [ 35 ] ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_VehFdbk_at_outport_0_1_PWORK ; struct { void *
uBuffers [ 2 ] ; } SFunction_PWORK ; void * Scope_PWORK ; void *
Scope1_PWORK_m ; void * SteerVelocityLatAccel_PWORK [ 3 ] ; void *
ToWorkspace_PWORK ; void * ToWorkspace1_PWORK ; void * Tyres_PWORK [ 8 ] ;
struct { void * AQHandles [ 3 ] ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_BusCreator3_at_outport_0_1_PWORK ; struct {
void * AQHandles ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_SignalSpecification_at_outport_0_PWORK_j ;
struct { void * uBuffers [ 2 ] ; } SFunction_PWORK_l ; struct { void *
AQHandles ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_ay_at_outport_0_PWORK ; int32_T
VehicleXYPlotter_sysIdxToRun ; int32_T MATLABFunction_sysIdxToRun ; int32_T
MATLABFunction_sysIdxToRun_d ; int32_T TCM_sysIdxToRun ; int32_T
TCMShiftController_sysIdxToRun ; int32_T calc_sysIdxToRun ; int32_T
calc_down_sysIdxToRun ; int32_T calc_up_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch1Inport1_sysIdxToRun ; struct { int_T Tail ; int_T
Head ; int_T Last ; int_T CircularBufSize ; int_T MaxNewBufSize ; }
TransportDelay1_IWORK ; struct { int_T indPs ; int_T bufSz ; }
SFunction_IWORK ; struct { int_T indPs ; int_T bufSz ; } SFunction_IWORK_e ;
int_T Step_MODE ; int_T Saturation_MODE ; int_T Step_MODE_j ; int_T
Integrator1_MODE ; int_T uto1_MODE ; int_T Integrator2_MODE ; int8_T
RateTransition3_Buffer0 ; int8_T TCM_SubsysRanBC ; int8_T calc_SubsysRanBC ;
int8_T calc_down_SubsysRanBC ; int8_T calc_up_SubsysRanBC ; boolean_T
Switch1_Mode ; boolean_T TCM_MODE ; boolean_T calc_MODE ; boolean_T
calc_down_MODE ; boolean_T calc_up_MODE ; char_T pad_calc_up_MODE [ 6 ] ;
n5qm5cab0up DrivelineIdealFixedGear_InstanceData ; egcgcay4tuh
PassVeh14DOF_InstanceData ; o2k4rz0uw5x IdealMappedEngine_InstanceData ; }
DW_ISReferenceApplication_T ; typedef struct { oakdhkzk5b
DrivelineIdealFixedGear_CSTATE ; h21fsrthfa PassVeh14DOF_CSTATE ; real_T
Integrator_CSTATE ; real_T Integrator_CSTATE_h ; real_T Integrator1_CSTATE ;
fpgmc1blog IdealMappedEngine_CSTATE ; real_T Integrator2_CSTATE ; real_T
Integrator2_CSTATE_f ; } X_ISReferenceApplication_T ; typedef int_T
PeriodicIndX_ISReferenceApplication_T [ 4 ] ; typedef real_T
PeriodicRngX_ISReferenceApplication_T [ 8 ] ; typedef struct { bjbjifrsrv
DrivelineIdealFixedGear_CSTATE ; ectmdkaxud PassVeh14DOF_CSTATE ; real_T
Integrator_CSTATE ; real_T Integrator_CSTATE_h ; real_T Integrator1_CSTATE ;
ih0mudozt1 IdealMappedEngine_CSTATE ; real_T Integrator2_CSTATE ; real_T
Integrator2_CSTATE_f ; } XDot_ISReferenceApplication_T ; typedef struct {
l1pljxktrl DrivelineIdealFixedGear_CSTATE ; gy0s4k0fxb PassVeh14DOF_CSTATE ;
boolean_T Integrator_CSTATE ; boolean_T Integrator_CSTATE_h ; boolean_T
Integrator1_CSTATE ; dk2lj1ie3v IdealMappedEngine_CSTATE ; boolean_T
Integrator2_CSTATE ; boolean_T Integrator2_CSTATE_f ; }
XDis_ISReferenceApplication_T ; typedef struct { grfcawoazk
DrivelineIdealFixedGear_CSTATE ; mq10j5tdpd PassVeh14DOF_CSTATE ; real_T
Integrator_CSTATE ; real_T Integrator_CSTATE_h ; real_T Integrator1_CSTATE ;
i3uom1vnc5 IdealMappedEngine_CSTATE ; real_T Integrator2_CSTATE ; real_T
Integrator2_CSTATE_f ; } CStateAbsTol_ISReferenceApplication_T ; typedef
struct { real_T Step_StepTime_ZC ; real_T Saturation_UprLim_ZC ; real_T
Saturation_LwrLim_ZC ; jn1etpvcka DrivelineIdealFixedGear_Reset_ZC ;
beahf2xhqn PassVeh14DOF_Input_ZC ; real_T Step_StepTime_ZC_f ; real_T
Integrator1_IntgUpLimit_ZC ; real_T Integrator1_IntgLoLimit_ZC ; real_T
Integrator1_LeaveSaturate_ZC ; real_T uto1_UprLim_ZC ; real_T uto1_LwrLim_ZC
; real_T Integrator2_IntgUpLimit_ZC ; real_T Integrator2_IntgLoLimit_ZC ;
real_T Integrator2_LeaveSaturate_ZC ; real_T Switch1_SwitchCond_ZC ; }
ZCV_ISReferenceApplication_T ; typedef struct { ZCSigState Step_StepTime_ZCE
; ZCSigState Saturation_UprLim_ZCE ; ZCSigState Saturation_LwrLim_ZCE ;
ZCSigState DrivelineIdealFixedGear_Reset_ZCE ; ZCSigState
DrivelineIdealFixedGear_Reset_ZCE_a ; ZCSigState
DrivelineIdealFixedGear_Reset_ZCE_ae ; ZCSigState PassVeh14DOF_Input_ZCE ;
ZCSigState PassVeh14DOF_UprLim_ZCE ; ZCSigState PassVeh14DOF_LwrLim_ZCE ;
ZCSigState PassVeh14DOF_Input_ZCE_o ; ZCSigState PassVeh14DOF_UprLim_ZCE_g ;
ZCSigState PassVeh14DOF_LwrLim_ZCE_d ; ZCSigState PassVeh14DOF_Input_ZCE_ou ;
ZCSigState PassVeh14DOF_UprLim_ZCE_go ; ZCSigState PassVeh14DOF_LwrLim_ZCE_dg
; ZCSigState PassVeh14DOF_Input_ZCE_oub ; ZCSigState
PassVeh14DOF_UprLim_ZCE_goy ; ZCSigState PassVeh14DOF_LwrLim_ZCE_dgl ;
ZCSigState Step_StepTime_ZCE_i ; ZCSigState Integrator1_IntgUpLimit_ZCE ;
ZCSigState Integrator1_IntgLoLimit_ZCE ; ZCSigState
Integrator1_LeaveSaturate_ZCE ; ZCSigState uto1_UprLim_ZCE ; ZCSigState
uto1_LwrLim_ZCE ; ZCSigState Integrator2_IntgUpLimit_ZCE ; ZCSigState
Integrator2_IntgLoLimit_ZCE ; ZCSigState Integrator2_LeaveSaturate_ZCE ;
ZCSigState Switch1_SwitchCond_ZCE ; } PrevZCX_ISReferenceApplication_T ;
typedef struct { real_T VehicleXYPlotter_bufferSize_Size [ 2 ] ; real_T
VehicleXYPlotter_bufferSize ; real_T VehicleXYPlotter_figBorder_Size [ 2 ] ;
real_T VehicleXYPlotter_figBorder ; real_T VehicleXYPlotter_figWidth_Size [ 2
] ; real_T VehicleXYPlotter_figWidth ; } ConstP_ISReferenceApplication_T ;
struct P_ISReferenceApplication_T_ { real_T P_0 ; real_T P_1 ; real_T P_2 [
28 ] ; real_T P_3 [ 4 ] ; real_T P_4 [ 7 ] ; real_T P_5 ; real_T P_6 [ 28 ] ;
real_T P_7 [ 4 ] ; real_T P_8 [ 7 ] ; real_T P_9 ; real_T P_10 [ 28 ] ;
real_T P_11 [ 4 ] ; real_T P_12 [ 7 ] ; real_T P_13 [ 28 ] ; real_T P_14 [ 4
] ; real_T P_15 [ 7 ] ; real_T P_16 ; real_T P_17 ; real_T P_18 ; real_T P_19
; real_T P_20 ; real_T P_21 [ 2 ] ; real_T P_22 [ 2 ] ; real_T P_23 ; real_T
P_24 ; real_T P_25 [ 2 ] ; real_T P_26 ; real_T P_27 [ 2 ] ; real_T P_28 ;
real_T P_29 [ 2 ] ; real_T P_30 ; real_T P_31 ; real_T P_32 ; real_T P_33 ;
real_T P_34 ; real_T P_35 ; real_T P_36 ; real_T P_37 ; real_T P_38 ; real_T
P_39 ; real_T P_40 ; real_T P_41 ; real_T P_42 [ 4 ] ; real_T P_43 [ 4 ] ;
real_T P_44 ; real_T P_45 ; real_T P_46 ; real_T P_47 ; real_T P_48 ; real_T
P_49 ; real_T P_50 ; real_T P_51 ; real_T P_52 ; real_T P_53 ; real_T P_54 ;
real_T P_55 ; real_T P_56 ; real_T P_57 ; real_T P_58 ; real_T P_59 ; real_T
P_60 ; real_T P_61 ; real_T P_62 ; real_T P_63 ; real_T P_64 ; real_T P_65 ;
real_T P_66 ; real_T P_67 ; real_T P_68 ; real_T P_69 ; real_T P_70 ; real_T
P_71 ; real_T P_72 ; real_T P_73 ; real_T P_74 ; real_T P_75 ; real_T P_76 ;
real_T P_77 ; real_T P_78 [ 2 ] ; real_T P_79 ; real_T P_80 ; real_T P_81 ;
real_T P_82 ; uint32_T P_83 [ 2 ] ; uint32_T P_84 [ 2 ] ; uint32_T P_85 [ 2 ]
; uint32_T P_86 [ 2 ] ; int8_T P_87 ; char_T pad_P_87 [ 7 ] ; } ; extern
P_ISReferenceApplication_T ISReferenceApplication_DefaultP ; extern const
ConstP_ISReferenceApplication_T ISReferenceApplication_ConstP ;
#endif
