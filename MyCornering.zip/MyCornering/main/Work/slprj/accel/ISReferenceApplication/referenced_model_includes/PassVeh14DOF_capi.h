#include "__cf_PassVeh14DOF.h"
#ifndef RTW_HEADER_PassVeh14DOF_capi_h_
#define RTW_HEADER_PassVeh14DOF_capi_h_
#include "PassVeh14DOF.h"
extern void PassVeh14DOF_InitializeDataMapInfo ( gwlxzditat * const
ke3gqsjzkb , jb251fek03 * localDW , h21fsrthfa * localX , void * sysRanPtr ,
int contextTid ) ;
#endif
