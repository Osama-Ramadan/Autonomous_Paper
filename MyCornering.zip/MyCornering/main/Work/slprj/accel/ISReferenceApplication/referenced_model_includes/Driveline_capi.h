#include "__cf_Driveline.h"
#ifndef RTW_HEADER_Driveline_capi_h_
#define RTW_HEADER_Driveline_capi_h_
#include "Driveline.h"
extern void Driveline_InitializeDataMapInfo ( dwsgrvz41y * const pubqvcmed4 ,
bsz3qtxrxd * localDW , oakdhkzk5b * localX , void * sysRanPtr , int
contextTid ) ;
#endif
