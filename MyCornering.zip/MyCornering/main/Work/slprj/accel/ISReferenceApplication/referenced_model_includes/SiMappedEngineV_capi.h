#include "__cf_SiMappedEngineV.h"
#ifndef RTW_HEADER_SiMappedEngineV_capi_h_
#define RTW_HEADER_SiMappedEngineV_capi_h_
#include "SiMappedEngineV.h"
extern void SiMappedEngineV_InitializeDataMapInfo ( kgxfljuibq * const
plpdajfsza , fpgmc1blog * localX , void * sysRanPtr , int contextTid ) ;
#endif
